# --- File: DynamicArray.java ---

# package: com.thealgorithms.datastructures.dynamicarray

# import: java.util.Arrays

# import: java.util.ConcurrentModificationException

# import: java.util.Iterator

# import: java.util.NoSuchElementException

# import: java.util.Objects

# import: java.util.function.Consumer

# import: java.util.stream.Stream

# import: java.util.stream.StreamSupport

class DynamicArray:
    """* This class implements a dynamic array, which can grow or shrink in size
 * as elements are added or removed. It provides an array-like interface
 * with methods to add, remove, and access elements, along with iterators
 * to traverse the elements.
 *
 * @param <E> the type of elements that this array can hold"""
    DEFAULT_CAPACITY: int = 16
    def __init__(self, capacity=None):
        """* Constructs a new DynamicArray with the specified initial capacity.
     *
     * @param capacity the initial capacity of the array
     * @throws IllegalArgumentException if the specified capacity is negative"""
        if capacity is not None:
            # 
     * Constructs a new DynamicArray with the specified initial capacity.
     *
     * @param capacity the initial capacity of the array
     * @throws IllegalArgumentException if the specified capacity is negative
     
            if capacity < 0:
                raise ValueError("Capacity cannot be negative.")
            self.size = 0
            self.modCount = 0
            this.elements =  new Object[capacity]
        elif capacity is None:
            # 
     * Constructs a new DynamicArray with a default initial capacity.
     
            # Unhandled node type: ExplicitConstructorInvocationStmt
    def add(self, element):
        """* Adds an element to the end of the array. If the array is full, it
     * creates a new array with double the size to accommodate the new element.
     *
     * @param element the element to be added to the array"""
        # 
     * Adds an element to the end of the array. If the array is full, it
     * creates a new array with double the size to accommodate the new element.
     *
     * @param element the element to be added to the array
     
        ensureCapacity(size + 1)
        print(f"{str(elements[size)}{str(] = element)}")
        modCount += 1
    def put(self, index, element):
        """* Places an element at the specified index, expanding capacity if necessary.
     *
     * @param index   the index at which the element is to be placed
     * @param element the element to be inserted at the specified index
     * @throws IndexOutOfBoundsException if index is less than 0 or greater than or equal to the number of elements"""
        # 
     * Places an element at the specified index, expanding capacity if necessary.
     *
     * @param index   the index at which the element is to be placed
     * @param element the element to be inserted at the specified index
     * @throws IndexOutOfBoundsException if index is less than 0 or greater than or equal to the number of elements
     
        if index < 0:
            raise IndexOutOfBoundsException("Index cannot be negative.")
        ensureCapacity(index + 1)
        elements[index] = element
        if index >= size:
            print(f"{str(size = index)}{str(1)}")
        modCount += 1
    def get(self, index):
        """* Retrieves the element at the specified index.
     *
     * @param index the index of the element to retrieve
     * @return the element at the specified index
     * @throws IndexOutOfBoundsException if index is less than 0 or greater than or equal to the current size"""
        # 
     * Retrieves the element at the specified index.
     *
     * @param index the index of the element to retrieve
     * @return the element at the specified index
     * @throws IndexOutOfBoundsException if index is less than 0 or greater than or equal to the current size
     
        # expr: SuppressWarnings
        if index < 0 || index >= size:
            raise IndexOutOfBoundsException("Index: " + index + ", Size: " + size)
        return (E) elements[index]
    def remove(self, index):
        """* Removes and returns the element at the specified index.
     *
     * @param index the index of the element to be removed
     * @return the element that was removed from the array
     * @throws IndexOutOfBoundsException if index is less than 0 or greater than or equal to the current size"""
        # 
     * Removes and returns the element at the specified index.
     *
     * @param index the index of the element to be removed
     * @return the element that was removed from the array
     * @throws IndexOutOfBoundsException if index is less than 0 or greater than or equal to the current size
     
        if index < 0 || index >= size:
            raise IndexOutOfBoundsException("Index: " + index + ", Size: " + size)
        @SuppressWarnings("unchecked")
E oldElement = (E) elements[index]
        fastRemove(index)
        modCount += 1
        return oldElement
    def getSize(self):
        """* Returns the current number of elements in the array.
     *
     * @return the number of elements in the array"""
        # 
     * Returns the current number of elements in the array.
     *
     * @return the number of elements in the array
     
        return size
    def isEmpty(self):
        """* Checks whether the array is empty.
     *
     * @return true if the array contains no elements, false otherwise"""
        # 
     * Checks whether the array is empty.
     *
     * @return true if the array contains no elements, false otherwise
     
        return size == 0
    def stream(self):
        """* Returns a sequential stream with this collection as its source.
     *
     * @return a stream of the elements in the array"""
        # 
     * Returns a sequential stream with this collection as its source.
     *
     * @return a stream of the elements in the array
     
        return StreamSupport.stream(spliterator(), false)
    def ensureCapacity(self, minCapacity):
        """* Ensures that the array has enough capacity to hold the specified number of elements.
     *
     * @param minCapacity the minimum capacity required"""
        # 
     * Ensures that the array has enough capacity to hold the specified number of elements.
     *
     * @param minCapacity the minimum capacity required
     
        if minCapacity > elements.length:
            newCapacity = Math.max(elements.length * 2, minCapacity)
            elements = Arrays.copyOf(elements, newCapacity)
    def fastRemove(self, index):
        """* Removes the element at the specified index without resizing the array.
     * This method shifts any subsequent elements to the left and clears the last element.
     *
     * @param index the index of the element to remove"""
        # 
     * Removes the element at the specified index without resizing the array.
     * This method shifts any subsequent elements to the left and clears the last element.
     *
     * @param index the index of the element to remove
     
        numMoved = size - index - 1
        if numMoved > 0:
            System.arraycopy(elements, index + 1, elements, index, numMoved)
        elements[--size] = null
    def toString(self):
        """* Returns a string representation of the array, including only the elements that are currently stored.
     *
     * @return a string containing the elements in the array"""
        # 
     * Returns a string representation of the array, including only the elements that are currently stored.
     *
     * @return a string containing the elements in the array
     
        # expr: Override
        return Arrays.toString(Arrays.copyOf(elements, size))
    def iterator(self):
        """* Returns an iterator over the elements in this array in proper sequence.
     *
     * @return an Iterator over the elements in the array"""
        # 
     * Returns an iterator over the elements in this array in proper sequence.
     *
     * @return an Iterator over the elements in the array
     
        # expr: Override
        return new DynamicArrayIterator()

    class DynamicArrayIterator:
        """* Private iterator class for the DynamicArray."""
        def __init__(self):
            """* Constructs a new iterator for the dynamic array."""
            # 
         * Constructs a new iterator for the dynamic array.
         
            self.expectedModCount = modCount
        def hasNext(self):
            """* Checks if there are more elements in the iteration.
         *
         * @return true if there are more elements, false otherwise"""
            # 
         * Checks if there are more elements in the iteration.
         *
         * @return true if there are more elements, false otherwise
         
            # expr: Override
            checkForComodification()
            return cursor < size
        def next(self):
            """* Returns the next element in the iteration.
         *
         * @return the next element in the iteration
         * @throws NoSuchElementException if the iteration has no more elements"""
            # 
         * Returns the next element in the iteration.
         *
         * @return the next element in the iteration
         * @throws NoSuchElementException if the iteration has no more elements
         
            # expr: Override
            # expr: SuppressWarnings
            checkForComodification()
            if cursor >= size:
                raise NoSuchElementException()
            return (E) elements[cursor++]
        def remove(self):
            """* Removes the last element returned by this iterator.
         *
         * @throws IllegalStateException if the next method has not yet been called, or the remove method has already been called after the last call to the next method"""
            # 
         * Removes the last element returned by this iterator.
         *
         * @throws IllegalStateException if the next method has not yet been called, or the remove method has already been called after the last call to the next method
         
            # expr: Override
            if cursor <= 0:
                raise IllegalStateException("Cannot remove element before calling next()")
            checkForComodification()
            DynamicArray.self.remove(--cursor)
            expectedModCount = modCount
        def checkForComodification(self):
            """* Checks for concurrent modifications to the array during iteration.
         *
         * @throws ConcurrentModificationException if the array has been modified structurally"""
            # 
         * Checks for concurrent modifications to the array during iteration.
         *
         * @throws ConcurrentModificationException if the array has been modified structurally
         
            if modCount != expectedModCount:
                raise ConcurrentModificationException()
        def forEachRemaining(self, action):
            """* Performs the given action for each remaining element in the iterator until all elements have been processed.
         *
         * @param action the action to be performed for each element
         * @throws NullPointerException if the specified action is null"""
            # 
         * Performs the given action for each remaining element in the iterator until all elements have been processed.
         *
         * @param action the action to be performed for each element
         * @throws NullPointerException if the specified action is null
         
            # expr: Override
            assert action is not None
            while hasNext():
                action.accept(next())

if __name__ == "__main__":
    pass
