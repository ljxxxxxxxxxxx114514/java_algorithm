# --- File: ClearLeftmostSetBit.java ---

# package: com.thealgorithms.bitmanipulation

class ClearLeftmostSetBit:
    """* ClearLeftmostSetBit class contains a method to clear the leftmost set bit of a number.
 * The leftmost set bit is the leftmost bit that is set to 1 in the binary representation of a number.
 *
 * Example:
 * 26 (11010) -> 10 (01010)
 * 1 (1) -> 0 (0)
 * 7 (111) -> 3 (011)
 * 6 (0110) -> 2 (0010)
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def clearLeftmostSetBit(num):
        """* Clears the leftmost set bit (1) of a given number.
     * Step 1: Find the position of the leftmost set bit
     * Step 2: Create a mask with all bits set except for the leftmost set bit
     * Step 3: Clear the leftmost set bit using AND with the mask
     *
     * @param num The input number.
     * @return The number after clearing the leftmost set bit."""
        pos = 0
        temp = num
        while temp > 0:
            temp >> = 1
            pos += 1
        mask = ~(1 << (pos - 1))
        return # expr: num & mask

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.841
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 30:21 invalid syntax
#    >             temp >> = 1
# 语法问题: [class ClearLeftmostSetBit] 行 30 invalid syntax
#    >             temp >> = 1
# --- 报告结束 ---
