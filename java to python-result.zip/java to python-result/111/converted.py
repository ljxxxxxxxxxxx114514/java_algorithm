# --- File: CentroidDecomposition.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.Arrays

# import: java.util.List

class CentroidDecomposition:
    """* Centroid Decomposition is a divide-and-conquer technique for trees.
 * It recursively partitions a tree by finding centroids - nodes whose removal
 * creates balanced subtrees (each with at most N/2 nodes).
 *
 * <p>
 * Time Complexity: O(N log N) for construction
 * Space Complexity: O(N)
 *
 * <p>
 * Applications:
 * - Distance queries on trees
 * - Path counting problems
 * - Nearest neighbor searches
 *
 * @see <a href="https://en.wikipedia.org/wiki/Centroid_decomposition">Centroid Decomposition</a>
 * @see <a href="https://codeforces.com/blog/entry/81661">Centroid Decomposition Tutorial</a>
 * @author lens161"""
    def __init__(self):
        pass
    @staticmethod
    def buildFromEdges(n, edges):
        """* Creates a centroid tree from an edge list.
     *
     * @param n number of nodes (0-indexed: 0 to n-1)
     * @param edges list of edges where each edge is [u, v]
     * @return CentroidTree object
     * @throws IllegalArgumentException if n &lt;= 0 or edges is invalid"""
        if n < = 0:
            raise ValueError("Number of nodes must be positive")
        if edges == None:
            raise ValueError("Edges cannot be null")
        if edges.length != n - 1:
            raise ValueError("Tree must have exactly n-1 edges")
        adj = list()
        for i in range(n):
            adj.append(list())
        for edge in edges:
            if edge.length != 2:
                raise ValueError("Each edge must have exactly 2 nodes")
            u = edge[0]
            v = edge[1]
            if u < 0 or u > = n or v < 0 or v >= n:
                raise ValueError("Invalid node in edge: [" + u + ", " + v + "]")
            adj[u].append(v)
            adj[v].append(u)
        return CentroidTree(adj)

    class CentroidTree:
        """* Represents the centroid tree structure."""
        def __init__(self, adj):
            """* Constructs a centroid tree from an adjacency list.
         *
         * @param adj adjacency list representation of the tree (0-indexed)
         * @throws IllegalArgumentException if tree is empty or null"""
            if adj == None or (not adj):
                raise ValueError("Tree cannot be empty or null")
            self.n = len(adj)
            self.adj = adj
            self.parent =  new int[n]
            self.subtreeSize =  new int[n]
            self.removed =  new boolean[n]
            Arrays.fill(parent, -1)
            self.root = decompose(0, -1)
        def decompose(self, u, p):
            """* Recursively builds the centroid tree.
         *
         * @param u current node
         * @param p parent in centroid tree
         * @return centroid of current component"""
            size = getSubtreeSize(u, -1)
            centroid = findCentroid(u, -1, size)
            removed[centroid] = True
            parent[centroid] = p
            for v in self.adj[centroid]:
                if not removed[v]:
                    decompose(v, centroid)
            return centroid
        def getSubtreeSize(self, u, p):
            """* Calculates subtree size from node u.
         *
         * @param u current node
         * @param p parent node (-1 for root)
         * @return size of subtree rooted at u"""
            subtreeSize[u] = 1
            for v in self.adj[u]:
                if v != p and not removed[v]:
                    subtreeSize[u] + = getSubtreeSize(v, u)
            return subtreeSize[u]
        def findCentroid(self, u, p, totalSize):
            """* Finds the centroid of a subtree.
         * A centroid is a node whose removal creates components with size &lt;= totalSize/2.
         *
         * @param u current node
         * @param p parent node
         * @param totalSize total size of current component
         * @return centroid node"""
            for v in self.adj[u]:
                if v != p and not removed[v] and subtreeSize[v] > totalSize / 2:
                    return findCentroid(v, u, totalSize)
            return u
        def getParent(self, node):
            """* Gets the parent of a node in the centroid tree.
         *
         * @param node the node
         * @return parent node in centroid tree, or -1 if root"""
            if node < 0 or node > = n:
                raise ValueError("Invalid node: " + node)
            return parent[node]
        def getRoot(self):
            """* Gets the root of the centroid tree.
         *
         * @return root node"""
            return self.root
        def size(self):
            """* Gets the number of nodes in the tree.
         *
         * @return number of nodes"""
            return self.n
        def toString(self):
            """* Returns the centroid tree structure as a string.
         * Format: node -&gt; parent (or ROOT for root node)
         *
         * @return string representation"""
            Override
            sb = StringBuilder("Centroid Tree:\n")
            for i in range(self.n):
                sb.append("Node ").append(i).append(" -> ")
                if parent[i] == -1:
                    sb.append("ROOT")
                else:
                    sb.append("Parent ").append(parent[i])
                sb.append("\n")
            return sb.toString()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.946
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 39:16 invalid syntax
#    >         if n < = 0:
# 语法问题: [class CentroidDecomposition] 行 39 invalid syntax
#    >         if n < = 0:
# 未映射方法(Top):
#  - StringBuilder.append: 4
# --- 报告结束 ---
