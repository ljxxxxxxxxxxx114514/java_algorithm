# --- File: CountSinglyLinkedListRecursion.java ---

# package: com.thealgorithms.datastructures.lists

class CountSinglyLinkedListRecursion:
    """* CountSinglyLinkedListRecursion extends a singly linked list to include a
 * recursive count method, which calculates the number of nodes in the list."""
    def countRecursion(self, head):
        """* Recursively calculates the number of nodes in the list.
     *
     * @param head the head node of the list segment being counted.
     * @return the count of nodes from the given head node onward."""
        return 0 if head == None else 1 + countRecursion(head.next)
    def count(self):
        """* Returns the total number of nodes in the list by invoking the recursive
     * count helper method.
     *
     * @return the total node count in the list."""
        Override
        return countRecursion(getHead())

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.875
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
