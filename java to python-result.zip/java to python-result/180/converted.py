# --- File: NextHigherSameBitCount.java ---

# package: com.thealgorithms.bitmanipulation

class NextHigherSameBitCount:
    """* This class provides a method to find the next higher number
 * with the same number of set bits as the given number.
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def nextHigherSameBitCount(n):
        """* Finds the next higher integer with the same number of set bits.
     * Steps:
     * 1. Find {@code c}, the rightmost set bit of {@code n}.
     * 2. Find {@code r}, the rightmost set bit of {@code n + c}.
     * 3. Swap the bits of {@code r} and {@code n} to the right of {@code c}.
     * 4. Shift the bits of {@code r} and {@code n} to the right of {@code c} to the rightmost.
     * 5. Combine the results of steps 3 and 4.
     *
     * @param n the input number
     * @return the next higher integer with the same set bit count"""
        c = n & -n
        r = n + c
        return (((r ^ n) >> 2) / c) | r

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.750
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
