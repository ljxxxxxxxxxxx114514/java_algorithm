# --- File: Bag.java ---

# package: com.thealgorithms.datastructures.bags

# import: java.util.Iterator

# import: java.util.NoSuchElementException

class Bag:
    """* A generic collection that allows adding and iterating over elements but does not support
 * element removal. This class implements a simple bag data structure, which can hold duplicate
 * elements and provides operations to check for membership and the size of the collection.
 *
 * <p>Bag is not thread-safe and should not be accessed by multiple threads concurrently.
 *
 * @param <E> the type of elements in this bag"""
    def __init__(self):
        """* Constructs an empty bag.
     * <p>This initializes the bag with zero elements."""
        # 
     * Constructs an empty bag.
     * <p>This initializes the bag with zero elements.
     
        firstElement = null
        size = 0
    def isEmpty(self):
        """* Checks if the bag is empty.
     *
     * @return {@code true} if the bag contains no elements; {@code false} otherwise"""
        # 
     * Checks if the bag is empty.
     *
     * @return {@code true} if the bag contains no elements; {@code false} otherwise
     
        return size == 0
    def size(self):
        """* Returns the number of elements in the bag.
     *
     * @return the number of elements currently in the bag"""
        # 
     * Returns the number of elements in the bag.
     *
     * @return the number of elements currently in the bag
     
        return size
    def add(self, element):
        """* Adds an element to the bag.
     *
     * <p>This method adds the specified element to the bag. Duplicates are allowed, and the
     * bag will maintain the order in which elements are added.
     *
     * @param element the element to add; must not be {@code null}"""
        # 
     * Adds an element to the bag.
     *
     * <p>This method adds the specified element to the bag. Duplicates are allowed, and the
     * bag will maintain the order in which elements are added.
     *
     * @param element the element to add; must not be {@code null}
     
        newNode = Node()
        newNode.content = element
        newNode.nextElement = firstElement
        firstElement = newNode
        size += 1
    def contains(self, element):
        """* Checks if the bag contains a specific element.
     *
     * <p>This method uses the {@code equals} method of the element to determine membership.
     *
     * @param element the element to check for; must not be {@code null}
     * @return {@code true} if the bag contains the specified element; {@code false} otherwise"""
        # 
     * Checks if the bag contains a specific element.
     *
     * <p>This method uses the {@code equals} method of the element to determine membership.
     *
     * @param element the element to check for; must not be {@code null}
     * @return {@code true} if the bag contains the specified element; {@code false} otherwise
     
        for value in this:
            if value.equals(element):
                return true
        return false
    def iterator(self):
        """* Returns an iterator over the elements in this bag.
     *
     * <p>The iterator provides a way to traverse the elements in the order they were added.
     *
     * @return an iterator that iterates over the elements in the bag"""
        # 
     * Returns an iterator over the elements in this bag.
     *
     * <p>The iterator provides a way to traverse the elements in the order they were added.
     *
     * @return an iterator that iterates over the elements in the bag
     
        # expr: Override
        return new ListIterator<>(firstElement)

    class Node:
        """Node class representing each element in the bag"""

        def __init__(self):
            self.content = None
            self.nextElement = None

    class ListIterator:
        """Private class for iterating over elements"""
        def __init__(self, firstElement):
            """* Constructs a ListIterator starting from the given first element.
         *
         * @param firstElement the first element of the bag to iterate over"""
            # 
         * Constructs a ListIterator starting from the given first element.
         *
         * @param firstElement the first element of the bag to iterate over
         
            self.currentElement = firstElement
        def hasNext(self):
            """* Checks if there are more elements to iterate over.
         *
         * @return {@code true} if there are more elements; {@code false} otherwise"""
            # 
         * Checks if there are more elements to iterate over.
         *
         * @return {@code true} if there are more elements; {@code false} otherwise
         
            # expr: Override
            return currentElement != null
        def next(self):
            """* Returns the next element in the iteration.
         *
         * @return the next element in the bag
         * @throws NoSuchElementException if there are no more elements to return"""
            # 
         * Returns the next element in the iteration.
         *
         * @return the next element in the bag
         * @throws NoSuchElementException if there are no more elements to return
         
            # expr: Override
            if !hasNext():
                raise NoSuchElementException("No more elements in the bag.")
            element = currentElement.content
            currentElement = currentElement.nextElement
            return element

if __name__ == "__main__":
    pass
