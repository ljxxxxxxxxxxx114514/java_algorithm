# --- File: CheckBinaryTreeIsValidBST.java ---

# package: com.thealgorithms.datastructures.trees

class CheckBinaryTreeIsValidBST:
    """* This code recursively validates whether given Binary Search Tree (BST) is balanced or not.
 * Trees with only distinct values are supported.
 * Key points:
 * 1. According to the definition of a BST, each node in a tree must be in range [min, max],
 *    where 'min' and 'max' values represent the child nodes (left, right).
 * 2. The smallest possible node value is Integer.MIN_VALUE, the biggest - Integer.MAX_VALUE."""
    def __init__(self):
        pass
    @staticmethod
    def isBST(root):
        return isBSTUtil(root, Integer.MIN_VALUE, Integer.MAX_VALUE)
    @staticmethod
    def isBSTUtil(node, min, max):
        if node == None:
            return True
        if node.data < min or node.data > max:
            return False
        return (isBSTUtil(node.left, min, node.data - 1) and isBSTUtil(node.right, node.data + 1, max))

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.841
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
