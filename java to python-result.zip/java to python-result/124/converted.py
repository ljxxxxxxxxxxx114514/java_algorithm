# --- File: PostOrderTraversal.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayDeque

# import: java.util.ArrayList

# import: java.util.Deque

# import: java.util.LinkedList

# import: java.util.List

class PostOrderTraversal:
    """* Given tree is traversed in a 'post-order' way: LEFT -> RIGHT -> ROOT.
 * Below are given the recursive and iterative implementations.
 * <p>
 * Complexities:
 * Recursive: O(n) - time, O(n) - space, where 'n' is the number of nodes in a tree.
 * <p>
 * Iterative: O(n) - time, O(h) - space, where 'n' is the number of nodes in a tree
 * and 'h' is the height of a binary tree.
 * In the worst case 'h' can be O(n) if tree is completely unbalanced, for instance:
 * 5
 *  \
 *   6
 *    \
 *     7
 *      \
 *       8
 *
 * @author Albina Gimaletdinova on 21/02/2023"""
    def __init__(self):
        pass
    @staticmethod
    def recursivePostOrder(root):
        result = list()
        recursivePostOrder(root, result)
        return result
    @staticmethod
    def iterativePostOrder(root):
        result = LinkedList()
        if root == None:
            return result
        stack = ArrayDeque()
        stack.push(root)
        while not (not stack):
            node = stack.pop()
            result.insert(0, ...)(node.data)
            if node.left != None:
                stack.push(node.left)
            if node.right != None:
                stack.push(node.right)
        return result
    @staticmethod
    def recursivePostOrder(root, result):
        if root == None:
            return
        recursivePostOrder(root.left, result)
        recursivePostOrder(root.right, result)
        result.append(root.data)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.828
# 可解析度: 1.000 (2/2)
# 未映射方法(Top):
#  - Deque.push: 3
# --- 报告结束 ---
