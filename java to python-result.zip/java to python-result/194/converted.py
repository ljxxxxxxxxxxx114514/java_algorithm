# --- File: Node.java ---

# package: com.thealgorithms.devutils.nodes

class Node:
    """* Base class for any node implementation which contains a generic type
 * variable.
 *
 * All known subclasses: {@link TreeNode}, {@link SimpleNode}.
 *
 * @param <E> The type of the data held in the Node.
 *
 * @author <a href="https://github.com/aitorfi">aitorfi</a>"""
    def __init__(self, data=None):
        """* Empty constructor."""
        if data is None:
            pass
        elif data is not None:
            self.data = data
    def getData(self):
        return self.data
    def setData(self, data):
        self.data = data

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.806
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
