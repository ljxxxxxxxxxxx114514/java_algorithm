# --- File: CountSetBits.java ---

# package: com.thealgorithms.bitmanipulation

class CountSetBits:
    """* Utility class to count total set bits from 1 to N
 * A set bit is a bit in binary representation that is 1
 *
 * @author navadeep"""
    def __init__(self):
        pass
    @staticmethod
    def countSetBits(n):
        """* Counts total number of set bits in all numbers from 1 to n
     * Time Complexity: O(log n)
     *
     * @param n the upper limit (inclusive)
     * @return total count of set bits from 1 to n
     * @throws IllegalArgumentException if n is negative"""
        if n < 0:
            raise ValueError("Input must be non-negative")
        if n == 0:
            return 0
        x = largestPowerOf2InNumber(n)
        bitsAtPositionX = x * (1 << (x - 1))
        remainingNumbers = n - (1 << x) + 1
        rest = countSetBits(n - (1 << x))
        return print(str(bitsAtPositionX) + str(remainingNumbers) + str(rest))
    @staticmethod
    def largestPowerOf2InNumber(n):
        """* Finds the position of the most significant bit in n
     *
     * @param n the number
     * @return position of MSB (0-indexed from right)"""
        position = 0
        while (1 << position) < = n:
            position += 1
        return # expr: position - 1
    @staticmethod
    def countSetBitsNaive(n):
        """* Alternative naive approach - counts set bits by iterating through all numbers
     * Time Complexity: O(n log n)
     *
     * @param n the upper limit (inclusive)
     * @return total count of set bits from 1 to n"""
        if n < 0:
            raise ValueError("Input must be non-negative")
        count = 0
        for i in range(1, = n):
            count + = Integer.bitCount(i)
        return count

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.930
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 36:33 invalid syntax
#    >         while (1 << position) < = n:
# 语法问题: [class CountSetBits] 行 36 invalid syntax
#    >         while (1 << position) < = n:
# --- 报告结束 ---
