# --- File: VerticalOrderTraversal.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.HashMap

# import: java.util.LinkedList

# import: java.util.Map

# import: java.util.Queue

class VerticalOrderTraversal:
    def __init__(self):
        pass
    @staticmethod
    def verticalTraversal(root):
        # Function that receives a root Node and prints the tree
        #         in Vertical Order.
        if root == None:
            return list()
        queue = LinkedList()
        index = LinkedList()
        map = HashMap()
        max = 0
        min = 0
        queue.append(root)
        index.append(0)
        while not (not queue):
            if queue.peek():
                queue.append(queue.peek().left)
                index.append(index.peek() - 1)
            if queue.peek():
                queue.append(queue.peek().right)
                index.append(index.peek() + 1)
            if not map.containsKey(index.peek()):
                a = list()
                map[index.peek()] = a
            map[index.peek()].append(queue.peek().data)
            max = Math.max(max, index.peek())
            min = Math.min(min, index.peek())
            index.poll()
            queue.poll()
        ans = list()
        for i in range(min, = max):
            ans.extend(map[i])
        return ans

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.851
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 47:29 invalid syntax
#    >         for i in range(min, = max):
# 语法问题: [class VerticalOrderTraversal] 行 47 invalid syntax
#    >         for i in range(min, = max):
# --- 报告结束 ---
