# --- File: HammingDistance.java ---

# package: com.thealgorithms.bitmanipulation

class HammingDistance:
    """* The Hamming distance between two integers is the number of positions at which the corresponding bits are different.
 * Given two integers x and y, calculate the Hamming distance.
 * Example:
 * Input: x = 1, y = 4
 * Output: 2
 * Explanation: 1 (0001) and 4 (0100) have 2 differing bits.
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def hammingDistance(x, y):
        """* Calculates the Hamming distance between two integers.
     * The Hamming distance is the number of differing bits between the two integers.
     *
     * @param x The first integer.
     * @param y The second integer.
     * @return The Hamming distance (number of differing bits)."""
        xor = x ^ y
        return Integer.bitCount(xor)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.708
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
