# --- File: LevelOrderTraversal.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.LinkedList

# import: java.util.List

# import: java.util.Queue

class LevelOrderTraversal:
    def __init__(self):
        pass
    @staticmethod
    def traverse(root):
        if root == None:
            return List.of()
        result = list()
        q = LinkedList()
        q.append(root)
        while not (not q):
            nodesOnLevel = len(q)
            level = LinkedList()
            for i in range(nodesOnLevel):
                tempNode = q.poll()
                level.append(tempNode.data)
                if tempNode.left != None:
                    q.append(tempNode.left)
                if tempNode.right != None:
                    q.append(tempNode.right)
            result.append(level)
        return result
    @staticmethod
    def printGivenLevel(root, level):
        #  Print nodes at the given level 
        if root == None:
            print("Root node must not be Nonenot Exiting.")
            return
        if level == 1:
            print(f"{str(root.data)} ", end="")

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.847
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
