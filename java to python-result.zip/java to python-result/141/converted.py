# --- File: ArrayCombination.java ---

# package: com.thealgorithms.backtracking

# import: java.util.ArrayList

# import: java.util.List

class ArrayCombination:
    """* This class provides methods to find all combinations of integers from 0 to n-1
 * of a specified length k using backtracking."""
    def __init__(self):
        pass
    @staticmethod
    def combination(n, k):
        """* Generates all possible combinations of length k from the integers 0 to n-1.
     *
     * @param n The total number of elements (0 to n-1).
     * @param k The desired length of each combination.
     * @return A list containing all combinations of length k.
     * @throws IllegalArgumentException if n or k are negative, or if k is greater than n."""
        if n < 0 or k < 0 or k > n:
            raise ValueError("Invalid input: n must be non-negative, k must be non-negative and less than or equal to n.")
        combinations = list()
        combine(combinations, list(), 0, n, k)
        return combinations
    @staticmethod
    def combine(combinations, current, start, n, k):
        """* A helper method that uses backtracking to find combinations.
     *
     * @param combinations The list to store all valid combinations found.
     * @param current The current combination being built.
     * @param start The starting index for the current recursion.
     * @param n The total number of elements (0 to n-1).
     * @param k The desired length of each combination."""
        if current.size():
            combinations.append(list(current))
            return
        for i in range(start, n):
            current.append(i)
            combine(combinations, current, i + 1, n, k)
            current.remove(len(current) - 1)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.829
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
