# --- File: InorderTraversal.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayDeque

# import: java.util.ArrayList

# import: java.util.Deque

# import: java.util.List

class InorderTraversal:
    """* Given tree is traversed in an 'inorder' way: LEFT -> ROOT -> RIGHT.
 * Below are given the recursive and iterative implementations.
 *
 * Complexities:
 * Recursive: O(n) - time, O(n) - space, where 'n' is the number of nodes in a tree.
 *
 * Iterative: O(n) - time, O(h) - space, where 'n' is the number of nodes in a tree
 * and 'h' is the height of a binary tree.
 * In the worst case 'h' can be O(n) if tree is completely unbalanced, for instance:
 * 5
 *  \
 *   6
 *    \
 *     7
 *      \
 *       8
 *
 * @author Albina Gimaletdinova on 21/02/2023"""
    def __init__(self):
        pass
    @staticmethod
    def recursiveInorder(root):
        result = list()
        recursiveInorder(root, result)
        return result
    @staticmethod
    def iterativeInorder(root):
        result = list()
        if root == None:
            return result
        stack = ArrayDeque()
        while not (not stack) or root != None:
            while root != None:
                stack.push(root)
                root = root.left
            root = stack.pop()
            result.append(root.data)
            root = root.right
        return result
    @staticmethod
    def recursiveInorder(root, result):
        if root == None:
            return
        recursiveInorder(root.left, result)
        result.append(root.data)
        recursiveInorder(root.right, result)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.842
# 可解析度: 1.000 (2/2)
# 未映射方法(Top):
#  - Deque.push: 1
#  - Deque.pop: 1
# --- 报告结束 ---
