# --- File: BellmanFord.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.Scanner

class BellmanFord:
    def __init__(self, v, e):
        vertex = v
        edge = e
        edges =  new Edge[e]
    def printPath(self, p, i):
        """* @param p[] Parent array which shows updates in edges
     * @param i   Current vertex under consideration"""
        # 
     * @param p[] Parent array which shows updates in edges
     * @param i   Current vertex under consideration
     
        if p[i] == -1:
            return
        printPath(p, p[i])
        print(f"{str(i)} ", end="")

def main(args=None):
    if args is None:
        args = []
    obj = BellmanFord(0, 0)
    obj.go()
def go(self):
    try:
        # expr: int i
        # expr: int v
        # expr: int e
        # expr: int u
        # expr: int ve
        # expr: int w
        # expr: int j
        neg = 0
        print("Enter no. of vertices and edges please")
        v = sc.nextInt()
        e = sc.nextInt()
        arr = new Edge[e]
        print("Input edges")
        for i in range(e):
            u = sc.nextInt()
            ve = sc.nextInt()
            w = sc.nextInt()
            arr[i] = Edge(u, ve, w)
        dist = new int[v]
        p = new int[v]
        for i in range(v):
            dist[i] = Integer.MAX_VALUE
        dist[0] = 0
        p[0] = -1
        for i in range(v - 1):
            for j in range(e):
                if dist[arr[j].u] != Integer.MAX_VALUE && dist[arr[j].v] > dist[arr[j].u] + arr[j].w:
                    print(f"{str(dist[arr[j].v] = dist[arr[j].u])}{str(arr[j].w)}")
                    p[arr[j].v] = arr[j].u
        for j in range(e):
            if dist[arr[j].u] != Integer.MAX_VALUE && dist[arr[j].v] > dist[arr[j].u] + arr[j].w:
                neg = 1
                print("Negative cycle")
                break
        if neg == 0:
            print("Distances are: ")
            for i in range(v):
                print(f"{str(i)} {str(dist[i])}")
            print("Path followed:")
            for i in range(v):
                print("0 ", end="")
                printPath(p, i)
                print()
def show(self, source, end, arr):
    """* @param source Starting vertex
 * @param end    Ending vertex
 * @param Edge   Array of edges"""
    # 
 * @param source Starting vertex
 * @param end    Ending vertex
 * @param Edge   Array of edges

    # expr: int i
    # expr: int j
    v = instance.vertex
    e = instance.edge
    neg = 0
    dist = new double[v]
    p = new int[v]
    for i in range(instance.v):
        dist[i] = Integer.MAX_VALUE
    dist[source] = 0
    p[source] = -1
    for i in range(v - 1):
        for j in range(instance.e):
            if (int) dist[arr[j].u] != Integer.MAX_VALUE && dist[arr[j].v] > dist[arr[j].u] + arr[j].w:
                print(f"{str(dist[arr[j].v] = dist[arr[j].u])}{str(arr[j].w)}")
                p[arr[j].v] = arr[j].u
    for j in range(instance.e):
        if (int) dist[arr[j].u] != Integer.MAX_VALUE && dist[arr[j].v] > dist[arr[j].u] + arr[j].w:
            neg = 1
            print("Negative cycle")
            break
    if neg == 0:
        print(f"Distance is: {str(dist[end])}")
        print("Path followed:")
        print(f"{str(source)} ", end="")
        printPath(p, end)
        print()
def addEdge(self, x, y, z):
    """* @param x Source Vertex
 * @param y End vertex
 * @param z Weight"""
    # 
 * @param x Source Vertex
 * @param y End vertex
 * @param z Weight

    edges[index++] = Edge(x, y, z)
def getEdgeArray(self):
    # Unhandled node type: ArrayType
    return edges

class Edge:
    def __init__(self, a, b, c):
        """* @param u Source Vertex
     * @param v End vertex
     * @param c Weight"""
        # 
     * @param u Source Vertex
     * @param v End vertex
     * @param c Weight

        u = a
        v = b
        w = c

if __name__ == "__main__":
    main()
