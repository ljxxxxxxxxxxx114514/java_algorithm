# --- File: SubsequenceFinder.java ---

# package: com.thealgorithms.backtracking

# import: java.util.ArrayList

# import: java.util.List

class SubsequenceFinder:
    """* Class generates all subsequences for a given list of elements using backtracking"""
    def __init__(self):
        pass
    @staticmethod
    def generateAll(sequence):
        """* Find all subsequences of given list using backtracking
     *
     * @param sequence a list of items on the basis of which we need to generate all subsequences
     * @param <T> the type of elements in the array
     * @return a list of all subsequences"""
        allSubSequences = list()
        if sequence.isEmpty():
            allSubSequences.append(list())
            return allSubSequences
        currentSubsequence = list()
        backtrack(sequence, currentSubsequence, 0, allSubSequences)
        return allSubSequences
    @staticmethod
    def backtrack(sequence, currentSubsequence, index, allSubSequences):
        """* Iterate through each branch of states
     * We know that each state has exactly two branching
     * It terminates when it reaches the end of the given sequence
     *
     * @param sequence all elements
     * @param currentSubsequence current subsequence
     * @param index current index
     * @param allSubSequences contains all sequences
     * @param <T> the type of elements which we generate"""
        # Unhandled node type: AssertStmt
        if index == len(sequence):
            allSubSequences.append(list(currentSubsequence))
            return
        backtrack(sequence, currentSubsequence, index + 1, allSubSequences)
        currentSubsequence.append(sequence[index])
        backtrack(sequence, currentSubsequence, index + 1, allSubSequences)
        currentSubsequence.removeLast()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.845
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
