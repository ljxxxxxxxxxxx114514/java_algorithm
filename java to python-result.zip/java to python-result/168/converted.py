# --- File: FindNthBit.java ---

# package: com.thealgorithms.bitmanipulation

class FindNthBit:
    """* A utility class to find the Nth bit of a given number.
 *
 * <p>This class provides a method to extract the value of the Nth bit (either 0 or 1)
 * from the binary representation of a given integer.
 *
 * <p>Example:
 * <pre>{@code
 * int result = FindNthBit.findNthBit(5, 2); // returns 0 as the 2nd bit of 5 (binary 101) is 0.
 * }</pre>
 *
 * <p>Author: <a href="https://github.com/Tuhinm2002">Tuhinm2002</a>"""
    def __init__(self):
        """* Private constructor to prevent instantiation.
     *
     * <p>This is a utility class, and it should not be instantiated.
     * Attempting to instantiate this class will throw an UnsupportedOperationException."""
        raise UnsupportedOperationException("Utility class")
    @staticmethod
    def findNthBit(num, n):
        """* Finds the value of the Nth bit of the given number.
     *
     * <p>This method uses bitwise operations to extract the Nth bit from the
     * binary representation of the given integer.
     *
     * @param num the integer number whose Nth bit is to be found
     * @param n   the bit position (1-based) to retrieve
     * @return    the value of the Nth bit (0 or 1)
     * @throws IllegalArgumentException if the bit position is less than 1"""
        if n < 1:
            raise ValueError("Bit position must be greater than or equal to 1.")
        return (num & (1 << (n - 1))) >> (n - 1)

# --- File: FirstDifferentBit.java ---

# package: com.thealgorithms.bitmanipulation

class FirstDifferentBit:
    """* This class provides a method to find the first differing bit
 * between two integers.
 *
 * Example:
 *  x = 10 (1010 in binary)
 *  y = 12 (1100 in binary)
 *  The first differing bit is at index 1 (0-based)
 *  So, the output will be 1
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def firstDifferentBit(x, y):
        """* Identifies the index of the first differing bit between two integers.
     * Steps:
     * 1. XOR the two integers to get the differing bits
     * 2. Find the index of the first set bit in XOR result
     *
     * @param x the first integer
     * @param y the second integer
     * @return the index of the first differing bit (0-based)"""
        diff = x ^ y
        return Integer.numberOfTrailingZeros(diff)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.821
# 可解析度: 1.000 (3/3)
# --- 报告结束 ---
