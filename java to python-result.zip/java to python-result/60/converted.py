# --- File: MaxHeap.java ---

# package: com.thealgorithms.datastructures.heaps

# import: java.util.ArrayList

# import: java.util.List

class MaxHeap:
    """* A Max Heap implementation where each node's key is higher than or equal to its children's keys.
 * This data structure provides O(log n) time complexity for insertion and deletion operations,
 * and O(1) for retrieving the maximum element.
 *
 * Properties:
 * 1. Complete Binary Tree
 * 2. Parent node's key ≥ Children nodes' keys
 * 3. Root contains the maximum element
 *
 * Example usage:
 * <pre>
 * List<HeapElement> elements = Arrays.asList(
 *     new HeapElement(5, "Five"),
 *     new HeapElement(2, "Two")
 * );
 * MaxHeap heap = new MaxHeap(elements);
 * heap.insertElement(new HeapElement(7, "Seven"));
 * HeapElement max = heap.getElement(); // Returns and removes the maximum element
 * </pre>
 *
 * @author Nicolas Renard"""
    def __init__(self, listElements):
        """* Constructs a new MaxHeap from a list of elements.
     * Null elements in the input list are ignored.
     *
     * @param listElements List of HeapElement objects to initialize the heap
     * @throws IllegalArgumentException if the input list is null"""
        if listElements == None:
            raise ValueError("Input list cannot be null")
        maxHeap = list()
        for heapElement in listElements:
            if heapElement != None:
                self.maxHeap.append(heapElement)
        for i in range(self.maxHeap.size(), = 0, -1):
            heapifyDown(i + 1)
    def heapifyDown(self, elementIndex):
        """* Maintains heap properties by moving an element down the heap.
     * Similar to toggleDown but used specifically during initialization.
     *
     * @param elementIndex 1-based index of the element to heapify"""
        largest = elementIndex - 1
        leftChild = 2 * elementIndex - 1
        rightChild = 2 * elementIndex
        if leftChild < len(maxHeap) and maxHeap[leftChild].getKey() > maxHeap[largest].getKey():
            largest = leftChild
        if rightChild < len(maxHeap) and maxHeap[rightChild].getKey() > maxHeap[largest].getKey():
            largest = rightChild
        if largest != elementIndex - 1:
            swap = maxHeap[elementIndex - 1]
            self.maxHeap[elementIndex - 1] = maxHeap[largest]
            self.maxHeap[largest] = swap
            heapifyDown(largest + 1)
    def getElement(self, elementIndex):
        """* Retrieves the element at the specified index without removing it.
     * Note: The index is 1-based for consistency with heap operations.
     *
     * @param elementIndex 1-based index of the element to retrieve
     * @return HeapElement at the specified index
     * @throws IndexOutOfBoundsException if the index is invalid"""
        if (elementIndex < = 0) or (elementIndex > len(maxHeap)):
            raise IndexOutOfBoundsException("Index " + elementIndex + " is out of heap range [1, " + maxHeap.size() + "]")
        return self.maxHeap[elementIndex - 1]
    def getElementKey(self, elementIndex):
        """* Retrieves the key value of an element at the specified index.
     *
     * @param elementIndex 1-based index of the element
     * @return double value representing the key
     * @throws IndexOutOfBoundsException if the index is invalid"""
        if (elementIndex < = 0) or (elementIndex > len(maxHeap)):
            raise IndexOutOfBoundsException("Index " + elementIndex + " is out of heap range [1, " + maxHeap.size() + "]")
        return self.maxHeap[elementIndex - 1].getKey()
    def swap(self, index1, index2):
        """* Swaps two elements in the heap.
     *
     * @param index1 1-based index of first element
     * @param index2 1-based index of second element"""
        temporaryElement = maxHeap[index1 - 1]
        self.maxHeap[index1 - 1] = maxHeap[index2 - 1]
        self.maxHeap[index2 - 1] = temporaryElement
    def toggleUp(self, elementIndex):
        """* Moves an element up the heap until heap properties are satisfied.
     * This operation is called after insertion to maintain heap properties.
     *
     * @param elementIndex 1-based index of the element to move up"""
        key = maxHeap[elementIndex - 1].getKey()
        while elementIndex > 1 and getElementKey((int) Math.floor(elementIndex / 2.0)) < key:
            swap(elementIndex, (int) Math.floor(elementIndex / 2.0))
            elementIndex = (int) Math.floor(elementIndex / 2.0)
    def toggleDown(self, elementIndex):
        """* Moves an element down the heap until heap properties are satisfied.
     * This operation is called after deletion to maintain heap properties.
     *
     * @param elementIndex 1-based index of the element to move down"""
        key = maxHeap[elementIndex - 1].getKey()
        wrongOrder = (2 * elementIndex <= len(maxHeap) and key < getElementKey(elementIndex * 2)) or (2 * elementIndex + 1 <= len(maxHeap) and key < getElementKey(elementIndex * 2 + 1))
        while 2 * elementIndex < = len(maxHeap) and wrongOrder:
            # expr: int largerChildIndex
            if 2 * elementIndex + 1 < = len(maxHeap) and getElementKey(elementIndex * 2 + 1) > getElementKey(elementIndex * 2):
                print(f"{str(largerChildIndex = 2 * elementIndex)}{str(1)}")
            else:
                largerChildIndex = 2 * elementIndex
            swap(elementIndex, largerChildIndex)
            elementIndex = largerChildIndex
            wrongOrder = (2 * elementIndex <= len(maxHeap) and key < getElementKey(elementIndex * 2)) or (2 * elementIndex + 1 <= len(maxHeap) and key < getElementKey(elementIndex * 2 + 1))
    def extractMax(self):
        """* Extracts and returns the maximum element from the heap.
     *
     * @return HeapElement with the highest key
     * @throws EmptyHeapException if the heap is empty"""
        if self.maxHeap.isEmpty():
            raise EmptyHeapException("Cannot extract from an empty heap")
        result = maxHeap.getFirst()
        deleteElement(1)
        return result
    def insertElement(self, element):
        """* {@inheritDoc}"""
        Override
        if element == None:
            raise ValueError("Cannot insert null element")
        self.maxHeap.append(element)
        toggleUp(len(maxHeap))
    def deleteElement(self, elementIndex):
        """* {@inheritDoc}"""
        Override
        if self.maxHeap.isEmpty():
            raise EmptyHeapException("Cannot delete from an empty heap")
        if (elementIndex > len(maxHeap)) or (elementIndex < = 0):
            raise IndexOutOfBoundsException("Index " + elementIndex + " is out of heap range [1, " + maxHeap.size() + "]")
        self.maxHeap[elementIndex - 1] = maxHeap.getLast()
        self.maxHeap.removeLast()
        if not (not maxHeap) and elementIndex < = len(maxHeap):
            if elementIndex > 1 and getElementKey(elementIndex) > getElementKey((int) Math.floor(elementIndex / 2.0)):
                toggleUp(elementIndex)
            else:
                toggleDown(elementIndex)
    def getElement(self):
        """* {@inheritDoc}"""
        Override
        return extractMax()
    def size(self):
        """* Returns the current size of the heap.
     *
     * @return number of elements in the heap"""
        return self.maxHeap.size()
    def isEmpty(self):
        """* Checks if the heap is empty.
     *
     * @return true if the heap contains no elements"""
        return self.maxHeap.isEmpty()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.960
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 43:45 invalid syntax
#    >         for i in range(self.maxHeap.size(), = 0, -1):
# 语法问题: [class MaxHeap] 行 43 invalid syntax
#    >         for i in range(self.maxHeap.size(), = 0, -1):
# 未处理节点类型(Top):
#  - ExpressionStmt: 1
# --- 报告结束 ---
