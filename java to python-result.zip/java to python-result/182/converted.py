# --- File: NumberAppearingOddTimes.java ---

# package: com.thealgorithms.bitmanipulation

class NumberAppearingOddTimes:
    def __init__(self):
        pass
    @staticmethod
    def findOddOccurrence(arr):
        """* Finds the element in the array that appears an odd number of times.
     *
     * @param arr the input array containing integers, where all elements
     *            except one appear an even number of times.
     * @return the integer that appears an odd number of times."""
        result = 0
        for num in arr:
            result ^ = num
        return result

# Unhandled node type: JavadocComment
#
#  * This class provides a method to find the element that appears an
#  * odd number of times in an array. All other elements in the array
#  * must appear an even number of times for the logic to work.
#  *
#  * The solution uses the XOR operation, which has the following properties:
#  * - a ^ a = 0 (XOR-ing the same numbers cancels them out)
#  * - a ^ 0 = a
#  * - XOR is commutative and associative.
#  *
#  * Time Complexity: O(n), where n is the size of the array.
#  * Space Complexity: O(1), as no extra space is used.
#  *
#  * Usage Example:
#  * int result = NumberAppearingOddTimes.findOddOccurrence(new int[]{1, 2, 1, 2, 3});
#  * // result will be 3
#  *
#  * @author Lakshyajeet Singh Goyal (https://github.com/DarkMatter-999)
#

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.781
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 17:22 invalid syntax
#    >             result ^ = num
# 语法问题: [class NumberAppearingOddTimes] 行 17 invalid syntax
#    >             result ^ = num
# --- 报告结束 ---
