# --- File: HashMapCuckooHashing.java ---

# package: com.thealgorithms.datastructures.hashmap.hashing

# import: java.util.Objects

class HashMapCuckooHashing:
    """* This class implements a hash table using Cuckoo Hashing.
 * Cuckoo hashing is a type of open-addressing hash table that resolves collisions
 * by relocating existing keys. It utilizes two hash functions to minimize collisions
 * and automatically resizes the table when the load factor exceeds 0.7.
 *
 * For more information on cuckoo hashing, refer to
 * <a href="https://en.wikipedia.org/wiki/Cuckoo_hashing">this Wikipedia page</a>."""
    def __init__(self, tableSize):
        """* Constructs a HashMapCuckooHashing object with the specified initial table size.
     *
     * @param tableSize the initial size of the hash map"""
        # 
     * Constructs a HashMapCuckooHashing object with the specified initial table size.
     *
     * @param tableSize the initial size of the hash map
     
        this.buckets =  new Integer[tableSize]
        self.tableSize = tableSize
        self.emptySlot = Integer.MIN_VALUE
        self.size = 0
        self.thresh = (int) (Math.log(tableSize) / Math.log(2)) + 2
    def hashFunction1(self, key):
        """* Computes the first hash index for a given key using the modulo operation.
     *
     * @param key the key for which the hash index is computed
     * @return an integer index corresponding to the key"""
        # 
     * Computes the first hash index for a given key using the modulo operation.
     *
     * @param key the key for which the hash index is computed
     * @return an integer index corresponding to the key
     
        hash = key % tableSize
        if hash < 0:
            print(f"{str(hash)}{str(= tableSize)}")
        return hash
    def hashFunction2(self, key):
        """* Computes the second hash index for a given key using integer division.
     *
     * @param key the key for which the hash index is computed
     * @return an integer index corresponding to the key"""
        # 
     * Computes the second hash index for a given key using integer division.
     *
     * @param key the key for which the hash index is computed
     * @return an integer index corresponding to the key
     
        hash = key / tableSize
        hash %= tableSize
        if hash < 0:
            print(f"{str(hash)}{str(= tableSize)}")
        return hash
    def insertKey2HashTable(self, key):
        """* Inserts a key into the hash table using cuckoo hashing.
     * If the target bucket is occupied, it relocates the existing key and attempts to insert
     * it into its alternate location. If the insertion process exceeds the threshold,
     * the table is resized.
     *
     * @param key the key to be inserted into the hash table
     * @throws IllegalArgumentException if the key already exists in the table"""
        # 
     * Inserts a key into the hash table using cuckoo hashing.
     * If the target bucket is occupied, it relocates the existing key and attempts to insert
     * it into its alternate location. If the insertion process exceeds the threshold,
     * the table is resized.
     *
     * @param key the key to be inserted into the hash table
     * @throws IllegalArgumentException if the key already exists in the table
     
        wrappedInt = key
        # expr: Integer temp
        # expr: int hash
        loopCounter = 0
        if isFull():
            print("Hash table is full, lengthening & rehashing table")
            reHashTableIncreasesTableSize()
        if checkTableContainsKey(key):
            raise ValueError("Key already exists; duplicates are not allowed.")
        while loopCounter <= thresh:
            loopCounter += 1
            hash = hashFunction1(key)
            if (buckets[hash] == null) || Objects.equals(buckets[hash], emptySlot):
                buckets[hash] = wrappedInt
                size += 1
                checkLoadFactor()
                return
            temp = buckets[hash]
            buckets[hash] = wrappedInt
            wrappedInt = temp
            hash = hashFunction2(temp)
            if Objects.equals(buckets[hash], emptySlot):
                buckets[hash] = wrappedInt
                size += 1
                checkLoadFactor()
                return
            else:
                buckets[hash] = wrappedInt
                size += 1
                checkLoadFactor()
                return
            temp = buckets[hash]
            buckets[hash] = wrappedInt
            wrappedInt = temp
        print("Infinite loop occurred, lengthening & rehashing table")
        reHashTableIncreasesTableSize()
        insertKey2HashTable(key)
    def reHashTableIncreasesTableSize(self):
        """* Rehashes the current table to a new size (double the current size) and reinserts existing keys."""
        # 
     * Rehashes the current table to a new size (double the current size) and reinserts existing keys.
     
        newT = HashMapCuckooHashing(tableSize * 2)
        for i in range(self.tableSize):
            if buckets[i] != null && !Objects.equals(buckets[i], emptySlot):
                newT.insertKey2HashTable(self.buckets[i])
        self.tableSize *= 2
        self.buckets = newT.buckets
        self.thresh = (int) (Math.log(tableSize) / Math.log(2)) + 2
    def deleteKeyFromHashTable(self, key):
        """* Deletes a key from the hash table, marking its position as available.
     *
     * @param key the key to be deleted from the hash table
     * @throws IllegalArgumentException if the table is empty or if the key is not found"""
        # 
     * Deletes a key from the hash table, marking its position as available.
     *
     * @param key the key to be deleted from the hash table
     * @throws IllegalArgumentException if the table is empty or if the key is not found
     
        wrappedInt = key
        hash = hashFunction1(key)
        if isEmpty():
            raise ValueError("Table is empty, cannot delete.")
        if Objects.equals(buckets[hash], wrappedInt):
            buckets[hash] = emptySlot
            size -= 1
            return
        hash = hashFunction2(key)
        if Objects.equals(buckets[hash], wrappedInt):
            buckets[hash] = emptySlot
            size -= 1
            return
        raise ValueError("Key " + key + " not found in the table.")
    def displayHashtable(self):
        """* Displays the hash table contents, bucket by bucket."""
        # 
     * Displays the hash table contents, bucket by bucket.
     
        for i in range(self.tableSize):
            if (buckets[i] == null) || Objects.equals(buckets[i], emptySlot):
                print(f"Bucket {str(i)}: Empty")
            else:
                print(f"Bucket {str(i)}: {str(buckets[i].toString())}")
        print()
    def findKeyInTable(self, key):
        """* Finds the index of a given key in the hash table.
     *
     * @param key the key to be found
     * @return the index where the key is located
     * @throws IllegalArgumentException if the table is empty or the key is not found"""
        # 
     * Finds the index of a given key in the hash table.
     *
     * @param key the key to be found
     * @return the index where the key is located
     * @throws IllegalArgumentException if the table is empty or the key is not found
     
        wrappedInt = key
        hash = hashFunction1(key)
        if isEmpty():
            raise ValueError("Table is empty; cannot find keys.")
        if Objects.equals(buckets[hash], wrappedInt):
            return hash
        hash = hashFunction2(key)
        if !Objects.equals(buckets[hash], wrappedInt):
            raise ValueError("Key " + key + " not found in the table.")
        else:
            return hash
    def checkTableContainsKey(self, key):
        """* Checks if the given key is present in the hash table.
     *
     * @param key the key to be checked
     * @return true if the key exists, false otherwise"""
        # 
     * Checks if the given key is present in the hash table.
     *
     * @param key the key to be checked
     * @return true if the key exists, false otherwise
     
        return ((buckets[hashFunction1(key)] != null && buckets[hashFunction1(key)].equals(key)) || (buckets[hashFunction2(key)] != null && buckets[hashFunction2(key)].equals(key)))
    def checkLoadFactor(self):
        """* Checks the load factor of the hash table. If the load factor exceeds 0.7,
     * the table is resized to prevent further collisions.
     *
     * @return the current load factor of the hash table"""
        # 
     * Checks the load factor of the hash table. If the load factor exceeds 0.7,
     * the table is resized to prevent further collisions.
     *
     * @return the current load factor of the hash table
     
        factor = (double) size / tableSize
        if factor > .7:
            print("Load factor is %.2f, rehashing table.%n", factor, end="")
            reHashTableIncreasesTableSize()
        return factor
    def isFull(self):
        """* Checks if the hash map is full.
     *
     * @return true if the hash map is full, false otherwise"""
        # 
     * Checks if the hash map is full.
     *
     * @return true if the hash map is full, false otherwise
     
        for i in range(self.tableSize):
            if buckets[i] == null || Objects.equals(buckets[i], emptySlot):
                return false
        return true
    def isEmpty(self):
        """* Checks if the hash map is empty.
     *
     * @return true if the hash map is empty, false otherwise"""
        # 
     * Checks if the hash map is empty.
     *
     * @return true if the hash map is empty, false otherwise
     
        for i in range(self.tableSize):
            if buckets[i] != null:
                return false
        return true
    def getNumberOfKeysInTable(self):
        """* Returns the current number of keys in the hash table.
     *
     * @return the number of keys present in the hash table"""
        # 
     * Returns the current number of keys in the hash table.
     *
     * @return the number of keys present in the hash table
     
        return size

if __name__ == "__main__":
    pass
