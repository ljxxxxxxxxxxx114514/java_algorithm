# --- File: Combination.java ---

# package: com.thealgorithms.backtracking

# import: java.util.Arrays

# import: java.util.Collections

# import: java.util.LinkedList

# import: java.util.List

# import: java.util.TreeSet

class Combination:
    """* Finds all combinations of a given array using backtracking algorithm * @author Alan Piao (<a href="https://github.com/cpiao3">git-Alan Piao</a>)"""
    def __init__(self):
        pass
    @staticmethod
    def combination(arr, n):
        """* Find all combinations of given array using backtracking
     * @param arr the array.
     * @param n length of combination
     * @param <T> the type of elements in the array.
     * @return a list of all combinations of length n. If n == 0, return null."""
        if n < 0:
            raise ValueError("The combination length cannot be negative.")
        if n == 0:
            return Collections.emptyList()
        array = arr.clone()
        sorted(array)
        result = LinkedList()
        backtracking(array, n, 0, TreeSet(), result)
        return result
    @staticmethod
    def backtracking(arr, n, index, currSet, result):
        """* Backtrack all possible combinations of a given array
     * @param arr the array.
     * @param n length of the combination
     * @param index the starting index.
     * @param currSet set that tracks current combination
     * @param result the list contains all combination.
     * @param <T> the type of elements in the array."""
        if index + n - len(currSet) > arr.length:
            return
        if currSet.size():
            for i in range(index, arr.length):
                currSet.append(arr[i])
                result.append(TreeSet(currSet))
                currSet.remove(arr[i])
            return
        for i in range(index, arr.length):
            currSet.append(arr[i])
            backtracking(arr, n, i + 1, currSet, result)
            currSet.remove(arr[i])

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.823
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
