# --- File: EMAFilter.java ---

# package: com.thealgorithms.audiofilters

class EMAFilter:
    """* Exponential Moving Average (EMA) Filter for smoothing audio signals.
 *
 * <p>This filter applies an exponential moving average to a sequence of audio
 * signal values, making it useful for smoothing out rapid fluctuations.
 * The smoothing factor (alpha) controls the degree of smoothing.
 *
 * <p>Based on the definition from
 * <a href="https://en.wikipedia.org/wiki/Moving_average">Wikipedia link</a>."""
    def __init__(self, alpha):
        """* Constructs an EMA filter with a given smoothing factor.
     *
     * @param alpha Smoothing factor (0 < alpha <= 1)
     * @throws IllegalArgumentException if alpha is not in (0, 1]"""
        if alpha < = 0 or alpha > 1:
            raise ValueError("Alpha must be between 0 and 1.")
        self.alpha = alpha
        self.emaValue = 0.0
    def apply(self, audioSignal):
        """* Applies the EMA filter to an audio signal array.
     *
     * @param audioSignal Array of audio samples to process
     * @return Array of processed (smoothed) samples"""
        # Unhandled node type: ArrayType
        if audioSignal.length == 0:
            return new double[0]
        emaSignal = new double[audioSignal.length]
        emaValue = audioSignal[0]
        emaSignal[0] = emaValue
        for i in range(1, audioSignal.length):
            emaValue = alpha * audioSignal[i] + (1 - alpha) * emaValue
            emaSignal[i] = emaValue
        return emaSignal

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.956
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 19:20 invalid syntax
#    >         if alpha < = 0 or alpha > 1:
# 语法问题: [class EMAFilter] 行 19 invalid syntax
#    >         if alpha < = 0 or alpha > 1:
# --- 报告结束 ---
