# --- File: IIRFilter.java ---

# package: com.thealgorithms.audiofilters

class IIRFilter:
    """* N-Order IIR Filter Assumes inputs are normalized to [-1, 1]
 *
 * Based on the difference equation from
 * <a href="https://en.wikipedia.org/wiki/Infinite_impulse_response">Wikipedia link</a>"""
    def __init__(self, order):
        """* Construct an IIR Filter
     *
     * @param order the filter's order
     * @throws IllegalArgumentException if order is zero or less"""
        if order < 1:
            raise ValueError("order must be greater than zero")
        self.order = order
        coeffsA =  new double[order + 1]
        coeffsB =  new double[order + 1]
        coeffsA[0] = 1.0
        coeffsB[0] = 1.0
        historyX =  new double[order]
        historyY =  new double[order]
    def setCoeffs(self, aCoeffs, bCoeffs):
        """* Set coefficients
     *
     * @param aCoeffs Denominator coefficients
     * @param bCoeffs Numerator coefficients
     * @throws IllegalArgumentException if {@code aCoeffs} or {@code bCoeffs} is
     * not of size {@code order}, or if {@code aCoeffs[0]} is 0.0"""
        if aCoeffs.length != order:
            raise ValueError("aCoeffs must be of size " + order + ", got " + aCoeffs.length)
        if aCoeffs[0] == 0.0:
            raise ValueError("aCoeffs.get(0) must not be zero")
        if bCoeffs.length != order:
            raise ValueError("bCoeffs must be of size " + order + ", got " + bCoeffs.length)
        for i in range(self.order):
            coeffsA[i] = aCoeffs[i]
            coeffsB[i] = bCoeffs[i]
    def process(self, sample):
        """* Process a single sample
     *
     * @param sample the sample to process
     * @return the processed sample"""
        result = 0.0
        for i in range(1, = order):
            result + = (coeffsB[i] * historyX[i - 1] - coeffsA[i] * historyY[i - 1])
        result = (result + coeffsB[0] * sample) / coeffsA[0]
        for i in range(# expr: order - 1, 0, -1):
            historyX[i] = historyX[i - 1]
            historyY[i] = historyY[i - 1]
        historyX[0] = sample
        historyY[0] = result
        return result

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.977
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 18:29 invalid syntax
#    >         coeffsA =  new double[order + 1]
# 语法问题: [class IIRFilter] 行 18 invalid syntax
#    >         coeffsA =  new double[order + 1]
# --- 报告结束 ---
