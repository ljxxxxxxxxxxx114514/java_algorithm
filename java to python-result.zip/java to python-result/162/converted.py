# --- File: BitwiseGCD.java ---

# package: com.thealgorithms.bitmanipulation

# import: java.math.BigInteger

class BitwiseGCD:
    """* Bitwise GCD implementation with full-range support utilities.
 *
 * <p>This class provides a fast binary (Stein's) GCD implementation for {@code long}
 * inputs and a BigInteger-backed API for full 2's-complement range support (including
 * {@code Long.MIN_VALUE}). The {@code long} implementation is efficient and avoids
 * division/modulo operations. For edge-cases that overflow signed-64-bit ranges
 * (e.g., gcd(Long.MIN_VALUE, 0) = 2^63), use the BigInteger API {@code gcdBig}.
 *
 * <p>Behaviour:
 * <ul>
 *   <li>{@code gcd(long,long)} : returns non-negative {@code long} gcd for inputs whose
 *       absolute values fit in signed {@code long} (i.e., not causing an unsigned 2^63 result).
 *       If the true gcd does not fit in a signed {@code long} (for example gcd(Long.MIN_VALUE,0) = 2^63)
 *       this method will delegate to BigInteger and throw {@link ArithmeticException} if the
 *       BigInteger result does not fit into a signed {@code long}.</li>
 *   <li>{@code gcdBig(BigInteger, BigInteger)} : returns the exact gcd as a {@link BigInteger}
 *       and works for the full signed-64-bit range and beyond.</li>
 * </ul>"""
    def __init__(self):
        pass
    @staticmethod
    def gcd(a=None, b=None, values=None):
        """* Computes GCD of two long values using Stein's algorithm (binary GCD).
     * <p>Handles negative inputs. If either input is {@code Long.MIN_VALUE} the
     * method delegates to the BigInteger implementation and will throw {@link ArithmeticException}
     * if the result cannot be represented as a signed {@code long}.
     *
     * @param a first value (may be negative)
     * @param b second value (may be negative)
     * @return non-negative gcd as a {@code long}
     * @throws ArithmeticException when the exact gcd does not fit into a signed {@code long}"""
        if a is not None and b is not None:
            if a == 0L:
                return absOrThrowIfOverflow(b)
            if b == 0L:
                return absOrThrowIfOverflow(a)
            if a == Long.MIN_VALUE or b == Long.MIN_VALUE:
                g = gcdBig(BigInteger.valueOf(a), BigInteger.valueOf(b))
                return g.longValueExact()
            -a if a = (a < 0) else a
            -b if b = (b < 0) else b
            commonTwos = Long.numberOfTrailingZeros(a | b)
            a >> = Long.numberOfTrailingZeros(a)
            while b != 0L:
                b >> = Long.numberOfTrailingZeros(b)
                if a > b:
                    tmp = a
                    a = b
                    b = tmp
                b = b - a
            return a << commonTwos
        elif values is not None:
            if values == None or values.length == 0:
                return # expr: 0L
            result = values[0]
            for i in range(1, values.length):
                result = gcd(result, values[i])
                if result == 1L:
                    return # expr: 1L
            return result
        elif a is not None and b is not None:
            return (int) gcd((long) a, (long) b)
    @staticmethod
    def absOrThrowIfOverflow(x):
        """* Helper to return absolute value of x unless x == Long.MIN_VALUE, in which
     * case we delegate to BigInteger and throw to indicate overflow."""
        if x == Long.MIN_VALUE:
            raise ArithmeticException("Absolute value of Long.MIN_VALUE does not fit into signed long. Use gcdBig() for full-range support.")
        return -x if (x < 0) else x
    @staticmethod
    def gcdBig(a=None, b=None):
        """* BigInteger-backed gcd that works for the full integer range (and beyond).
     * This is the recommended method when inputs may be Long.MIN_VALUE or when you
     * need an exact result even if it is greater than Long.MAX_VALUE.
     * @param a first value (may be negative)
     * @param b second value (may be negative)
     * @return non-negative gcd as a {@link BigInteger}"""
        if a is not None and b is not None:
            if a == None or b == None:
                raise TypeError("Arguments must not be null")
            return a.abs().gcd(b.abs())
        elif a is not None and b is not None:
            return gcdBig(BigInteger.valueOf(a), BigInteger.valueOf(b))

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.944
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 40:22 invalid syntax
#    >             if a == 0L:
# 语法问题: [class BitwiseGCD] 行 40 invalid syntax
#    >             if a == 0L:
# --- 报告结束 ---
