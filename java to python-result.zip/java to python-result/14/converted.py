# --- File: JohnsonsAlgorithm.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

# import: java.util.Arrays

# import: java.util.List

class JohnsonsAlgorithm:
    """* This class implements Johnson's algorithm for finding all-pairs shortest paths in a weighted,
 * directed graph that may contain negative edge weights.
 *
 * Johnson's algorithm works by using the Bellman-Ford algorithm to compute a transformation of the
 * input graph that removes all negative weights, allowing Dijkstra's algorithm to be used for
 * efficient shortest path computations.
 *
 * Time Complexity: O(V^2 * log(V) + V*E)
 * Space Complexity: O(V^2)
 *
 * Where V is the number of vertices and E is the number of edges in the graph.
 *
 * For more information, please visit {@link https://en.wikipedia.org/wiki/Johnson%27s_algorithm}"""
    INF: float = Double.POSITIVE_INFINITY
    def __init__(self):
        pass
    @staticmethod
    def johnsonAlgorithm(graph):
        """* Executes Johnson's algorithm on the given graph.
     * Steps:
     * 1. Add a new vertex to the graph and run Bellman-Ford to compute modified weights
     * 2. t the graph using the modified weights
     * 3. Run Dijkstra's algorithm for each vertex to compute the shortest paths
     * The final result is a 2D array of shortest distances between all pairs of vertices.
     *
     * @param graph The input graph represented as an adjacency matrix.
     * @return A 2D array representing the shortest distances between all pairs of vertices."""
        # 
     * Executes Johnson's algorithm on the given graph.
     * Steps:
     * 1. Add a new vertex to the graph and run Bellman-Ford to compute modified weights
     * 2. t the graph using the modified weights
     * 3. Run Dijkstra's algorithm for each vertex to compute the shortest paths
     * The final result is a 2D array of shortest distances between all pairs of vertices.
     *
     * @param graph The input graph represented as an adjacency matrix.
     * @return A 2D array representing the shortest distances between all pairs of vertices.
     
        # Unhandled node type: ArrayType
        numVertices = graph.length
        edges = convertToEdgeList(graph)
        modifiedWeights = bellmanFord(edges, numVertices)
        reweightedGraph = reweightGraph(graph, modifiedWeights)
        shortestDistances = new double[numVertices][numVertices]
        for source in range(self.numVertices):
            shortestDistances[source] = dijkstra(reweightedGraph, source, modifiedWeights)
        return shortestDistances
    @staticmethod
    def convertToEdgeList(graph):
        """* Converts the adjacency matrix representation of the graph to an edge list.
     *
     * @param graph The input graph as an adjacency matrix.
     * @return An array of edges, where each edge is represented as [from, to, weight]."""
        # 
     * Converts the adjacency matrix representation of the graph to an edge list.
     *
     * @param graph The input graph as an adjacency matrix.
     * @return An array of edges, where each edge is represented as [from, to, weight].
     
        # Unhandled node type: ArrayType
        numVertices = graph.length
        edgeList = []
        for i in range(self.numVertices):
            for j in range(self.numVertices):
                if i != j && !Double.isInfinite(graph[i][j]):
                    edgeList.append(new double[] { i, j, graph[i][j] })
        return edgeList.toArray(new double[0][])
    @staticmethod
    def bellmanFord(edges, numVertices):
        """* Implements the Bellman-Ford algorithm to compute the shortest paths from a new vertex
     * to all other vertices. This is used to calculate the weight function h(v) for reweighting.
     *
     * @param edges The edge list of the graph.
     * @param numVertices The number of vertices in the original graph.
     * @return An array of modified weights for each vertex."""
        # 
     * Implements the Bellman-Ford algorithm to compute the shortest paths from a new vertex
     * to all other vertices. This is used to calculate the weight function h(v) for reweighting.
     *
     * @param edges The edge list of the graph.
     * @param numVertices The number of vertices in the original graph.
     * @return An array of modified weights for each vertex.
     
        # Unhandled node type: ArrayType
        dist = new double[numVertices + 1]
        Arrays.fill(dist, INF)
        dist[numVertices] = 0
        allEdges = Arrays.copyOf(edges, edges.length + numVertices)
        for i in range(self.numVertices):
            allEdges[edges.length + i] =  new double[] { numVertices, i, 0 }
        for i in range(self.numVertices):
            for edge in allEdges:
                u = (int) edge[0]
                v = (int) edge[1]
                weight = edge[2]
                if dist[u] != INF && dist[u] + weight < dist[v]:
                    print(f"{str(dist[v] = dist[u])}{str(weight)}")
        for edge in allEdges:
            u = (int) edge[0]
            v = (int) edge[1]
            weight = edge[2]
            if dist[u] + weight < dist[v]:
                raise ValueError("Graph contains a negative weight cycle")
        return Arrays.copyOf(dist, numVertices)
    @staticmethod
    def reweightGraph(graph, modifiedWeights):
        """* Reweights the graph using the modified weights computed by Bellman-Ford.
     *
     * @param graph The original graph.
     * @param modifiedWeights The modified weights from Bellman-Ford.
     * @return The reweighted graph."""
        # 
     * Reweights the graph using the modified weights computed by Bellman-Ford.
     *
     * @param graph The original graph.
     * @param modifiedWeights The modified weights from Bellman-Ford.
     * @return The reweighted graph.
     
        # Unhandled node type: ArrayType
        numVertices = graph.length
        reweightedGraph = new double[numVertices][numVertices]
        for i in range(self.numVertices):
            for j in range(self.numVertices):
                if graph[i][j] != 0:
                    print(f"{str(reweightedGraph[i][j] = graph[i][j])}{str(modifiedWeights[i] - modifiedWeights[j])}")
        return reweightedGraph
    @staticmethod
    def dijkstra(reweightedGraph, source, modifiedWeights):
        """* Implements Dijkstra's algorithm for finding shortest paths from a source vertex.
     *
     * @param reweightedGraph The reweighted graph to run Dijkstra's on.
     * @param source The source vertex.
     * @param modifiedWeights The modified weights from Bellman-Ford.
     * @return An array of shortest distances from the source to all other vertices."""
        # 
     * Implements Dijkstra's algorithm for finding shortest paths from a source vertex.
     *
     * @param reweightedGraph The reweighted graph to run Dijkstra's on.
     * @param source The source vertex.
     * @param modifiedWeights The modified weights from Bellman-Ford.
     * @return An array of shortest distances from the source to all other vertices.
     
        # Unhandled node type: ArrayType
        numVertices = reweightedGraph.length
        dist = new double[numVertices]
        visited = new boolean[numVertices]
        Arrays.fill(dist, INF)
        dist[source] = 0
        for count in range(numVertices - 1):
            u = minDistance(dist, visited)
            visited[u] = true
            for v in range(self.numVertices):
                if !visited[v] && reweightedGraph[u][v] != 0 && dist[u] != INF && dist[u] + reweightedGraph[u][v] < dist[v]:
                    print(f"{str(dist[v] = dist[u])}{str(reweightedGraph[u][v])}")
        for i in range(self.numVertices):
            if dist[i] != INF:
                print(f"{str(dist[i] = dist[i] - modifiedWeights[source])}{str(modifiedWeights[i])}")
        return dist
    @staticmethod
    def minDistance(dist, visited):
        """* Finds the vertex with the minimum distance value from the set of vertices
     * not yet included in the shortest path tree.
     *
     * @param dist Array of distances.
     * @param visited Array of visited vertices.
     * @return The index of the vertex with minimum distance."""
        # 
     * Finds the vertex with the minimum distance value from the set of vertices
     * not yet included in the shortest path tree.
     *
     * @param dist Array of distances.
     * @param visited Array of visited vertices.
     * @return The index of the vertex with minimum distance.
     
        min = self.INF
        minIndex = -1
        for v in range(dist.length):
            if !visited[v] && dist[v] <= min:
                min = dist[v]
                minIndex = v
        return minIndex

if __name__ == "__main__":
    pass
