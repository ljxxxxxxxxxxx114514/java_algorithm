# --- File: BSTRecursive.java ---

# package: com.thealgorithms.datastructures.trees

# import: com.thealgorithms.datastructures.trees.BinaryTree.Node

class BSTRecursive:
    """*
 *
 * <h1>Binary Search Tree (Recursive)</h1>
 *
 * An implementation of BST recursively. In recursive implementation the checks
 * are down the tree First root is checked if not found then its children are
 * checked Binary Search Tree is a binary tree which satisfies three properties:
 * left child is less than root node, right child is grater than root node, both
 * left and right children must themselves be a BST.
 *
 * <p>
 * I have made public functions as methods and to actually implement recursive
 * approach I have used private methods
 *
 * @author [Lakhan Nad](<a href="https://github.com/Lakhan-Nad">git-Lakhan Nad</a>)"""
    def __init__(self):
        """* Constructor use to initialize node as null"""
        root = None
    def getRoot(self):
        return self.root
    def delete(self, node, data):
        """* Recursive method to delete a data if present in BST.
     *
     * @param node the current node to search for data
     * @param data the value to be deleted
     * @return Node the updated value of root parameter after delete operation"""
        if node == None:
            print("No such data present in BST.")
        return node
    def insert(self, node, data):
        """* Recursive insertion of value in BST.
     *
     * @param node to check if the data can be inserted in current node or its
     * subtree
     * @param data the value to be inserted
     * @return the modified value of the root parameter after insertion"""
        if node == None:
            node = Node(data)
        return node
    def search(self, node, data):
        """* Search recursively if the given value is present in BST or not.
     *
     * @param node the current node to check
     * @param data the value to be checked
     * @return boolean if data is present or not"""
        if node == None:
            return False
    def add(self, data):
        """* add in BST. if the value is not already present it is inserted or else no
     * change takes place.
     *
     * @param data the value to be inserted"""
        self.root = insert(self.root, data)
    def remove(self, data):
        """* If data is present in BST delete it else do nothing.
     *
     * @param data the value to be removed"""
        self.root = delete(self.root, data)
    def find(self, data):
        """* To check if given value is present in tree or not.
     *
     * @param data the data to be found for"""
        if search(self.root, data):
            print(f"{str(data)} is present in given BST.")
            return True
        print(f"{str(data)} not found.")
        return False

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.946
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
