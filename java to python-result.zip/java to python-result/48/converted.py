# --- File: LinearProbingHashMap.java ---

# package: com.thealgorithms.datastructures.hashmap.hashing

# import: java.util.ArrayList

class LinearProbingHashMap:
    """* This class implements a hash table using linear probing to resolve collisions.
 * Linear probing is a collision resolution method where each slot in the hash table is checked in a sequential manner
 * until an empty slot is found.
 *
 * <p>
 * The class allows for storing key-value pairs, where both the key and value are generic types.
 * The key must be of a type that implements the Comparable interface to ensure that the keys can be compared for sorting.
 * </p>
 *
 * <p>
 * This implementation supports basic operations such as:
 * <ul>
 *     <li><b>put(Key key, Value value)</b>: Adds a key-value pair to the hash table. If the key already exists, its value is updated.</li>
 *     <li><b>get(Key key)</b>: Retrieves the value associated with the given key.</li>
 *     <li><b>delete(Key key)</b>: Removes the key and its associated value from the hash table.</li>
 *     <li><b>contains(Key key)</b>: Checks if the hash table contains a given key.</li>
 *     <li><b>size()</b>: Returns the number of key-value pairs in the hash table.</li>
 *     <li><b>keys()</b>: Returns an iterable collection of keys stored in the hash table.</li>
 * </ul>
 * </p>
 *
 * <p>
 * The internal size of the hash table is automatically resized when the load factor exceeds 0.5 or falls below 0.125,
 * ensuring efficient space utilization.
 * </p>
 *
 * @see <a href="https://en.wikipedia.org/wiki/Linear_probing">Linear Probing Hash Table</a>
 *
 * @param <Key> the type of keys maintained by this map
 * @param <Value> the type of mapped values"""
    def __init__(self, size=None):
        """Default constructor initializes the table with a default size of 16"""
        if size is None:
            #  Default constructor initializes the table with a default size of 16
            # Unhandled node type: ExplicitConstructorInvocationStmt
        elif size is not None:
            # expr: SuppressWarnings
            self.hsize = size
            keys = (Key[]) new Comparable[size]
            values = (Value[]) new Object[size]
    def put(self, key, value):
        # expr: Override
        if key == null:
            return false
        if size > hsize / 2:
            resize(2 * hsize)
        keyIndex = hash(key, hsize)
        # for([]; keys[keyIndex] != null; [keyIndex = increment(keyIndex)])
            if key.equals(keys[keyIndex]):
                values[keyIndex] = value
                return true
        keys[keyIndex] = key
        values[keyIndex] = value
        size += 1
        return true
    def get(self, key):
        # expr: Override
        if key == null:
            return null
        # for([int i = hash(key, hsize)]; keys[i] != null; [i = increment(i)])
            if key.equals(keys[i]):
                return values[i]
        return null
    def delete(self, key):
        # expr: Override
        if key == null || !contains(key):
            return false
        i = hash(key, hsize)
        while !key.equals(keys[i]):
            i = increment(i)
        keys[i] = null
        values[i] = null
        i = increment(i)
        while keys[i] != null:
            keyToRehash = keys[i]
            valToRehash = values[i]
            keys[i] = null
            values[i] = null
            size -= 1
            put(keyToRehash, valToRehash)
            i = increment(i)
        size -= 1
        if size > 0 && size <= hsize / 8:
            resize(hsize / 2)
        return true
    def contains(self, key):
        # expr: Override
        return get(key) != null
    def size(self):
        # expr: Override
        return size
    def keys(self):
        # expr: Override
        listOfKeys = []
        for i in range(self.hsize):
            if keys[i] != null:
                listOfKeys.append(keys[i])
        listOfKeys.sort(Comparable::compareTo)
        return listOfKeys
    def increment(self, i):
        return (i + 1) % hsize
    def resize(self, newSize):
        LinearProbingHashMap<Key, Value> tmp = LinearProbingHashMap(newSize)
        for i in range(self.hsize):
            if keys[i] != null:
                tmp.put(keys[i], values[i])
        self.keys = tmp.keys
        self.values = tmp.values
        self.hsize = newSize

if __name__ == "__main__":
    pass
