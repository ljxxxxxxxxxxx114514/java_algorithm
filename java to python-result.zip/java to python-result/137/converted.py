# --- File: ZigzagTraversal.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayDeque

# import: java.util.ArrayList

# import: java.util.Deque

# import: java.util.LinkedList

# import: java.util.List

class ZigzagTraversal:
    """* Given a binary tree.
 * This code returns the zigzag level order traversal of its nodes' values.
 * Binary tree:
 *                               7
 *                   /                         \
 *                6                           3
 *         /                \             /             \
 *      2                    4         10                19
 * Zigzag traversal:
 * [[7], [3, 6], [2, 4, 10, 19]]
 * <p>
 * This solution implements the breadth-first search (BFS) algorithm using a queue.
 * 1. The algorithm starts with a root node. This node is added to a queue.
 * 2. While the queue is not empty:
 *  - each time we enter the while-loop we get queue size. Queue size refers to the number of nodes
 * at the current level.
 *  - we traverse all the level nodes in 2 ways: from left to right OR from right to left
 *    (this state is stored on `prevLevelFromLeftToRight` variable)
 *  - if the current node has children we add them to a queue
 *  - add level with nodes to a result.
 * <p>
 * Complexities:
 * O(N) - time, where N is the number of nodes in a binary tree
 * O(N) - space, where N is the number of nodes in a binary tree
 *
 * @author Albina Gimaletdinova on 11/01/2023"""
    def __init__(self):
        pass
    @staticmethod
    def traverse(root):
        if root == None:
            return List.of()
        result = list()
        q = ArrayDeque()
        q.offer(root)
        prevLevelFromLeftToRight = False
        while not (not q):
            nodesOnLevel = len(q)
            level = LinkedList()
            for i in range(nodesOnLevel):
                node = q.poll()
                if prevLevelFromLeftToRight:
                    level.append(0, node.data)
                else:
                    level.append(node.data)
                if node.left != None:
                    q.offer(node.left)
                if node.right != None:
                    q.offer(node.right)
            prevLevelFromLeftToRight = not prevLevelFromLeftToRight
            result.append(level)
        return result

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.817
# 可解析度: 1.000 (2/2)
# 未映射方法(Top):
#  - Deque.offer: 3
# --- 报告结束 ---
