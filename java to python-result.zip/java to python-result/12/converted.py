# --- File: Graphs.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

class AdjacencyListGraph:
    def __init__(self):
        vertices = []
    def removeEdge(self, from, to):
        """* this method removes an edge from the graph between two specified
     * vertices
     *
     * @param from the data of the vertex the edge is from
     * @param to the data of the vertex the edge is going to
     * @return returns false if the edge doesn't exist, returns true if the edge
     * exists and is removed"""
        # 
     * this method removes an edge from the graph between two specified
     * vertices
     *
     * @param from the data of the vertex the edge is from
     * @param to the data of the vertex the edge is going to
     * @return returns false if the edge doesn't exist, returns true if the edge
     * exists and is removed
     
        fromV = null
        for v in vertices:
            if from.compareTo(v.data) == 0:
                fromV = v
                break
        if fromV == null:
            return false
        return fromV.removeAdjacentVertex(to)
    def addEdge(self, from, to):
        """* this method adds an edge to the graph between two specified vertices
     *
     * @param from the data of the vertex the edge is from
     * @param to the data of the vertex the edge is going to
     * @return returns true if the edge did not exist, return false if it
     * already did"""
        # 
     * this method adds an edge to the graph between two specified vertices
     *
     * @param from the data of the vertex the edge is from
     * @param to the data of the vertex the edge is going to
     * @return returns true if the edge did not exist, return false if it
     * already did
     
        fromV = null
        toV = null
        for v in vertices:
            if from.compareTo(v.data) == 0:
                fromV = v
            else:
                toV = v
            if fromV != null && toV != null:
                break
        if fromV == null:
            fromV = Vertex(from)
            vertices.append(fromV)
        if toV == null:
            toV = Vertex(to)
            vertices.append(toV)
        return fromV.addAdjacentVertex(toV)
    def toString(self):
        """* this gives a list of vertices in the graph and their adjacencies
     *
     * @return returns a string describing this graph"""
        # 
     * this gives a list of vertices in the graph and their adjacencies
     *
     * @return returns a string describing this graph
     
        # expr: Override
        sb = StringBuilder()
        for v in vertices:
            sb.append("Vertex: ")
            sb.append(v.data)
            sb.append("\n")
            sb.append("Adjacent vertices: ")
            for v2 in v.adjacentVertices:
                sb.append(v2.data)
                sb.append(" ")
            sb.append("\n")
        return sb.toString()

    class Vertex:
        def __init__(self, data):
            adjacentVertices = []
            self.data = data
        def addAdjacentVertex(self, to):
            for v in adjacentVertices:
                if v.data.compareTo(to.data) == 0:
                    return false
            return adjacentVertices.add(to)
        def removeAdjacentVertex(self, to):
            for i in range(adjacentVertices.size()):
                if adjacentVertices.get(i).data.compareTo(to) == 0:
                    adjacentVertices.remove(i)
                    return true
            return false

class Graphs:
    def __init__(self):
        pass

def main(args=None):
    if args is None:
        args = []
    graph = AdjacencyListGraph()
    # Unhandled node type: AssertStmt
    print(graph)

if __name__ == "__main__":
    main()
