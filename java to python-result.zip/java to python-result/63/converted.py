# --- File: MinHeap.java ---

# package: com.thealgorithms.datastructures.heaps

# import: java.util.ArrayList

# import: java.util.List

class MinHeap:
    """* A Min Heap implementation where each node's key is lower than or equal to its children's keys.
 * This data structure provides O(log n) time complexity for insertion and deletion operations,
 * and O(1) for retrieving the minimum element.
 *
 * Properties:
 * 1. Complete Binary Tree
 * 2. Parent node's key ≤ Children nodes' keys
 * 3. Root contains the minimum element
 *
 * Example usage:
 * ```java
 * List<HeapElement> elements = Arrays.asList(
 *     new HeapElement(5, "Five"),
 *     new HeapElement(2, "Two")
 * );
 * MinHeap heap = new MinHeap(elements);
 * heap.insertElement(new HeapElement(1, "One"));
 * HeapElement min = heap.getElement(); // Returns and removes the minimum element
 * ```
 *
 * @author Nicolas Renard"""
    def __init__(self, listElements):
        """* Constructs a new MinHeap from a list of elements.
     * Null elements in the input list are ignored with a warning message.
     *
     * @param listElements List of HeapElement objects to initialize the heap
     * @throws IllegalArgumentException if the input list is null"""
        if listElements == None:
            raise ValueError("Input list cannot be null")
        minHeap = list()
        for heapElement in listElements:
            if heapElement != None:
                self.minHeap.append(heapElement)
            else:
                print("Null element. Not added to heap")
        for i in range(self.minHeap.size(), = 0, -1):
            heapifyDown(i + 1)
        if self.minHeap.isEmpty():
            print("No element has been added, empty heap.")
    def getElement(self, elementIndex):
        """* Retrieves the element at the specified index without removing it.
     * Note: The index is 1-based for consistency with heap operations.
     *
     * @param elementIndex 1-based index of the element to retrieve
     * @return HeapElement at the specified index
     * @throws IndexOutOfBoundsException if the index is invalid"""
        if (elementIndex < = 0) or (elementIndex > len(minHeap)):
            raise IndexOutOfBoundsException("Index " + elementIndex + " is out of heap range [1, " + minHeap.size() + "]")
        return self.minHeap[elementIndex - 1]
    def getElementKey(self, elementIndex):
        """* Retrieves the key value of an element at the specified index.
     *
     * @param elementIndex 1-based index of the element
     * @return double value representing the key
     * @throws IndexOutOfBoundsException if the index is invalid"""
        if (elementIndex < = 0) or (elementIndex > len(minHeap)):
            raise IndexOutOfBoundsException("Index " + elementIndex + " is out of heap range [1, " + minHeap.size() + "]")
        return self.minHeap[elementIndex - 1].getKey()
    def swap(self, index1, index2):
        """* Swaps two elements in the heap.
     *
     * @param index1 1-based index of first element
     * @param index2 1-based index of second element"""
        temporaryElement = minHeap[index1 - 1]
        self.minHeap[index1 - 1] = minHeap[index2 - 1]
        self.minHeap[index2 - 1] = temporaryElement
    def heapifyDown(self, elementIndex):
        """* Maintains heap properties by moving an element down the heap.
     * Used specifically during initialization.
     *
     * @param elementIndex 1-based index of the element to heapify"""
        smallest = elementIndex - 1
        leftChild = 2 * elementIndex - 1
        rightChild = 2 * elementIndex
        if leftChild < len(minHeap) and minHeap[leftChild].getKey() < minHeap[smallest].getKey():
            smallest = leftChild
        if rightChild < len(minHeap) and minHeap[rightChild].getKey() < minHeap[smallest].getKey():
            smallest = rightChild
        if smallest != elementIndex - 1:
            swap = minHeap[elementIndex - 1]
            self.minHeap[elementIndex - 1] = minHeap[smallest]
            self.minHeap[smallest] = swap
            heapifyDown(smallest + 1)
    def toggleUp(self, elementIndex):
        """* Moves an element up the heap until heap properties are satisfied.
     * This operation is called after insertion to maintain heap properties.
     *
     * @param elementIndex 1-based index of the element to move up"""
        if elementIndex < = 1:
            return
        key = minHeap[elementIndex - 1].getKey()
        parentIndex = (int) Math.floor(elementIndex / 2.0)
        while elementIndex > 1 and getElementKey(parentIndex) > key:
            swap(elementIndex, parentIndex)
            elementIndex = parentIndex
            parentIndex = (int) Math.floor(elementIndex / 2.0)
    def toggleDown(self, elementIndex):
        """* Moves an element down the heap until heap properties are satisfied.
     * This operation is called after deletion to maintain heap properties.
     *
     * @param elementIndex 1-based index of the element to move down"""
        key = minHeap[elementIndex - 1].getKey()
        size = len(minHeap)
        while True:
            smallest = elementIndex
            leftChild = 2 * elementIndex
            rightChild = 2 * elementIndex + 1
            if leftChild < = size and getElementKey(leftChild) < key:
                smallest = leftChild
            if rightChild < = size and getElementKey(rightChild) < getElementKey(smallest):
                smallest = rightChild
            if smallest == elementIndex:
                break
            swap(elementIndex, smallest)
            elementIndex = smallest
    def extractMin(self):
        """* Extracts and returns the minimum element from the heap.
     *
     * @return HeapElement with the lowest key
     * @throws EmptyHeapException if the heap is empty"""
        if self.minHeap.isEmpty():
            raise EmptyHeapException("Cannot extract from empty heap")
        result = minHeap.getFirst()
        deleteElement(1)
        return result
    def insertElement(self, element):
        """* {@inheritDoc}"""
        Override
        if element == None:
            raise ValueError("Cannot insert null element")
        self.minHeap.append(element)
        toggleUp(len(minHeap))
    def deleteElement(self, elementIndex):
        """* {@inheritDoc}"""
        Override
        if self.minHeap.isEmpty():
            raise EmptyHeapException("Cannot delete from empty heap")
        if (elementIndex > len(minHeap)) or (elementIndex < = 0):
            raise IndexOutOfBoundsException("Index " + elementIndex + " is out of heap range [1, " + minHeap.size() + "]")
        self.minHeap[elementIndex - 1] = minHeap.getLast()
        self.minHeap.removeLast()
        if not (not minHeap) and elementIndex < = len(minHeap):
            if elementIndex > 1 and getElementKey(elementIndex) < getElementKey((int) Math.floor(elementIndex / 2.0)):
                toggleUp(elementIndex)
            else:
                toggleDown(elementIndex)
    def getElement(self):
        """* {@inheritDoc}"""
        Override
        return extractMin()
    def size(self):
        """* Returns the current size of the heap.
     *
     * @return number of elements in the heap"""
        return self.minHeap.size()
    def isEmpty(self):
        """* Checks if the heap is empty.
     *
     * @return true if the heap contains no elements"""
        return self.minHeap.isEmpty()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.976
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 45:45 invalid syntax
#    >         for i in range(self.minHeap.size(), = 0, -1):
# 语法问题: [class MinHeap] 行 45 invalid syntax
#    >         for i in range(self.minHeap.size(), = 0, -1):
# --- 报告结束 ---
