# --- File: LRUCache.java ---

# package: com.thealgorithms.datastructures.caches

# import: java.util.HashMap

# import: java.util.Map

class LRUCache:
    """* A Least Recently Used (LRU) Cache implementation.
 *
 * <p>An LRU cache is a fixed-size cache that maintains items in order of use. When the cache reaches
 * its capacity and a new item needs to be added, it removes the least recently used item first.
 * This implementation provides O(1) time complexity for both get and put operations.</p>
 *
 * <p>Features:</p>
 * <ul>
 *   <li>Fixed-size cache with configurable capacity</li>
 *   <li>Constant time O(1) operations for get and put</li>
 *   <li>Thread-unsafe - should be externally synchronized if used in concurrent environments</li>
 *   <li>Supports null values but not null keys</li>
 * </ul>
 *
 * <p>Implementation Details:</p>
 * <ul>
 *   <li>Uses a HashMap for O(1) key-value lookups</li>
 *   <li>Maintains a doubly-linked list for tracking access order</li>
 *   <li>The head of the list contains the least recently used item</li>
 *   <li>The tail of the list contains the most recently used item</li>
 * </ul>
 *
 * <p>Example usage:</p>
 * <pre>
 * LRUCache<String, Integer> cache = new LRUCache<>(3); // Create cache with capacity 3
 * cache.put("A", 1); // Cache: A=1
 * cache.put("B", 2); // Cache: A=1, B=2
 * cache.put("C", 3); // Cache: A=1, B=2, C=3
 * cache.get("A");    // Cache: B=2, C=3, A=1 (A moved to end)
 * cache.put("D", 4); // Cache: C=3, A=1, D=4 (B evicted)
 * </pre>
 *
 * @param <K> the type of keys maintained by this cache
 * @param <V> the type of mapped values"""
    DEFAULT_CAP: int = 100
    def __init__(self, cap=None):
        if cap is None:
            setCapacity(DEFAULT_CAP)
        elif cap is not None:
            setCapacity(cap)
    def setCapacity(self, newCapacity):
        """* Returns the current capacity of the cache.
     *
     * @param newCapacity the new capacity of the cache"""
        # 
     * Returns the current capacity of the cache.
     *
     * @param newCapacity the new capacity of the cache
     
        checkCapacity(newCapacity)
        # for([int i = data.size()]; i > newCapacity; [i--])
            Entry<K, V> evicted = evict()
            data.pop(evicted.getKey())
        self.cap = newCapacity
    def evict(self):
        """* Evicts the least recently used item from the cache.
     *
     * @return the evicted entry"""
        # 
     * Evicts the least recently used item from the cache.
     *
     * @return the evicted entry
     
        if head == null:
            raise Exception("cache cannot be empty!")
        Entry<K, V> evicted = head
        head = evicted.getNextEntry()
        head.setPreEntry(null)
        evicted.setNextEntry(null)
        return evicted
    def checkCapacity(self, capacity):
        """* Checks if the capacity is valid.
     *
     * @param capacity the capacity to check"""
        # 
     * Checks if the capacity is valid.
     *
     * @param capacity the capacity to check
     
        if capacity <= 0:
            raise Exception("capacity must greater than 0!")
    def get(self, key):
        """* Returns the value to which the specified key is mapped, or null if this cache contains no
     * mapping for the key.
     *
     * @param key the key whose associated value is to be returned
     * @return the value to which the specified key is mapped, or null if this cache contains no
     * mapping for the key"""
        # 
     * Returns the value to which the specified key is mapped, or null if this cache contains no
     * mapping for the key.
     *
     * @param key the key whose associated value is to be returned
     * @return the value to which the specified key is mapped, or null if this cache contains no
     * mapping for the key
     
        if !data.containsKey(key):
            return null
        final Entry<K, V> entry = data.get(key)
        moveNodeToLast(entry)
        return entry.getValue()
    def moveNodeToLast(self, entry):
        """* Moves the specified entry to the end of the list.
     *
     * @param entry the entry to move"""
        # 
     * Moves the specified entry to the end of the list.
     *
     * @param entry the entry to move
     
        if tail == entry:
            return
        final Entry<K, V> preEntry = entry.getPreEntry()
        final Entry<K, V> nextEntry = entry.getNextEntry()
        if preEntry != null:
            preEntry.setNextEntry(nextEntry)
        if nextEntry != null:
            nextEntry.setPreEntry(preEntry)
        if head == entry:
            head = nextEntry
        tail.setNextEntry(entry)
        entry.setPreEntry(tail)
        entry.setNextEntry(null)
        tail = entry
    def put(self, key, value):
        """* Associates the specified value with the specified key in this cache.
     *
     * @param key the key with which the specified value is to be associated
     * @param value the value to be associated with the specified key"""
        # 
     * Associates the specified value with the specified key in this cache.
     *
     * @param key the key with which the specified value is to be associated
     * @param value the value to be associated with the specified key
     
        if data.containsKey(key):
            final Entry<K, V> existingEntry = data.get(key)
            existingEntry.setValue(value)
            moveNodeToLast(existingEntry)
            return
        # expr: Entry<K, V> newEntry
        if data.size() == cap:
            newEntry = evict()
            data.pop(newEntry.getKey())
        else:
            newEntry = Entry()
        newEntry.setKey(key)
        newEntry.setValue(value)
        addNewEntry(newEntry)
        data[key] = newEntry
    def addNewEntry(self, newEntry):
        """* Adds a new entry to the end of the list.
     *
     * @param newEntry the entry to add"""
        # 
     * Adds a new entry to the end of the list.
     *
     * @param newEntry the entry to add
     
        if data.isEmpty():
            head = newEntry
            tail = newEntry
            return
        tail.setNextEntry(newEntry)
        newEntry.setPreEntry(tail)
        newEntry.setNextEntry(null)
        tail = newEntry

    class Entry:
        def __init__(self, preEntry=None, nextEntry=None, key=None, value=None):
            if preEntry is None and nextEntry is None and key is None and value is None:
                pass
            elif preEntry is not None and nextEntry is not None and key is not None and value is not None:
                self.preEntry = preEntry
                self.nextEntry = nextEntry
                self.key = key
                self.value = value
        def getPreEntry(self):
            return preEntry
        def setPreEntry(self, preEntry):
            self.preEntry = preEntry
        def getNextEntry(self):
            return nextEntry
        def setNextEntry(self, nextEntry):
            self.nextEntry = nextEntry
        def getKey(self):
            return key
        def setKey(self, key):
            self.key = key
        def getValue(self):
            return value
        def setValue(self, value):
            self.value = value

if __name__ == "__main__":
    pass
