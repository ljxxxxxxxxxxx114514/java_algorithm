# --- File: OneBitDifference.java ---

# package: com.thealgorithms.bitmanipulation

class OneBitDifference:
    """* This class provides a method to detect if two integers
 * differ by exactly one bit flip.
 *
 * Example:
 * 1 (0001) and 2 (0010) differ by exactly one bit flip.
 * 7 (0111) and 3 (0011) differ by exactly one bit flip.
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def differByOneBit(x, y):
        """* Checks if two integers differ by exactly one bit.
     *
     * @param x the first integer
     * @param y the second integer
     * @return true if x and y differ by exactly one bit, false otherwise"""
        if x == y:
            return False
        xor = x ^ y
        return (xor & (xor - 1)) == 0

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.781
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
