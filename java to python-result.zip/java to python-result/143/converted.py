# --- File: CombinationSum.java ---

# package: com.thealgorithms.backtracking

# import: java.util.ArrayList

# import: java.util.Arrays

# import: java.util.List

class CombinationSum:
    """Backtracking: pick/not-pick with reuse of candidates."""
    def __init__(self):
        raise UnsupportedOperationException("Utility class")
    @staticmethod
    def combinationSum(candidates, target):
        results = list()
        if candidates == None or candidates.length == 0:
            return results
        sorted(candidates)
        backtrack(candidates, target, 0, list(), results)
        return results
    @staticmethod
    def backtrack(candidates, remaining, start, combination, results):
        if remaining == 0:
            results.append(list(combination))
            return
        for i in range(start, candidates.length):
            candidate = candidates[i]
            if candidate > remaining:
                break
            combination.append(candidate)
            backtrack(candidates, remaining - candidate, i, combination, results)
            combination.remove(len(combination) - 1)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.880
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
