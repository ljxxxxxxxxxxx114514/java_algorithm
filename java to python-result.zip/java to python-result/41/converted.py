# --- File: Node.java ---

# package: com.thealgorithms.datastructures.disjointsetunion

class Node:
    def __init__(self, data):
        self.data = data
        parent = this

if __name__ == "__main__":
    pass
