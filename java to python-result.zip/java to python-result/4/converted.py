# --- File: BoruvkaAlgorithm.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

# import: java.util.List

class BoruvkaAlgorithm:
    def __init__(self):
        pass
    @staticmethod
    def find(components, i):
        """* Finds the parent of the subset using path compression
     *
     * @param components array of subsets
     * @param i          index of the subset
     * @return the parent of the subset"""
        # 
     * Finds the parent of the subset using path compression
     *
     * @param components array of subsets
     * @param i          index of the subset
     * @return the parent of the subset
     
        if components[i].parent != i:
            components[i].parent = find(components, components[i].parent)
        return components[i].parent
    @staticmethod
    def union(components, x, y):
        """* Performs the Union operation for Union-Find
     *
     * @param components array of subsets
     * @param x          index of the first subset
     * @param y          index of the second subset"""
        # 
     * Performs the Union operation for Union-Find
     *
     * @param components array of subsets
     * @param x          index of the first subset
     * @param y          index of the second subset
     
        final int xroot = find(components, x)
        final int yroot = find(components, y)
        if components[xroot].rank < components[yroot].rank:
            components[xroot].parent = yroot
        else:
            rank + rank
            components[yroot].parent = xroot
            # expr: components[xroot].rank++
    @staticmethod
    def boruvkaMST(graph):
        """* Boruvka's algorithm to find the Minimum Spanning Tree
     *
     * @param graph the graph
     * @return list of edges in the Minimum Spanning Tree"""
        # 
     * Boruvka's algorithm to find the Minimum Spanning Tree
     *
     * @param graph the graph
     * @return list of edges in the Minimum Spanning Tree
     
        boruvkaState = BoruvkaState(graph)
        while boruvkaState.hasMoreEdgesToAdd():
            final var cheapest = boruvkaState.computeCheapestEdges()
            boruvkaState.merge(cheapest)
        return boruvkaState.result
    @staticmethod
    def checkEdgeVertices(vertex, upperBound):
        """* Checks if the edge vertices are in a valid range
     *
     * @param vertex     the vertex to check
     * @param upperBound the upper bound for the vertex range"""
        # 
     * Checks if the edge vertices are in a valid range
     *
     * @param vertex     the vertex to check
     * @param upperBound the upper bound for the vertex range
     
        if vertex < 0 || vertex >= upperBound:
            raise ValueError("Edge vertex out of range")

    class Edge:
        """* Represents an edge in the graph"""
        def __init__(self, src, dest, weight):
            self.src = src
            self.dest = dest
            self.weight = weight

    class Graph:
        """* Represents the graph"""
        def __init__(self, vertex, edges):
            """* Constructor for the graph
         *
         * @param vertex number of vertices
         * @param edges  list of edges"""
            # 
         * Constructor for the graph
         *
         * @param vertex number of vertices
         * @param edges  list of edges
         
            if vertex < 0:
                raise ValueError("Number of vertices must be positive")
            if edges == null || edges.isEmpty():
                raise ValueError("Edges list must not be null or empty")
            for edge in edges:
                checkEdgeVertices(edge.src, vertex)
                checkEdgeVertices(edge.dest, vertex)
            self.vertex = vertex
            self.edges = edges

    class Component:
        """* Represents a subset for Union-Find operations"""
        def __init__(self, parent, rank):
            self.parent = parent
            self.rank = rank

    class BoruvkaState:
        """* Represents the state of Union-Find components and the result list"""
        def __init__(self, graph):
            this.result = []
            self.components = initializeComponents(graph)
            self.graph = graph
        def merge(self, cheapest):
            """* Adds the cheapest edges to the result list and performs Union operation on the subsets.
         *
         * @param cheapest Array containing the cheapest edge for each subset."""
            # 
         * Adds the cheapest edges to the result list and performs Union operation on the subsets.
         *
         * @param cheapest Array containing the cheapest edge for each subset.
         
            for i in range(graph.vertex):
                if cheapest[i] != null:
                    final var component1 = find(components, cheapest[i].src)
                    final var component2 = find(components, cheapest[i].dest)
                    if component1 != component2:
                        result.append(cheapest[i])
                        union(components, component1, component2)
        def hasMoreEdgesToAdd(self):
            """* Checks if there are more edges to add to the result list
         *
         * @return true if there are more edges to add, false otherwise"""
            # 
         * Checks if there are more edges to add to the result list
         *
         * @return true if there are more edges to add, false otherwise
         
            return result.size() < graph.vertex - 1
        def computeCheapestEdges(self):
            """* Computes the cheapest edges for each subset in the Union-Find structure.
         *
         * @return an array containing the cheapest edge for each subset."""
            # 
         * Computes the cheapest edges for each subset in the Union-Find structure.
         *
         * @return an array containing the cheapest edge for each subset.
         
            # Unhandled node type: ArrayType
            cheapest = new Edge[graph.vertex]
            for edge in graph.edges:
                final var set1 = find(components, edge.src)
                final var set2 = find(components, edge.dest)
                if set1 != set2:
                    if cheapest[set1] == null || edge.weight < cheapest[set1].weight:
                        cheapest[set1] = edge
                    if cheapest[set2] == null || edge.weight < cheapest[set2].weight:
                        cheapest[set2] = edge
            return cheapest
        @staticmethod
        def initializeComponents(graph):
            """* Initializes subsets for Union-Find
         *
         * @param graph the graph
         * @return the initialized subsets"""
            # 
         * Initializes subsets for Union-Find
         *
         * @param graph the graph
         * @return the initialized subsets
         
            # Unhandled node type: ArrayType
            components = new Component[graph.vertex]
            for v in range(graph.vertex):
                components[v] = Component(v, 0)
            return components

# Unhandled node type: JavadocComment
# 
 * Boruvka's algorithm to find Minimum Spanning Tree
 * (https://en.wikipedia.org/wiki/Bor%C5%AFvka%27s_algorithm)
 *
 * @author itakurah (https://github.com/itakurah)

if __name__ == "__main__":
    pass
