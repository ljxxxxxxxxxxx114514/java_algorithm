# --- File: ModuloPowerOfTwo.java ---

# package: com.thealgorithms.bitmanipulation

class ModuloPowerOfTwo:
    """* This class provides a method to compute the remainder
 * of a number when divided by a power of two (2^n)
 * without using division or modulo operations.
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def moduloPowerOfTwo(x, n):
        """* Computes the remainder of a given integer when divided by 2^n.
     *
     * @param x the input number
     * @param n the exponent (power of two)
     * @return the remainder of x divided by 2^n"""
        if n < = 0:
            raise ValueError("The exponent must be positive")
        return x & ((1 << n) - 1)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.750
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 20:16 invalid syntax
#    >         if n < = 0:
# 语法问题: [class ModuloPowerOfTwo] 行 20 invalid syntax
#    >         if n < = 0:
# --- 报告结束 ---
