# --- File: LCA.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.Scanner

class LCA:
    SCANNER: iter = new Scanner(System.in)
    def __init__(self):
        pass
#
#  * Input:
#  * 10
#  * 0 1
#  * 0 2
#  * 1 5
#  * 5 6
#  * 2 4
#  * 2 3
#  * 3 7
#  * 7 9
#  * 7 8
#  * 9 4
#  * Output:
#  * 2
#

def main(args=None):
    if args is None:
        args = []
    adj = list()
    v = SCANNER.nextInt()
    e = v - 1
    for i in range(v):
        adj.append(list())
    # expr: int to
    # expr: int from
    for i in range(e):
        to = SCANNER.int(input())()
        from = SCANNER.int(input())()
        adj[to].append(from)
        adj[from].append(to)
    parent = new int[v]
    depth = new int[v]
    dfs(adj, 0, -1, parent, depth)
    v1 = SCANNER.nextInt()
    v2 = SCANNER.nextInt()
    print(getLCA(v1, v2, depth, parent))
def dfs(adj, s, p, parent, depth):
    """* Depth first search to calculate parent and depth of every vertex
 *
 * @param adj The adjacency list representation of the tree
 * @param s The source vertex
 * @param p Parent of source
 * @param parent An array to store parents of all vertices
 * @param depth An array to store depth of all vertices"""
    for adjacent in adj[s]:
        if adjacent != p:
            parent[adjacent] = s
            print(f"{str(depth[adjacent] = 1)}{str(depth[s])}")
            dfs(adj, adjacent, s, parent, depth)
def getLCA(v1, v2, depth, parent):
    """* Method to calculate Lowest Common Ancestor
 *
 * @param v1 The first vertex
 * @param v2 The second vertex
 * @param depth An array with depths of all vertices
 * @param parent An array with parents of all vertices
 * @return Returns a vertex that is LCA of v1 and v2"""
    if depth[v1] < depth[v2]:
        temp = v1
        v1 = v2
        v2 = temp
    while depth[v1] != depth[v2]:
        v1 = parent[v1]
    if v1 == v2:
        return v1
    while v1 != v2:
        v1 = parent[v1]
        v2 = parent[v2]
    return v1

if __name__ == "__main__":
    main()

# --- 转换测试报告 ---
# 转换效率: 0.878
# 可解析度: 0.400 (2/5)
# 语法问题: 模块无法解析
#  - 行 10:31 invalid syntax
#    >     SCANNER: iter = new Scanner(System.in)
# 语法问题: [class LCA] 行 10 invalid syntax
#    >     SCANNER: iter = new Scanner(System.in)
# 语法问题: [def main] 行 42 invalid syntax
#    >         from = SCANNER.int(input())()
# 语法问题: [def dfs] 行 62 keyword can't be an expression
#    >             print(f"{str(depth[adjacent] = 1)}{str(depth[s])}")
# 未处理节点类型(Top):
#  - ExpressionStmt: 2
# --- 报告结束 ---
