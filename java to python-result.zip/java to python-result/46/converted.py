# --- File: ImmutableHashMap.java ---

# package: com.thealgorithms.datastructures.hashmap.hashing

class ImmutableHashMap:
    """* Immutable HashMap implementation using separate chaining.
 *
 * <p>This HashMap does not allow modification of existing instances.
 * Any update operation returns a new ImmutableHashMap.
 *
 * @param <K> key type
 * @param <V> value type"""
    DEFAULT_CAPACITY: int = 16
    def __init__(self, table, size):
        """* Private constructor to enforce immutability."""
        # 
     * Private constructor to enforce immutability.
     
        self.table = table
        self.size = size
    @staticmethod
    def empty():
        """* Creates an empty ImmutableHashMap.
     *
     * @param <K> key type
     * @param <V> value type
     * @return empty ImmutableHashMap"""
        # 
     * Creates an empty ImmutableHashMap.
     *
     * @param <K> key type
     * @param <V> value type
     * @return empty ImmutableHashMap
     
        # expr: SuppressWarnings
        Node<K, V>[] table = (Node<K, V>[]) new Node[DEFAULT_CAPACITY]
        return new ImmutableHashMap<>(table, 0)
    def put(self, key, value):
        """* Returns a new ImmutableHashMap with the given key-value pair added.
     *
     * @param key key to add
     * @param value value to associate
     * @return new ImmutableHashMap instance"""
        # 
     * Returns a new ImmutableHashMap with the given key-value pair added.
     *
     * @param key key to add
     * @param value value to associate
     * @return new ImmutableHashMap instance
     
        Node<K, V>[] newTable = table.clone()
        index = hash(key)
        newTable[index] = Node(key, value, newTable[index])
        return new ImmutableHashMap<>(newTable, size + 1)
    def get(self, key):
        """* Retrieves the value associated with the given key.
     *
     * @param key key to search
     * @return value if found, otherwise null"""
        # 
     * Retrieves the value associated with the given key.
     *
     * @param key key to search
     * @return value if found, otherwise null
     
        index = hash(key)
        Node<K, V> current = table[index]
        while current != null:
            if (key == null && current.key == null) || (key != null && key.equals(current.key)):
                return current.value
            current = current.next
        return null
    def containsKey(self, key):
        """* Checks whether the given key exists in the map.
     *
     * @param key key to check
     * @return true if key exists, false otherwise"""
        # 
     * Checks whether the given key exists in the map.
     *
     * @param key key to check
     * @return true if key exists, false otherwise
     
        return get(key) != null
    def size(self):
        """* Returns the number of key-value pairs.
     *
     * @return size of the map"""
        # 
     * Returns the number of key-value pairs.
     *
     * @return size of the map
     
        return size
    def hash(self, key):
        """* Computes hash index for a given key."""
        # 
     * Computes hash index for a given key.
     
        return key == null ? 0 : (key.hashCode() & Integer.MAX_VALUE) % table.length

    class Node:
        """* Node class for separate chaining."""
        def __init__(self, key, value, next):
            self.key = key
            self.value = value
            self.next = next

if __name__ == "__main__":
    pass
