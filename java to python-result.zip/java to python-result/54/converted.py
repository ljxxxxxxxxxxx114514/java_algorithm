# --- File: GenericHeap.java ---

# package: com.thealgorithms.datastructures.heaps

# import: java.util.ArrayList

# import: java.util.HashMap

class GenericHeap:
    """* A generic implementation of a max heap data structure.
 *
 * @param <T> the type of elements in this heap, must extend Comparable."""
    def add(self, item):
        """* Adds an item to the heap, maintaining the heap property.
     *
     * @param item the item to be added"""
        if item == None:
            raise ValueError("Cannot insert null into the heap.")
        self.data.append(item)
        self.map[item] = len(self.data) - 1
        upHeapify(len(self.data) - 1)
    def upHeapify(self, ci):
        """* Restores the heap property by moving the item at the given index upwards.
     *
     * @param ci the index of the current item"""
        pi = (ci - 1) / 2
        if ci > 0 and isLarger(self.data[ci], self.data[pi]) > 0:
            swap(pi, ci)
            upHeapify(pi)
    def size(self):
        """* Returns the number of elements in the heap.
     *
     * @return the size of the heap"""
        return self.data.size()
    def isEmpty(self):
        """* Checks if the heap is empty.
     *
     * @return true if the heap is empty, false otherwise"""
        return this.size()
    def remove(self):
        """* Removes and returns the maximum item from the heap.
     *
     * @return the maximum item"""
        if isEmpty():
            raise IllegalStateException("Heap is empty")
        self.swap(0, len(self) - 1)
        rv = self.data.remove(len(self) - 1)
        self.map.pop(rv)
        downHeapify(0)
        return rv
    def downHeapify(self, pi):
        """* Restores the heap property by moving the item at the given index downwards.
     *
     * @param pi the index of the current item"""
        lci = 2 * pi + 1
        rci = 2 * pi + 2
        mini = pi
        if lci < len(self) and isLarger(self.data[lci], self.data[mini]) > 0:
            mini = lci
        if rci < len(self) and isLarger(self.data[rci], self.data[mini]) > 0:
            mini = rci
        if mini != pi:
            self.swap(pi, mini)
            downHeapify(mini)
    def get(self):
        """* Retrieves the maximum item from the heap without removing it.
     *
     * @return the maximum item"""
        if isEmpty():
            raise IllegalStateException("Heap is empty")
        return self.data.getFirst()
    def isLarger(self, t, o):
        """* Compares two items to determine their order.
     *
     * @param t the first item
     * @param o the second item
     * @return a positive integer if t is greater than o, negative if t is less, and zero if they are equal"""
        return t.compareTo(o)
    def swap(self, i, j):
        """* Swaps two items in the heap and updates their indices in the map.
     *
     * @param i index of the first item
     * @param j index of the second item"""
        ith = self.data[i]
        jth = self.data[j]
        self.data[i] = jth
        self.data[j] = ith
        self.map[ith] = j
        self.map[jth] = i
    def updatePriority(self, item):
        """* Updates the priority of the specified item by restoring the heap property.
     *
     * @param item the item whose priority is to be updated"""
        if not map.containsKey(item):
            raise ValueError("Item not found in the heap")
        index = map[item]
        upHeapify(index)

    def __init__(self):
        self.data = new ArrayList<>()
        self.map = new HashMap<>()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.960
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 100:33 invalid syntax
#    >         self.data = new ArrayList<>()
# 语法问题: [class GenericHeap] 行 100 invalid syntax
#    >         self.data = new ArrayList<>()
# --- 报告结束 ---
