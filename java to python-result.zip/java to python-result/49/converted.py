# --- File: MainCuckooHashing.java ---

# package: com.thealgorithms.datastructures.hashmap.hashing

# import: java.util.Scanner

class MainCuckooHashing:
    def __init__(self):
        pass

def main(args=None):
    if args is None:
        args = []
    # expr: int choice
    # expr: int key
    h = HashMapCuckooHashing(7)
    scan = Scanner(System.in)
    while true:
        print("_________________________")
        print("Enter your Choice :")
        print("1. Add Key")
        print("2. Delete Key")
        print("3. Print Table")
        print("4. Exit")
        print("5. Search and print key index")
        print("6. Check load factor")
        print("7. Rehash Current Table")
        choice = scan.nextInt()
        # switch choice
            choice
            # Unhandled node type: SwitchEntry

if __name__ == "__main__":
    main()
