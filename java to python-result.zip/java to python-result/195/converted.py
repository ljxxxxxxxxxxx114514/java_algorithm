# --- File: SimpleNode.java ---

# package: com.thealgorithms.devutils.nodes

class SimpleNode:
    """* Simple Node implementation that holds a reference to the next Node.
 *
 * @param <E> The type of the data held in the Node.
 *
 * @author <a href="https://github.com/aitorfi">aitorfi</a>"""
    def __init__(self, data=None, nextNode=None):
        """* Empty constructor."""
        if data is None and nextNode is None:
            # Unhandled node type: ExplicitConstructorInvocationStmt
        elif data is not None:
            # Unhandled node type: ExplicitConstructorInvocationStmt
        elif data is not None and nextNode is not None:
            # Unhandled node type: ExplicitConstructorInvocationStmt
            self.nextNode = nextNode
    def hasNext(self):
        """* @return True if there is a next node, otherwise false."""
        return (nextNode != None)
    def getNextNode(self):
        return self.nextNode
    def setNextNode(self, nextNode):
        self.nextNode = nextNode

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.771
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 15:12 expected an indented block
#    >         elif data is not None:
# 语法问题: [class SimpleNode] 行 15 expected an indented block
#    >         elif data is not None:
# 未处理节点类型(Top):
#  - BlockStmt: 2
# --- 报告结束 ---
