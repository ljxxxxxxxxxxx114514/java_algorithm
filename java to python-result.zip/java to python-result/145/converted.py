# --- File: FloodFill.java ---

# package: com.thealgorithms.backtracking

class FloodFill:
    """* Java program for Flood fill algorithm.
 * @author Akshay Dubey (<a href="https://github.com/itsAkshayDubey">Git-Akshay Dubey</a>)"""
    def __init__(self):
        pass
    @staticmethod
    def getPixel(image, x, y):
        return image[x][y]
    @staticmethod
    def putPixel(image, x, y, newColor):
        """* Put the color at the given coordinates of a 2D image
     *
     * @param image The image to be filled
     * @param x The x coordinate at which color is to be filled
     * @param y The y coordinate at which color is to be filled"""
        image[x][y] = newColor
    @staticmethod
    def floodFill(image, x, y, newColor, oldColor):
        """* Fill the 2D image with new color
     *
     * @param image The image to be filled
     * @param x The x coordinate at which color is to be filled
     * @param y The y coordinate at which color is to be filled
     * @param newColor The new color which to be filled in the image
     * @param oldColor The old color which is to be replaced in the image"""
        if newColor == oldColor or x < 0 or x >= image.length or y < 0 or y >= image[x].length or getPixel(image, x, y) != oldColor:
            return
        putPixel(image, x, y, newColor)
        floodFill(image, x + 1, y, newColor, oldColor)
        floodFill(image, x - 1, y, newColor, oldColor)
        floodFill(image, x, y + 1, newColor, oldColor)
        floodFill(image, x, y - 1, newColor, oldColor)
        floodFill(image, x + 1, y - 1, newColor, oldColor)
        floodFill(image, x - 1, y + 1, newColor, oldColor)
        floodFill(image, x + 1, y + 1, newColor, oldColor)
        floodFill(image, x - 1, y - 1, newColor, oldColor)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.908
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
