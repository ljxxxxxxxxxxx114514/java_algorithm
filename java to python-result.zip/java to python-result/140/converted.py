# --- File: AllPathsFromSourceToTarget.java ---

# package: com.thealgorithms.backtracking

# import: java.util.ArrayList

# import: java.util.List

class AllPathsFromSourceToTarget:
    nm: list[list[int]] = new ArrayList<>()
    def __init__(self, vertices):
        #  Constructor
        self.v = vertices
        initAdjList()
    def initAdjList(self):
        #  utility method to initialise adjacency list
        adjList =  new ArrayList[v]
        for i in range(self.v):
            adjList[i] = list()
    def addEdge(self, u, v):
        #  add edge from u to v
        adjList[u].add(v)
    def storeAllPaths(self, s, d):
        isVisited = new boolean[v]
        pathList = list()
        pathList.append(s)
        storeAllPathsUtil(s, d, isVisited, pathList)
    def storeAllPathsUtil(self, u, d, isVisited, localPathList):
        #  localPathList<> stores actual vertices in the current path
        if (u == d):
            nm.append(list(localPathList))
            return
        isVisited[u] = True
        for i in adjList[u]:
            if not isVisited[i]:
                localPathList.append(i)
                storeAllPathsUtil(i, d, isVisited, localPathList)
                localPathList.remove(i)
        isVisited[u] = False
    @staticmethod
    def allPathsFromSourceToTarget(vertices, a, source, destination):
        #  Driver program
        g = AllPathsFromSourceToTarget(vertices)
        for i in a:
            g.addEdge(i[0], i[1])
        g.storeAllPaths(source, destination)
        return nm

# Unhandled node type: JavadocComment
#
#  * Finds all possible simple paths from a given source vertex to a destination vertex
#  * in a directed graph using backtracking.
#  *
#  * <p>This algorithm performs a Depth First Search (DFS) traversal while keeping track
#  * of visited vertices to avoid cycles. Whenever the destination vertex is reached,
#  * the current path is stored as one valid path.</p>
#  *
#  * <p><b>Key Characteristics:</b></p>
#  * <ul>
#  *   <li>Works on directed graphs</li>
#  *   <li>Does not allow revisiting vertices in the same path</li>
#  *   <li>Stores all possible paths from source to destination</li>
#  * </ul>
#  *
#  * <p><b>Time Complexity:</b></p>
#  * <ul>
#  *   <li>Worst Case: O(V!) — when the graph is fully connected</li>
#  * </ul>
#  *
#  * <p><b>Space Complexity:</b></p>
#  * <ul>
#  *   <li>O(V) for recursion stack and visited array</li>
#  *   <li>Additional space for storing all valid paths</li>
#  * </ul>
#  *
#  * <p>This implementation is intended for educational purposes.</p>
#  *
#  * @see <a href="https://en.wikipedia.org/wiki/Depth-first_search">Depth First Search</a>
#

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.936
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 10:39 invalid syntax
#    >     nm: list[list[int]] = new ArrayList<>()
# 语法问题: [class AllPathsFromSourceToTarget] 行 10 invalid syntax
#    >     nm: list[list[int]] = new ArrayList<>()
# 未映射方法(Top):
#  - AllPathsFromSourceToTarget.addEdge: 1
#  - AllPathsFromSourceToTarget.storeAllPaths: 1
# --- 报告结束 ---
