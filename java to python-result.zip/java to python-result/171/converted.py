# --- File: GrayCodeConversion.java ---

# package: com.thealgorithms.bitmanipulation

class GrayCodeConversion:
    """* Gray code is a binary numeral system where two successive values differ in only one bit.
 * This is a simple conversion between binary and Gray code.
 * Example:
 * 7 -> 0111 -> 0100 -> 4
 * 4 -> 0100 -> 0111 -> 7
 * 0 -> 0000 -> 0000 -> 0
 * 1 -> 0001 -> 0000 -> 0
 * 2 -> 0010 -> 0011 -> 3
 * 3 -> 0011 -> 0010 -> 2
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def binaryToGray(num):
        """* Converts a binary number to Gray code.
     *
     * @param num The binary number.
     * @return The corresponding Gray code."""
        return num ^ (num >> 1)
    @staticmethod
    def grayToBinary(gray):
        """* Converts a Gray code number back to binary.
     *
     * @param gray The Gray code number.
     * @return The corresponding binary number."""
        binary = gray
        while gray > 0:
            gray >> = 1
            binary ^ = gray
        return binary

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.841
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 34:21 invalid syntax
#    >             gray >> = 1
# 语法问题: [class GrayCodeConversion] 行 34 invalid syntax
#    >             gray >> = 1
# --- 报告结束 ---
