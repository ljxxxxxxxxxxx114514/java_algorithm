# --- File: CheckIfBinaryTreeBalanced.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.HashMap

# import: java.util.Stack

class CheckIfBinaryTreeBalanced:
    """* This class will check if a BinaryTree is balanced. A balanced binary tree is
 * defined as a binary tree where the difference in height between the left and
 * right subtree of each node differs by at most one.
 * <p>
 * This can be done in both an iterative and recursive fashion. Below,
 * `isBalancedRecursive()` is implemented in a recursive fashion, and
 * `isBalancedIterative()` is implemented in an iterative fashion.
 *
 * @author [Ian Cowan](<a href="https://github.com/iccowan">Git-Ian Cowan</a>)"""
    def __init__(self):
        pass
    @staticmethod
    def isBalancedRecursive(root):
        """* Recursive is BT balanced implementation
     *
     * @param root The binary tree to check if balanced"""
        if root == None:
            return True
        isBalanced = new boolean[1]
        isBalanced[0] = True
        isBalancedRecursive(root, 0, isBalanced)
        return isBalanced[0]
    @staticmethod
    def isBalancedRecursive(node, depth, isBalanced):
        """* Private helper method to keep track of the depth and balance during
     * recursion. We effectively perform a modified post-order traversal where
     * we are looking at the heights of both children of each node in the tree
     *
     * @param node       The current node to explore
     * @param depth      The current depth of the node
     * @param isBalanced The array of length 1 keeping track of our balance"""
        if node == None or not isBalanced[0]:
            return 0
        leftHeight = isBalancedRecursive(node.left, depth + 1, isBalanced)
        rightHeight = isBalancedRecursive(node.right, depth + 1, isBalanced)
        if Math.abs(leftHeight - rightHeight) > 1:
            isBalanced[0] = False
        return # expr: Math.max(leftHeight, rightHeight) + 1
    @staticmethod
    def isBalancedIterative(root):
        """* Iterative is BT balanced implementation"""
        if root == None:
            return True
        isBalanced = True
        nodeStack = Stack()
        lastVisited = None
        subtreeHeights = HashMap()
        node = root
        while not ((not nodeStack) and node == None) and isBalanced:
            if node != None:
                nodeStack.append(node)
                node = node.left
            else:
                node = nodeStack.[-1]()
                if node.right == None or node.right == lastVisited:
                    leftHeight = 0
                    rightHeight = 0
                    if node.left != None:
                        leftHeight = subtreeHeights[node.left]
                    if node.right != None:
                        rightHeight = subtreeHeights[node.right]
                    if Math.abs(rightHeight - leftHeight) > 1:
                        isBalanced = False
                    subtreeHeights[node] = Math.max(rightHeight, leftHeight) + 1
                    nodeStack.pop()
                    lastVisited = node
                    node = None
                else:
                    node = node.right
        return isBalanced

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.932
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 28:32 invalid syntax
#    >         isBalanced = new boolean[1]
# 语法问题: [class CheckIfBinaryTreeBalanced] 行 28 invalid syntax
#    >         isBalanced = new boolean[1]
# --- 报告结束 ---
