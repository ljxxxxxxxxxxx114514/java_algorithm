# --- File: WelshPowell.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.Arrays

# import: java.util.Comparator

# import: java.util.HashSet

# import: java.util.stream.IntStream

class WelshPowell:
    """* The Welsh-Powell algorithm is a graph coloring algorithm that aims to color a graph
 * using the minimum number of colors such that no two adjacent vertices share the same color.
 *
 * <p>
 * The algorithm works by:
 * <ol>
 * <li>Sorting the vertices in descending order based on their degrees (number of edges connected).</li>
 * <li>Iterating through each vertex and assigning it the smallest available color that has not been used by its adjacent vertices.</li>
 * <li>Coloring adjacent vertices with the same color is avoided.</li>
 * </ol>
 * </p>
 *
 * <p>
 * For more information, see <a href="https://en.wikipedia.org/wiki/Graph_coloring">Graph Coloring</a>.
 * </p>"""
    BLANK_COLOR: int = -1
    def __init__(self):
        pass
    @staticmethod
    def makeGraph(numberOfVertices, listOfEdges):
        """* Creates a graph with the specified number of vertices and edges.
     *
     * @param numberOfVertices the total number of vertices
     * @param listOfEdges a 2D array representing edges where each inner array contains two vertex indices
     * @return a Graph object representing the created graph
     * @throws IllegalArgumentException if the edge array is invalid or vertices are out of bounds"""
        # 
     * Creates a graph with the specified number of vertices and edges.
     *
     * @param numberOfVertices the total number of vertices
     * @param listOfEdges a 2D array representing edges where each inner array contains two vertex indices
     * @return a Graph object representing the created graph
     * @throws IllegalArgumentException if the edge array is invalid or vertices are out of bounds
     
        graph = Graph(numberOfVertices)
        for edge in listOfEdges:
            if edge.length != 2:
                raise ValueError("Edge array must have exactly two elements")
            graph.addEdge(edge[0], edge[1])
        return graph
    @staticmethod
    def findColoring(graph):
        """* Finds the coloring of the given graph using the Welsh-Powell algorithm.
     *
     * @param graph the input graph to color
     * @return an array of integers where each index represents a vertex and the value represents the color assigned"""
        # 
     * Finds the coloring of the given graph using the Welsh-Powell algorithm.
     *
     * @param graph the input graph to color
     * @return an array of integers where each index represents a vertex and the value represents the color assigned
     
        # Unhandled node type: ArrayType
        colors = initializeColors(graph.getNumVertices())
        sortedVertices = getSortedNodes(graph)
        for vertex in sortedVertices:
            if isBlank(colors[vertex]):
                usedColors = computeUsedColors(graph, vertex, colors)
                final var newColor = firstUnusedColor(usedColors)
                colors[vertex] = newColor
                Arrays.stream(sortedVertices).forEach(otherVertex -> {
    if (isBlank(colors[otherVertex]) && !isAdjacentToColored(graph, otherVertex, colors)) {
        colors[otherVertex] = newColor;
    }
})
        return colors
    @staticmethod
    def isBlank(color):
        """* Helper method to check if a color is unassigned
     *
     * @param color the color to check
     * @return {@code true} if the color is unassigned, {@code false} otherwise"""
        # 
     * Helper method to check if a color is unassigned
     *
     * @param color the color to check
     * @return {@code true} if the color is unassigned, {@code false} otherwise
     
        return color == BLANK_COLOR
    @staticmethod
    def isAdjacentToColored(graph, vertex, colors):
        """* Checks if a vertex has adjacent colored vertices
     *
     * @param graph the input graph
     * @param vertex the vertex to check
     * @param colors the array of colors assigned to the vertices
     * @return {@code true} if the vertex has adjacent colored vertices, {@code false} otherwise"""
        # 
     * Checks if a vertex has adjacent colored vertices
     *
     * @param graph the input graph
     * @param vertex the vertex to check
     * @param colors the array of colors assigned to the vertices
     * @return {@code true} if the vertex has adjacent colored vertices, {@code false} otherwise
     
        return graph.getAdjacencyList(vertex).stream().anyMatch(otherVertex -> !isBlank(colors[otherVertex]))
    @staticmethod
    def initializeColors(numberOfVertices):
        """* Initializes the colors array with blank color
     *
     * @param numberOfVertices the number of vertices in the graph
     * @return an array of integers representing the colors assigned to the vertices"""
        # 
     * Initializes the colors array with blank color
     *
     * @param numberOfVertices the number of vertices in the graph
     * @return an array of integers representing the colors assigned to the vertices
     
        # Unhandled node type: ArrayType
        colors = new int[numberOfVertices]
        Arrays.fill(colors, BLANK_COLOR)
        return colors
    @staticmethod
    def getSortedNodes(graph):
        """* Sorts the vertices by their degree in descending order
     *
     * @param graph the input graph
     * @return an array of integers representing the vertices sorted by degree"""
        # 
     * Sorts the vertices by their degree in descending order
     *
     * @param graph the input graph
     * @return an array of integers representing the vertices sorted by degree
     
        # Unhandled node type: ArrayType
        return IntStream.range(0, graph.getNumVertices()).boxed().sorted(Comparator.comparingInt(v -> -graph.getAdjacencyList(v).size())).toArray(Integer[]::new)
    @staticmethod
    def computeUsedColors(graph, vertex, colors):
        """* Computes the colors already used by the adjacent vertices
     *
     * @param graph the input graph
     * @param vertex the vertex to check
     * @param colors the array of colors assigned to the vertices
     * @return an array of booleans representing the colors used by the adjacent vertices"""
        # 
     * Computes the colors already used by the adjacent vertices
     *
     * @param graph the input graph
     * @param vertex the vertex to check
     * @param colors the array of colors assigned to the vertices
     * @return an array of booleans representing the colors used by the adjacent vertices
     
        # Unhandled node type: ArrayType
        usedColors = new boolean[graph.getNumVertices()]
        graph.getAdjacencyList(vertex).stream().map(neighbor -> colors[neighbor]).filter(color -> !isBlank(color)).forEach(color -> usedColors[color] = true)
        return usedColors
    @staticmethod
    def firstUnusedColor(usedColors):
        """* Finds the first unused color
     *
     * @param usedColors the array of colors used by the adjacent vertices
     * @return the first unused color"""
        # 
     * Finds the first unused color
     *
     * @param usedColors the array of colors used by the adjacent vertices
     * @return the first unused color
     
        return IntStream.range(0, usedColors.length).filter(color -> !usedColors[color]).findFirst().getAsInt()

    class Graph:
        """* Represents a graph using an adjacency list."""
        def __init__(self, vertices):
            """* Initializes a graph with a specified number of vertices.
         *
         * @param vertices the number of vertices in the graph
         * @throws IllegalArgumentException if the number of vertices is negative"""
            # 
         * Initializes a graph with a specified number of vertices.
         *
         * @param vertices the number of vertices in the graph
         * @throws IllegalArgumentException if the number of vertices is negative
         
            if vertices < 0:
                raise ValueError("Number of vertices cannot be negative")
            adjacencyLists =  new HashSet[vertices]
            Arrays.setAll(adjacencyLists, i -> new HashSet<>())
        def addEdge(self, nodeA, nodeB):
            """* Adds an edge between two vertices in the graph.
         *
         * @param nodeA one end of the edge
         * @param nodeB the other end of the edge
         * @throws IllegalArgumentException if the vertices are out of bounds or if a self-loop is attempted"""
            # 
         * Adds an edge between two vertices in the graph.
         *
         * @param nodeA one end of the edge
         * @param nodeB the other end of the edge
         * @throws IllegalArgumentException if the vertices are out of bounds or if a self-loop is attempted
         
            validateVertex(nodeA)
            validateVertex(nodeB)
            if nodeA == nodeB:
                raise ValueError("Self-loops are not allowed")
            adjacencyLists[nodeA].add(nodeB)
            adjacencyLists[nodeB].add(nodeA)
        def validateVertex(self, vertex):
            """* Validates that the vertex index is within the bounds of the graph.
         *
         * @param vertex the index of the vertex to validate
         * @throws IllegalArgumentException if the vertex is out of bounds"""
            # 
         * Validates that the vertex index is within the bounds of the graph.
         *
         * @param vertex the index of the vertex to validate
         * @throws IllegalArgumentException if the vertex is out of bounds
         
            if vertex < 0 || vertex >= getNumVertices():
                raise ValueError("Vertex " + vertex + " is out of bounds")
        def getAdjacencyList(self, vertex):
            """* Returns the adjacency list for a specific vertex.
         *
         * @param vertex the index of the vertex
         * @return the set of adjacent vertices"""
            # 
         * Returns the adjacency list for a specific vertex.
         *
         * @param vertex the index of the vertex
         * @return the set of adjacent vertices
         
            return adjacencyLists[vertex]
        def getNumVertices(self):
            """* Returns the number of vertices in the graph.
         *
         * @return the number of vertices"""
            # 
         * Returns the number of vertices in the graph.
         *
         * @return the number of vertices
         
            return adjacencyLists.length

if __name__ == "__main__":
    pass
