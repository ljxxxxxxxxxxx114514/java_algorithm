# --- File: IndexedPriorityQueue.java ---

# package: com.thealgorithms.datastructures.heaps

# import: java.util.Arrays

# import: java.util.Comparator

# import: java.util.IdentityHashMap

# import: java.util.Objects

# import: java.util.function.Consumer

class IndexedPriorityQueue:
    """* An addressable (indexed) min-priority queue with O(log n) updates.
 *
 * <p>Key features:
 * <ul>
 *   <li>Each element E is tracked by a handle (its current heap index) via a map,
 *       enabling O(log n) {@code remove(e)} and O(log n) key updates
 *       ({@code changeKey/decreaseKey/increaseKey}).</li>
 *   <li>The queue order is determined by the provided {@link Comparator}. If the
 *       comparator is {@code null}, elements must implement {@link Comparable}
 *       (same contract as {@link java.util.PriorityQueue}).</li>
 *   <li>By default this implementation uses {@link IdentityHashMap} for the index
 *       mapping to avoid issues with duplicate-equals elements or mutable equals/hashCode.
 *       If you need value-based equality, switch to {@code HashMap} and read the caveats
 *       in the class-level Javadoc carefully.</li>
 * </ul>
 *
 * <h2>IMPORTANT contracts</h2>
 * <ul>
 *   <li><b>Do not mutate comparator-relevant fields of an element directly</b> while it is
 *       inside the queue. Always use {@code changeKey}/{@code decreaseKey}/{@code increaseKey}
 *       so the heap can be restored accordingly.</li>
 *   <li>If you replace {@link IdentityHashMap} with {@link HashMap}, you must ensure:
 *       (a) no two distinct elements are {@code equals()}-equal at the same time in the queue, and
 *       (b) {@code equals/hashCode} of elements remain stable while enqueued.</li>
 *   <li>{@code peek()} returns {@code null} when empty (matching {@link java.util.PriorityQueue}).</li>
 *   <li>Not thread-safe.</li>
 * </ul>
 *
 * <p>Complexities:
 * {@code offer, poll, remove(e), changeKey, decreaseKey, increaseKey} are O(log n);
 * {@code peek, isEmpty, size, contains} are O(1)."""
    DEFAULT_INITIAL_CAPACITY: int = 11
    def __init__(self, cmp=None, initialCapacity=None):
        if cmp is None and initialCapacity is None:
            # Unhandled node type: ExplicitConstructorInvocationStmt
        elif cmp is not None:
            # Unhandled node type: ExplicitConstructorInvocationStmt
        elif initialCapacity is not None and cmp is not None:
            if initialCapacity < 1:
                raise ValueError("initialCapacity < 1")
            self.heap =  new Object[initialCapacity]
            self.cmp = cmp
            self.index = IdentityHashMap()
    def size(self):
        """Returns current number of elements."""
        return self.size
    def isEmpty(self):
        """Returns {@code true} if empty."""
        return size == 0
    def peek(self):
        """* Returns the minimum element without removing it, or {@code null} if empty.
     * Matches {@link java.util.PriorityQueue#peek()} behavior."""
        SuppressWarnings
        return None if size == 0 else (E) heap[0]
    def offer(self, e):
        """* Inserts the specified element (O(log n)).
     * @throws NullPointerException if {@code e} is null
     * @throws ClassCastException if {@code cmp == null} and {@code e} is not Comparable,
     *                            or if incompatible with other elements"""
        assert e is not None
        if size > = heap.length:
            grow(size + 1)
        siftUp(size, e)
        size += 1
        return True
    def poll(self):
        """* Removes and returns the minimum element (O(log n)), or {@code null} if empty."""
        SuppressWarnings
        if size == 0:
            return None
        min = (E) heap[0]
        removeAt(0)
        return min
    def remove(self, o):
        """* Removes one occurrence of the specified element e (O(log n)) if present.
     * Uses the index map for O(1) lookup."""
        i = index[o]
        if i == None:
            return False
        removeAt(i)
        return True
    def contains(self, o):
        """O(1): returns whether the queue currently contains the given element reference."""
        return self.index.containsKey(o)
    def clear(self):
        """Clears the heap and the index map."""
        Arrays.fill(heap, 0, size, None)
        self.index.clear()
        size = 0
    def changeKey(self, e, mutator):
        """* Changes comparator-relevant fields of {@code e} via the provided {@code mutator},
     * then restores the heap in O(log n) by bubbling in the correct direction.
     *
     * <p><b>IMPORTANT:</b> The mutator must not change {@code equals/hashCode} of {@code e}
     * if you migrate this implementation to value-based indexing (HashMap).
     *
     * @throws IllegalArgumentException if {@code e} is not in the queue"""
        i = index[e]
        if i == None:
            raise ValueError("Element not in queue")
        mutator.accept(e)
        if not siftUp(i):
            siftDown(i)
    def decreaseKey(self, e, mutator):
        """* Faster variant if the new key is strictly smaller (higher priority).
     * Performs a single sift-up (O(log n))."""
        i = index[e]
        if i == None:
            raise ValueError("Element not in queue")
        mutator.accept(e)
        siftUp(i)
    def increaseKey(self, e, mutator):
        """* Faster variant if the new key is strictly larger (lower priority).
     * Performs a single sift-down (O(log n))."""
        i = index[e]
        if i == None:
            raise ValueError("Element not in queue")
        mutator.accept(e)
        siftDown(i)
    def grow(self, minCapacity):
        """Grows the internal array to accommodate at least {@code minCapacity}."""
        old = heap.length
        old + 2 if int pref = (old < 64) else old + (old >> 1)
        newCap = Math.max(minCapacity, pref)
        heap = Arrays.copyOf(heap, newCap)
    def compare(self, a, b):
        SuppressWarnings
        if cmp != None:
            return self.cmp.compare(a, b)
        return ((Comparable) a).compareTo(b)
    def siftUp(self, k, x):
        """* Inserts item {@code x} at position {@code k}, bubbling up while maintaining the heap.
     * Also maintains the index map for all moved elements."""
        SuppressWarnings
        while k > 0:
            p = (k - 1) >>> 1
            e = (E) heap[p]
            if compare(x, e) > = 0:
                break
            heap[k] = e
            self.index[e] = k
            k = p
        heap[k] = x
        self.index[x] = k
    def siftUp(self, k):
        """* Attempts to bubble up the element currently at {@code k}.
     * @return true if it moved; false otherwise."""
        SuppressWarnings
        orig = k
        x = (E) heap[k]
        while k > 0:
            p = (k - 1) >>> 1
            e = (E) heap[p]
            if compare(x, e) > = 0:
                break
            heap[k] = e
            self.index[e] = k
            k = p
        if k != orig:
            heap[k] = x
            self.index[x] = k
            return True
        return False
    def siftDown(self, k):
        """Bubbles down the element currently at {@code k}."""
        SuppressWarnings
        n = self.size
        x = (E) heap[k]
        half = n >>> 1
        while k < half:
            child = (k << 1) + 1
            c = (E) heap[child]
            r = child + 1
            if r < n and compare(c, (E) heap[r]) > 0:
                child = r
                c = (E) heap[child]
            if compare(x, c) < = 0:
                break
            heap[k] = c
            self.index[c] = k
            k = child
        heap[k] = x
        self.index[x] = k
    def removeAt(self, i):
        """* Removes the element at heap index {@code i}, restoring the heap afterwards.
     * <p>Returns nothing; the standard {@code PriorityQueue} returns a displaced
     * element in a rare case to help its iterator. We don't need that here, so
     * we keep the API simple."""
        SuppressWarnings
        n = --size
        moved = (E) heap[n]
        removed = (E) heap[i]
        heap[n] = None
        self.index.remove(removed)
        if i == n:
            return
        heap[i] = moved
        self.index[moved] = i
        if not siftUp(i):
            siftDown(i)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.950
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 51:12 expected an indented block
#    >         elif cmp is not None:
# 语法问题: [class IndexedPriorityQueue] 行 51 expected an indented block
#    >         elif cmp is not None:
# 未处理节点类型(Top):
#  - BlockStmt: 2
# 未映射方法(Top):
#  - IdentityHashMap.containsKey: 1
#  - Comparator.compare: 1
# --- 报告结束 ---
