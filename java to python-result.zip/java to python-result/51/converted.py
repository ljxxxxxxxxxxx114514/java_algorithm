# --- File: Map.java ---

# package: com.thealgorithms.datastructures.hashmap.hashing

class Map:
    def put(self, key, value):
        pass
    def get(self, key):
        pass
    def delete(self, key):
        pass
    def keys(self):
        pass
    def size(self):
        pass
    def contains(self, key):
        return get(key) != null
    def hash(self, key, size):
        return (key.hashCode() & Integer.MAX_VALUE) % size

if __name__ == "__main__":
    pass
