# --- File: SegmentTree.java ---

# package: com.thealgorithms.datastructures.trees

class SegmentTree:
    def __init__(self, n, arr):
        #  Constructor which takes the size of the array and the array as a parameter
        self.n = n
        x = (int) (Math.ceil(Math.log(n) / Math.log(2)))
        segSize = 2 * (int) Math.pow(2, x) - 1
        self.segTree =  new int[segSize]
        self.arr = arr
        self.n = n
        constructTree(arr, 0, n - 1, 0)
    def constructTree(self, arr, start, end, index):
        #  A function which will create the segment tree
        if start == end:
            self.segTree[index] = arr[start]
            return arr[start]
        mid = start + (end - start) / 2
        self.segTree[index] = constructTree(arr, start, mid, index * 2 + 1) + constructTree(arr, mid + 1, end, index * 2 + 2)
        return self.segTree[index]
    def updateTree(self, start, end, index, diff, segIndex):
        #  A function which will update the value at a index i. This will be called by the
        #     update function internally
        if index < start or index > end:
            return
        print(f"{str(self.segTree[segIndex])}{str(= diff)}")
        if start != end:
            mid = start + (end - start) / 2
            updateTree(start, mid, index, diff, segIndex * 2 + 1)
            updateTree(mid + 1, end, index, diff, segIndex * 2 + 2)
    def update(self, index, value):
        #  A function to update the value at a particular index
        if index < 0 or index > n:
            return
        diff = value - arr[index]
        arr[index] = value
        updateTree(0, n - 1, index, diff, 0)
    def getSumTree(self, start, end, qStart, qEnd, segIndex):
        #  A function to get the sum of the elements from index l to index r. This will be called
        #      * internally
        if qStart < = start and qEnd >= end:
            return self.segTree[segIndex]
        if qStart > end or qEnd < start:
            return 0
        mid = start + (end - start) / 2
        return (getSumTree(start, mid, qStart, qEnd, segIndex * 2 + 1) + getSumTree(mid + 1, end, qStart, qEnd, segIndex * 2 + 2))
    def getSum(self, start, end):
        #  A function to query the sum of the subarray [start...end]
        if start < 0 or end > n or start > end:
            return 0
        return getSumTree(0, n - 1, start, end, 0)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.982
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 10:32 invalid syntax
#    >         segSize = 2 * (int) Math.pow(2, x) - 1
# 语法问题: [class SegmentTree] 行 10 invalid syntax
#    >         segSize = 2 * (int) Math.pow(2, x) - 1
# --- 报告结束 ---
