# --- File: CreateBinaryTreeFromInorderPreorder.java ---

# package: com.thealgorithms.datastructures.trees

# import: com.thealgorithms.datastructures.trees.BinaryTree.Node

# import: java.util.HashMap

# import: java.util.Map

class CreateBinaryTreeFromInorderPreorder:
    """* Approach: Naive Solution: Create root node from first value present in
 * preorder traversal. Look for the index of root node's value in inorder
 * traversal. That will tell total nodes present in left subtree and right
 * subtree. Based on that index create left and right subtree. Complexity: Time:
 * O(n^2) for each node there is iteration to find index in inorder array Space:
 * Stack size = O(height) = O(lg(n))
 * <p>
 * Optimized Solution: Instead of iterating over inorder array to find index of
 * root value, create a hashmap and find out the index of root value.
 * Complexity: Time: O(n) hashmap reduced iteration to find index in inorder
 * array Space: O(n) space taken by hashmap"""
    def __init__(self):
        pass
    @staticmethod
    def createTree(preorder, inorder):
        if preorder == None or inorder == None:
            return None
        return createTree(preorder, inorder, 0, 0, inorder.length)
    @staticmethod
    def createTreeOptimized(preorder, inorder):
        if preorder == None or inorder == None:
            return None
        inorderMap = HashMap()
        for i in range(inorder.length):
            inorderMap[inorder[i]] = i
        return createTreeOptimized(preorder, inorderMap, 0, 0, inorder.length)
    @staticmethod
    def createTree(preorder, inorder, preStart, inStart, size):
        if size == 0:
            return None
        root = Node(preorder[preStart])
        i = inStart
        while not preorder[preStart].equals(inorder[i]):
            i += 1
        leftNodesCount = i - inStart
        rightNodesCount = size - leftNodesCount - 1
        root.left = createTree(preorder, inorder, preStart + 1, inStart, leftNodesCount)
        root.right = createTree(preorder, inorder, preStart + leftNodesCount + 1, i + 1, rightNodesCount)
        return root
    @staticmethod
    def createTreeOptimized(preorder, inorderMap, preStart, inStart, size):
        if size == 0:
            return None
        root = Node(preorder[preStart])
        i = inorderMap[preorder[preStart]]
        leftNodesCount = i - inStart
        rightNodesCount = size - leftNodesCount - 1
        root.left = createTreeOptimized(preorder, inorderMap, preStart + 1, inStart, leftNodesCount)
        root.right = createTreeOptimized(preorder, inorderMap, preStart + leftNodesCount + 1, i + 1, rightNodesCount)
        return root

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.897
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
