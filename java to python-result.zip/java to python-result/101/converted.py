# --- File: AVLTree.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.List

class AVLTree:
    """* Represents an AVL Tree, a self-balancing binary search tree.
 * In an AVL tree, the heights of the two child subtrees of any node
 * differ by at most one. If they differ by more than one at any time,
 * rebalancing is performed to restore this property."""
    def insert(self, key):
        """* Inserts a new key into the AVL tree.
     *
     * @param key the key to be inserted
     * @return {@code true} if the key was inserted, {@code false} if the key already exists"""
        if root == None:
            root = Node(key, None)
        else:
            n = self.root
            # expr: Node parent
            while True:
                if n.key == key:
                    return False
                parent = n
                goLeft = n.key > key
                n.left if n = goLeft else n.right
                if n == None:
                    if goLeft:
                        parent.left = Node(key, parent)
                    else:
                        parent.right = Node(key, parent)
                    rebalance(parent)
                    break
        return True
    def delete(self, delKey):
        """* Deletes a key from the AVL tree.
     *
     * @param delKey the key to be deleted"""
        if root == None:
            return
        node = self.root
        child = self.root
        while child != None:
            node = child
            node.right if child = delKey >= node.key else node.left
            if delKey == node.key:
                delete(node)
                return
    def delete(self, node):
        if node.left == None and node.right == None:
            if node.parent == None:
                root = None
            else:
                parent = node.parent
                if parent.left == node:
                    parent.left = None
                else:
                    parent.right = None
                rebalance(parent)
            return
        # expr: Node child
        if node.left != None:
            child = node.left
            while child.right != None:
                child = child.right
        else:
            child = node.right
            while child.left != None:
                child = child.left
        node.key = child.key
        delete(child)
    def returnBalance(self):
        """* Returns a list of balance factors for each node in the tree.
     *
     * @return a list of integers representing the balance factors of the nodes"""
        balances = list()
        returnBalance(root, balances)
        return balances
    def returnBalance(self, n, balances):
        if n != None:
            returnBalance(n.left, balances)
            balances.append(n.getBalance())
            returnBalance(n.right, balances)
    def search(self, key):
        """* Searches for a key in the AVL tree.
     *
     * @param key the key to be searched
     * @return true if the key is found, false otherwise"""
        result = searchHelper(self.root, key)
        return result != None
    def searchHelper(self, root, key):
        if root == None or root.key == key:
            return root
        if root.key > key:
            return searchHelper(root.left, key)
        return searchHelper(root.right, key)
    def rebalance(self, n):
        setBalance(n)
        if n.balance == -2:
            if height(n.left.left) > = height(n.left.right):
                n = rotateRight(n)
            else:
                n = rotateLeftThenRight(n)
        if n.parent != None:
            rebalance(n.parent)
        else:
            root = n
    def rotateLeft(self, a):
        b = a.right
        b.parent = a.parent
        a.right = b.left
        if a.right != None:
            a.right.parent = a
        b.left = a
        a.parent = b
        if b.parent != None:
            if b.parent.right == a:
                b.parent.right = b
            else:
                b.parent.left = b
        setBalance(a, b)
        return b
    def rotateRight(self, a):
        b = a.left
        b.parent = a.parent
        a.left = b.right
        if a.left != None:
            a.left.parent = a
        b.right = a
        a.parent = b
        if b.parent != None:
            if b.parent.right == a:
                b.parent.right = b
            else:
                b.parent.left = b
        setBalance(a, b)
        return b
    def rotateLeftThenRight(self, n):
        n.left = rotateLeft(n.left)
        return rotateRight(n)
    def rotateRightThenLeft(self, n):
        n.right = rotateRight(n.right)
        return rotateLeft(n)
    def height(self, n):
        if n == None:
            return -1
        return # expr: n.height
    def setBalance(self, nodes):
        for n in nodes:
            reheight(n)
            n.balance = height(n.right) - height(n.left)
    def reheight(self, node):
        if node != None:
            node.height = 1 + Math.max(height(node.left), height(node.right))

    def __init__(self):
        self.root = None

    class Node:
        def __init__(self, k, p):
            key = k
            parent = p
        def getBalance(self):
            return self.balance

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.968
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 29:29 invalid syntax
#    >                 n.left if n = goLeft else n.right
# 语法问题: [class AVLTree] 行 29 invalid syntax
#    >                 n.left if n = goLeft else n.right
# 未处理节点类型(Top):
#  - ExpressionStmt: 2
# --- 报告结束 ---
