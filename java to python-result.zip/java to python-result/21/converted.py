# --- File: TwoSat.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

# import: java.util.Arrays

# import: java.util.Stack

class TwoSat:
    """* This class implements a solution to the 2-SAT (2-Satisfiability) problem
 * using Kosaraju's algorithm to find strongly connected components (SCCs)
 * in the implication graph.
 *
 * <p>
 * <strong>Brief Idea:</strong>
 * </p>
 *
 * <pre>
 * 1. From each clause (a ∨ b), we can derive implications:
 *      (¬a → b) and (¬b → a)
 *
 * 2. We construct an implication graph using these implications.
 *
 * 3. For each variable x, its negation ¬x is also represented as a node.
 *    If x and ¬x belong to the same SCC, the expression is unsatisfiable.
 *
 * 4. Otherwise, we assign truth values based on the SCC order:
 *    If SCC(x) > SCC(¬x), then x = true; otherwise, x = false.
 * </pre>
 *
 * <p>
 * <strong>Complexities:</strong>
 * </p>
 * <ul>
 * <li>Time Complexity: O(n + m)</li>
 * <li>Space Complexity: O(n + m)</li>
 * </ul>
 * where {@code n} is the number of variables and {@code m} is the number of
 * clauses.
 *
 * <p>
 * <strong>Usage Example:</strong>
 * </p>
 *
 * <pre>
 * TwoSat twoSat = new TwoSat(5); // Initialize with 5 variables: x1, x2, x3, x4, x5
 *
 * // Add clauses
 * twoSat.addClause(1, false, 2, false); // (x1 ∨ x2)
 * twoSat.addClause(3, true, 2, false); // (¬x3 ∨ x2)
 * twoSat.addClause(4, false, 5, true); // (x4 ∨ ¬x5)
 *
 * twoSat.solve(); // Solve the problem
 *
 * if (twoSat.isSolutionExists()) {
 *     boolean[] solution = twoSat.getSolutions();
 *     for (int i = 1; i <= 5; i++) {
 *         System.out.println("x" + i + " = " + solution[i]);
 *     }
 * }
 * </pre>
 * <p><strong>Reference</strong></p>
 * <a href="https://cp-algorithms.com/graph/2SAT.html">CP Algorithm</a> <br></br>
 * <a href="https://en.wikipedia.org/wiki/2-satisfiability">Wikipedia - 2 SAT</a>
 * @author Shoyeb Ansari
 *
 * @see Kosaraju"""
    def __init__(self, numberOfVariables):
        """* Initializes the TwoSat solver with the given number of variables.
     *
     * @param numberOfVariables the number of boolean variables
     * @throws IllegalArgumentException if the number of variables is negative"""
        # 
     * Initializes the TwoSat solver with the given number of variables.
     *
     * @param numberOfVariables the number of boolean variables
     * @throws IllegalArgumentException if the number of variables is negative
     
        # expr: SuppressWarnings
        if numberOfVariables < 0:
            raise ValueError("Number of variables cannot be negative.")
        self.numberOfVariables = numberOfVariables
        n = 2 * numberOfVariables + 1
        graph = (ArrayList<Integer>[]) new ArrayList[n]
        graphTranspose = (ArrayList<Integer>[]) new ArrayList[n]
        for i in range(self.n):
            graph[i] = []
            graphTranspose[i] = []
        variableAssignments =  new boolean[numberOfVariables + 1]
    def addClause(self, a, isNegateA, b, isNegateB):
        """* Adds a clause of the form (a ∨ b) to the boolean expression.
     *
     * <p>
     * Example: To add (¬x₁ ∨ x₂), call:
     * </p>
     *
     * <pre>{@code
     * addClause(1, true, 2, false);
     * }</pre>
     *
     * @param a         the first variable (1 ≤ a ≤ numberOfVariables)
     * @param isNegateA {@code true} if variable {@code a} is negated
     * @param b         the second variable (1 ≤ b ≤ numberOfVariables)
     * @param isNegateB {@code true} if variable {@code b} is negated
     * @throws IllegalArgumentException if {@code a} or {@code b} are out of range"""
        # 
     * Adds a clause of the form (a ∨ b) to the boolean expression.
     *
     * <p>
     * Example: To add (¬x₁ ∨ x₂), call:
     * </p>
     *
     * <pre>{@code
     * addClause(1, true, 2, false);
     * }</pre>
     *
     * @param a         the first variable (1 ≤ a ≤ numberOfVariables)
     * @param isNegateA {@code true} if variable {@code a} is negated
     * @param b         the second variable (1 ≤ b ≤ numberOfVariables)
     * @param isNegateB {@code true} if variable {@code b} is negated
     * @throws IllegalArgumentException if {@code a} or {@code b} are out of range
     
        if a <= 0 || a > numberOfVariables:
            raise ValueError("Variable number must be between 1 and " + numberOfVariables)
        if b <= 0 || b > numberOfVariables:
            raise ValueError("Variable number must be between 1 and " + numberOfVariables)
        a = isNegateA ? negate(a) : a
        b = isNegateB ? negate(b) : b
        notA = negate(a)
        notB = negate(b)
        graph[notA].add(b)
        graph[notB].add(a)
        graphTranspose[b].add(notA)
        graphTranspose[a].add(notB)
    def solve(self):
        """* Solves the 2-SAT problem using Kosaraju's algorithm to find SCCs
     * and determines whether a satisfying assignment exists."""
        # 
     * Solves the 2-SAT problem using Kosaraju's algorithm to find SCCs
     * and determines whether a satisfying assignment exists.
     
        isSolved = true
        n = 2 * numberOfVariables + 1
        visited = new boolean[n]
        component = new int[n]
        topologicalOrder = Stack()
        for i in range(self.n):
            if !visited[i]:
                dfsForTopologicalOrder(i, visited, topologicalOrder)
        Arrays.fill(visited, false)
        sccId = 0
        while !topologicalOrder.isEmpty():
            node = topologicalOrder.pop()
            if !visited[node]:
                dfsForScc(node, visited, component, sccId)
                sccId += 1
        for i in range(= numberOfVariables):
            notI = negate(i)
            if component[i] == component[notI]:
                hasSolution = false
                return
            variableAssignments[i] = component[i] > component[notI]
    def isSolutionExists(self):
        """* Returns whether the given boolean formula is satisfiable.
     *
     * @return {@code true} if a solution exists; {@code false} otherwise
     * @throws Error if called before {@link #solve()}"""
        # 
     * Returns whether the given boolean formula is satisfiable.
     *
     * @return {@code true} if a solution exists; {@code false} otherwise
     * @throws Error if called before {@link #solve()}
     
        if !isSolved:
            raise Error("Please call solve() before checking for a solution.")
        return hasSolution
    def getSolutions(self):
        """* Returns one valid assignment of variables that satisfies the boolean formula.
     *
     * @return a boolean array where {@code result[i]} represents the truth value of
     *         variable {@code xᵢ}
     * @throws Error if called before {@link #solve()} or if no solution exists"""
        # 
     * Returns one valid assignment of variables that satisfies the boolean formula.
     *
     * @return a boolean array where {@code result[i]} represents the truth value of
     *         variable {@code xᵢ}
     * @throws Error if called before {@link #solve()} or if no solution exists
     
        # Unhandled node type: ArrayType
        if !isSolved:
            raise Error("Please call solve() before fetching the solution.")
        if !hasSolution:
            raise Error("No satisfying assignment exists for the given expression.")
        return variableAssignments.clone()
    def dfsForTopologicalOrder(self, u, visited, topologicalOrder):
        """Performs DFS to compute topological order."""
        #  Performs DFS to compute topological order. 
        visited[u] = true
        for v in graph[u]:
            if !visited[v]:
                dfsForTopologicalOrder(v, visited, topologicalOrder)
        topologicalOrder.append(u)
    def dfsForScc(self, u, visited, component, sccId):
        """Performs DFS on the transposed graph to identify SCCs."""
        #  Performs DFS on the transposed graph to identify SCCs. 
        visited[u] = true
        component[u] = sccId
        for v in graphTranspose[u]:
            if !visited[v]:
                dfsForScc(v, visited, component, sccId)
    def negate(self, a):
        """* Returns the index representing the negation of the given variable.
     *
     * <p>
     * Mapping rule:
     * </p>
     *
     * <pre>
     * For a variable i:
     *     negate(i) = i + n
     * For a negated variable (i + n):
     *     negate(i + n) = i
     * where n = numberOfVariables
     * </pre>
     *
     * @param a the variable index
     * @return the index representing its negation"""
        # 
     * Returns the index representing the negation of the given variable.
     *
     * <p>
     * Mapping rule:
     * </p>
     *
     * <pre>
     * For a variable i:
     *     negate(i) = i + n
     * For a negated variable (i + n):
     *     negate(i + n) = i
     * where n = numberOfVariables
     * </pre>
     *
     * @param a the variable index
     * @return the index representing its negation
     
        return a <= numberOfVariables ? a + numberOfVariables : a - numberOfVariables

if __name__ == "__main__":
    pass
