# --- File: SwapAdjacentBits.java ---

# package: com.thealgorithms.bitmanipulation

class SwapAdjacentBits:
    """* A utility class to swap every pair of adjacent bits in a given integer.
 * This operation shifts the even-positioned bits to odd positions and vice versa.
 *
 * Example:
 * - Input: 2 (binary: `10`) → Output: 1 (binary: `01`)
 * - Input: 43 (binary: `101011`) → Output: 23 (binary: `010111`)
 *
 * **Explanation of the Algorithm:**
 * 1. Mask even-positioned bits: Using `0xAAAAAAAA` (binary: `101010...`),
 *    which selects bits in even positions.
 * 2. Mask odd-positioned bits: Using `0x55555555` (binary: `010101...`),
 *    which selects bits in odd positions.
 * 3. Shift bits:
 *    - Right-shift even-positioned bits by 1 to move them to odd positions.
 *    - Left-shift odd-positioned bits by 1 to move them to even positions.
 * 4. Combine both shifted results using bitwise OR (`|`) to produce the final result.
 *
 * Use Case: This algorithm can be useful in applications involving low-level bit manipulation,
 * such as encoding, data compression, or cryptographic transformations.
 *
 * Time Complexity: O(1) (constant time, since operations are bitwise).
 *
 * Author: Lakshyajeet Singh Goyal (https://github.com/DarkMatter-999)"""
    def __init__(self):
        pass
    @staticmethod
    def swapAdjacentBits(num):
        """* Swaps every pair of adjacent bits of a given integer.
     * Steps:
     * 1. Mask the even-positioned bits.
     * 2. Mask the odd-positioned bits.
     * 3. Shift the even bits to the right and the odd bits to the left.
     * 4. Combine the shifted bits.
     *
     * @param num the integer whose bits are to be swapped
     * @return the integer after swapping every pair of adjacent bits"""
        evenBits = num & 0xAAAAAAAA
        oddBits = num & 0x55555555
        evenBits >> = 1
        oddBits << = 1
        return # expr: evenBits | oddBits

# --- File: TwosComplement.java ---

# package: com.thealgorithms.bitmanipulation

class TwosComplement:
    """* This class provides a method to compute the Two's Complement of a given binary number.
 *
 * <p>In two's complement representation, a binary number's negative value is obtained
 * by taking the one's complement (inverting all bits) and then adding 1 to the result.
 * This method handles both small and large binary strings and ensures the output is
 * correct for all binary inputs, including edge cases like all zeroes and all ones.
 *
 * <p>For more information on Two's Complement:
 * @see <a href="https://en.wikipedia.org/wiki/Two%27s_complement">Wikipedia - Two's Complement</a>
 *
 * <p>Algorithm originally suggested by Jon von Neumann.
 *
 * @author Abhinay Verma (https://github.com/Monk-AbhinayVerma)"""
    def __init__(self):
        pass
    @staticmethod
    def twosComplement(binary):
        """* Computes the Two's Complement of the given binary string.
     * Steps:
     * 1. Compute the One's Complement (invert all bits).
     * 2. Add 1 to the One's Complement to get the Two's Complement.
     * 3. Iterate from the rightmost bit to the left, adding 1 and carrying over as needed.
     * 4. If a carry is still present after the leftmost bit, prepend '1' to handle overflow.
     *
     * @param binary The binary number as a string (only '0' and '1' characters allowed).
     * @return The two's complement of the input binary string as a new binary string.
     * @throws IllegalArgumentException If the input contains non-binary characters."""
        if not binary.matches("[01]+"):
            raise ValueError("Input must contain only '0' and '1'.")
        onesComplement = StringBuilder()
        for bit in binary.toCharArray():
            '1' if onesComplement.append(bit == '0' else '0')
        twosComplement = StringBuilder(onesComplement)
        carry = True
        for i in range(onesComplement.length(), = 0 and carry, -1):
            if onesComplement.charAt(i) == '1':
                twosComplement.setCharAt(i, '0')
            else:
                twosComplement.setCharAt(i, '1')
                carry = False
        if carry:
            twosComplement.insert(0, '1')
        return twosComplement.toString()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.875
# 可解析度: 0.333 (1/3)
# 语法问题: 模块无法解析
#  - 行 44:21 invalid syntax
#    >         evenBits >> = 1
# 语法问题: [class SwapAdjacentBits] 行 44 invalid syntax
#    >         evenBits >> = 1
# 语法问题: [class TwosComplement] 行 84 invalid syntax
#    >             '1' if onesComplement.append(bit == '0' else '0')
# 未映射方法(Top):
#  - StringBuilder.setCharAt: 2
#  - StringBuilder.insert: 1
# --- 报告结束 ---
