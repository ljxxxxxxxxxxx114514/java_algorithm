# --- File: MatrixSearchAlgorithm.java ---

# package: com.thealgorithms.devutils.searches

import abc

class MatrixSearchAlgorithm(abc.ABC):
    """* The common interface of most searching algorithms that search in matrixes.
 *
 * @author Aitor Fidalgo (https://github.com/aitorfi)"""
    @abc.abstractmethod
    def find(self, matrix, key):
        raise NotImplementedError

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.625
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
