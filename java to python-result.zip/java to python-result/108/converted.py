# --- File: BSTRecursiveGeneric.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.List

class BSTRecursiveGeneric:
    """* <h1>Binary Search Tree (Recursive) Generic Type Implementation</h1>
 *
 * <p>
 * A recursive implementation of generic type BST.
 *
 * Reference: <a href="https://en.wikipedia.org/wiki/Binary_search_tree">Wiki links for BST</a>
 * </p>
 *
 * @author [Madhur Panwar](<a href="https://github.com/mdrpanwar">git-Madhur Panwar</a>)
 * @author [Udaya Krishnan M](<a href="https://github.com/UdayaKrishnanM/">git-Udaya Krishnan M</a>) {added prettyDisplay() method}"""
    def __init__(self):
        """* Constructor use to initialize node as null"""
        root = None
    def prettyDisplay(self):
        """* Displays the tree is a structured format"""
        prettyDisplay(root, 0)
    def prettyDisplay(self, node, level):
        if node == None:
            return
        prettyDisplay(node.right, level + 1)
        if level != 0:
            for i in range(level - 1):
                print("|\t", end="")
            print(f"|---->{str(node.data)}")
        else:
            print(node.data)
        prettyDisplay(node.left, level + 1)

def main(args=None):
    """* main function for testing"""
    if args is None:
        args = []
    print("Testing for integer data...")
    integerTree = BSTRecursiveGeneric()
    integerTree.append(5)
    integerTree.append(10)
    integerTree.append(-9)
    integerTree.append(4)
    integerTree.append(3)
    integerTree.append(1)
    print("Pretty Display of current tree is:")
    integerTree.prettyDisplay()
    # Unhandled node type: AssertStmt
    integerTree.remove(9)
    # Unhandled node type: AssertStmt
    integerTree.remove(1)
    # Unhandled node type: AssertStmt
    integerTree.append(20)
    integerTree.append(70)
    # Unhandled node type: AssertStmt
    print("Pretty Display of current tree is:")
    integerTree.prettyDisplay()
    integerTree.inorder()
    print("Pretty Display of current tree is:")
    integerTree.prettyDisplay()
    System.out.println()
    print("Testing for string data...")
    stringTree = BSTRecursiveGeneric()
    stringTree.append("banana")
    stringTree.append("apple")
    stringTree.append("pineapple")
    stringTree.append("date")
    # Unhandled node type: AssertStmt
    stringTree.remove("date")
    # Unhandled node type: AssertStmt
    stringTree.remove("boy")
    # Unhandled node type: AssertStmt
    stringTree.append("india")
    stringTree.append("hills")
    # Unhandled node type: AssertStmt
    print("Pretty Display of current tree is:")
    stringTree.prettyDisplay()
    stringTree.inorder()
    print("Pretty Display of current tree is:")
    stringTree.prettyDisplay()
def delete(self, node, data):
    """* Recursive method to delete a data if present in BST.
 *
 * @param node the node under which to (recursively) search for data
 * @param data the value to be deleted
 * @return Node the updated value of root parameter after delete operation"""
    if node == None:
        print("No such data present in BST.")
    return node
def insert(self, node, data):
    """* Recursive insertion of value in BST.
 *
 * @param node to check if the data can be inserted in current node or its
 * subtree
 * @param data the value to be inserted
 * @return the modified value of the root parameter after insertion"""
    if node == None:
        node = Node(data)
    return node
def preOrder(self, node):
    """* Recursively print Preorder traversal of the BST
 *
 * @param node the root node"""
    if node == None:
        return
    print(f"{str(node.data)} ", end="")
    if node.left != None:
        preOrder(node.left)
    if node.right != None:
        preOrder(node.right)
def postOrder(self, node):
    """* Recursively print Postorder traversal of BST.
 *
 * @param node the root node"""
    if node == None:
        return
    if node.left != None:
        postOrder(node.left)
    if node.right != None:
        postOrder(node.right)
    print(f"{str(node.data)} ", end="")
def inOrder(self, node):
    """* Recursively print Inorder traversal of BST.
 *
 * @param node the root node"""
    if node == None:
        return
    if node.left != None:
        inOrder(node.left)
    print(f"{str(node.data)} ", end="")
    if node.right != None:
        inOrder(node.right)
def inOrderSort(self, node, sortedList):
    """* Recursively traverse the tree using inorder traversal and keep adding
 * elements to argument list.
 *
 * @param node the root node
 * @param sortedList the list to add the srted elements into"""
    if node == None:
        return
    if node.left != None:
        inOrderSort(node.left, sortedList)
    sortedList.append(node.data)
    if node.right != None:
        inOrderSort(node.right, sortedList)
def search(self, node, data):
    """* Search recursively if the given value is present in BST or not.
 *
 * @param node the node under which to check
 * @param data the value to be checked
 * @return boolean if data is present or not"""
    if node == None:
        return False
def add(self, data):
    """* add in BST. if the value is not already present it is inserted or else no
 * change takes place.
 *
 * @param data the value to be inserted"""
    instance.root = insert(instance.root, data)
def remove(self, data):
    """* If data is present in BST delete it else do nothing.
 *
 * @param data the value to be removed"""
    instance.root = delete(instance.root, data)
def inorder(self):
    """* To call inorder traversal on tree"""
    print("Inorder traversal of this tree is:")
    inOrder(instance.root)
    System.out.println()
def inorderSort(self):
    """* return a sorted list by traversing the tree elements using inorder
 * traversal"""
    sortedList = list()
    inOrderSort(instance.root, sortedList)
    return sortedList
def postorder(self):
    """* To call postorder traversal on tree"""
    print("Postorder traversal of this tree is:")
    postOrder(instance.root)
    System.out.println()
def preorder(self):
    """* To call preorder traversal on tree."""
    print("Preorder traversal of this tree is:")
    preOrder(instance.root)
    System.out.println()
def find(self, data):
    """* To check if given value is present in tree or not.
 *
 * @param data the data to be found for"""
    if search(instance.root, data):
        print(f"{str(data)} is present in given BST.")
        return True
    print(f"{str(data)} not found.")
    return False

class Node:
    """* The generic Node class used for building binary search tree"""
    def __init__(self, d):
        """* Constructor with data as parameter"""
        data = d
        left = None
        right = None

if __name__ == "__main__":
    main()

# --- 转换测试报告 ---
# 转换效率: 0.982
# 可解析度: 1.000 (18/18)
# --- 报告结束 ---
