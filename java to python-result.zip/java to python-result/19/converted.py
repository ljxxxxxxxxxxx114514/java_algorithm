# --- File: PrimMST.java ---

# package: com.thealgorithms.datastructures.graphs

class PrimMST:
    """* A Java program for Prim's Minimum Spanning Tree (MST) algorithm.
 * Adjacency matrix representation of the graph."""
    V: int = 5
    def minKey(self, key, mstSet):
        """value, from the set of vertices not yet included in the MST"""
        #  value, from the set of vertices not yet included in the MST
        min = Integer.MAX_VALUE
        minIndex = -1
        for v in range(self.V):
            if !mstSet[v] && key[v] < min:
                min = key[v]
                minIndex = v
        return minIndex
    def primMST(self, graph):
        """Function to construct MST for a graph using adjacency matrix representation"""
        #  Function to construct MST for a graph using adjacency matrix representation
        # Unhandled node type: ArrayType
        parent = new int[V]
        key = new int[V]
        mstSet = new Boolean[V]
        for i in range(self.V):
            key[i] = Integer.MAX_VALUE
            mstSet[i] = Boolean.FALSE
        key[0] = 0
        parent[0] = -1
        for count in range(V - 1):
            u = minKey(key, mstSet)
            mstSet[u] = Boolean.TRUE
            for v in range(self.V):
                if graph[u][v] != 0 && !mstSet[v] && graph[u][v] < key[v]:
                    parent[v] = u
                    key[v] = graph[u][v]
        return parent

if __name__ == "__main__":
    pass
