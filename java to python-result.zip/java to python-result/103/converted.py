# --- File: BinaryTreeToString.java ---

# package: com.thealgorithms.datastructures.trees

class BinaryTreeToString:
    """* Leetcode 606: Construct String from Binary Tree:
 * https://leetcode.com/problems/construct-string-from-binary-tree/
 *
 * Utility class to convert a {@link BinaryTree} into its string representation.
 * <p>
 * The conversion follows a preorder traversal pattern (root → left → right)
 * and uses parentheses to denote the tree structure.
 * Empty parentheses "()" are used to explicitly represent missing left children
 * when a right child exists, ensuring the structure is unambiguous.
 * </p>
 *
 * <h2>Rules:</h2>
 * <ul>
 * <li>Each node is represented as {@code (value)}.</li>
 * <li>If a node has only a right child, include {@code ()} before the right
 * child
 * to indicate the missing left child.</li>
 * <li>If a node has no children, it appears as just {@code (value)}.</li>
 * <li>The outermost parentheses are removed from the final string.</li>
 * </ul>
 *
 * <h3>Example:</h3>
 *
 * <pre>
 *     Input tree:
 *           1
 *          / \
 *         2   3
 *          \
 *           4
 *
 *     Output string:
 *     "1(2()(4))(3)"
 * </pre>
 *
 * <p>
 * This implementation matches the logic from LeetCode problem 606:
 * <i>Construct String from Binary Tree</i>.
 * </p>
 *
 * @author Muhammad Junaid
 * @see BinaryTree"""
    def tree2str(self, root):
        """* Converts a binary tree (given its root node) to its string representation.
     *
     * @param root the root node of the binary tree
     * @return the string representation of the binary tree, or an empty string if
     *         the tree is null"""
        if root == None:
            return # expr: ""
        sb = StringBuilder()
        dfs(root)
        return self.sb.substring(1, sb.length() - 1)
    def dfs(self, node):
        """* Performs a recursive depth-first traversal to build the string.
     * Each recursive call appends the node value and its children (if any)
     * enclosed in parentheses.
     *
     * @param node the current node being processed"""
        if node == None:
            return
        self.sb.append("(").append(node.data)
        if node.left != None:
            dfs(node.left)
        if node.right != None and node.left == None:
            self.sb.append("()")
            dfs(node.right)
        self.sb.append(")")

    def __init__(self):
        self.sb = None

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.958
# 可解析度: 1.000 (2/2)
# 未映射方法(Top):
#  - StringBuilder.append: 3
#  - StringBuilder.substring: 1
# --- 报告结束 ---
