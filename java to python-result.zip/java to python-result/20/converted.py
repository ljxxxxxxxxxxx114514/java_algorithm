# --- File: TarjansAlgorithm.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

# import: java.util.List

# import: java.util.Stack

class TarjansAlgorithm:
    """* Java program that implements Tarjan's Algorithm to find Strongly Connected Components (SCCs) in a directed graph.
 *
 * <p>
 * Tarjan's algorithm is a linear time algorithm (O(V + E)) that identifies the SCCs of a directed graph.
 * An SCC is a maximal subgraph where every vertex is reachable from every other vertex within the subgraph.
 *
 * <h3>Algorithm Overview:</h3>
 * <ul>
 * <li>DFS Search: A depth-first search (DFS) is performed on the graph to generate a DFS tree.</li>
 * <li>Identification of SCCs: SCCs correspond to subtrees within this DFS tree.</li>
 * <li>Low-Link Values: For each node, a low-link value is maintained, which indicates the earliest visited
 * vertex (the one with the minimum insertion time) that can be reached from that subtree.</li>
 * <li>Stack Usage: Nodes are stored in a stack during DFS. When an SCC is identified, nodes are popped from
 * the stack until the head of the SCC is reached.</li>
 * </ul>
 *
 * <p>
 * Example of a directed graph:
 * <pre>
 *  0 --------> 1 -------> 3 --------> 4
 *  ^          /
 *  |         /
 *  |        /
 *  |       /
 *  |      /
 *  |     /
 *  |    /
 *  |   /
 *  |  /
 *  | /
 *  V
 *  2
 * </pre>
 *
 * <p>
 * For the above graph, the SCC list is as follows:
 * <ul>
 * <li>1, 2, 0</li>
 * <li>3</li>
 * <li>4</li>
 * </ul>
 * The order of nodes in an SCC does not matter as they form cycles.
 *
 * <h3>Comparison with Kosaraju's Algorithm:</h3>
 * <p>
 * Kosaraju's algorithm also identifies SCCs but does so using two DFS traversals.
 * In contrast, Tarjan's algorithm achieves this in a single DFS traversal, leading to improved performance
 * in terms of constant factors.
 * </p>"""
    def stronglyConnectedComponents(self, v, graph):
        """* Finds and returns the strongly connected components (SCCs) of the directed graph.
     *
     * @param v the number of vertices in the graph
     * @param graph the adjacency list representation of the graph
     * @return a list of lists, where each inner list represents a strongly connected component"""
        # 
     * Finds and returns the strongly connected components (SCCs) of the directed graph.
     *
     * @param v the number of vertices in the graph
     * @param graph the adjacency list representation of the graph
     * @return a list of lists, where each inner list represents a strongly connected component
     
        lowTime = new int[v]
        insertionTime = new int[v]
        for i in range(v):
            insertionTime[i] = -1
            lowTime[i] = -1
        isInStack = new boolean[v]
        st = Stack()
        for i in range(v):
            if insertionTime[i] == -1:
                stronglyConnCompsUtil(i, lowTime, insertionTime, isInStack, st, graph)
        return sccList
    def stronglyConnCompsUtil(self, u, lowTime, insertionTime, isInStack, st, graph):
        """* A utility function to perform DFS and find SCCs.
     *
     * @param u the current vertex being visited
     * @param lowTime array to keep track of the low-link values
     * @param insertionTime array to keep track of the insertion times
     * @param isInStack boolean array indicating if a vertex is in the stack
     * @param st the stack used for DFS
     * @param graph the adjacency list representation of the graph"""
        # 
     * A utility function to perform DFS and find SCCs.
     *
     * @param u the current vertex being visited
     * @param lowTime array to keep track of the low-link values
     * @param insertionTime array to keep track of the insertion times
     * @param isInStack boolean array indicating if a vertex is in the stack
     * @param st the stack used for DFS
     * @param graph the adjacency list representation of the graph
     
        insertionTime[u] = time
        lowTime[u] = time
        time += 1
        isInStack[u] = true
        st.append(u)
        for vertex in graph.get(u):
            if insertionTime[vertex] == -1:
                stronglyConnCompsUtil(vertex, lowTime, insertionTime, isInStack, st, graph)
                lowTime[u] = Math.min(lowTime[u], lowTime[vertex])
            else:
                lowTime[u] = Math.min(lowTime[u], insertionTime[vertex])
        if lowTime[u] == insertionTime[u]:
            pass
        else:
            w = -1
            scc = []
            while w != u:
                w = st.pop()
                scc.append(w)
                isInStack[w] = false
            sccList.append(scc)

    def __init__(self):
        self.time = None
        self.sccList = new ArrayList<>()

if __name__ == "__main__":
    pass
