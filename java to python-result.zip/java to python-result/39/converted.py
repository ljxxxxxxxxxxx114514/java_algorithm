# --- File: DisjointSetUnion.java ---

# package: com.thealgorithms.datastructures.disjointsetunion

class DisjointSetUnion:
    """* Disjoint Set Union (DSU), also known as Union-Find, is a data structure that tracks a set of elements
 * partitioned into disjoint (non-overlapping) subsets. It supports two primary operations efficiently:
 *
 * <ul>
 *     <li>Find: Determine which subset a particular element belongs to.</li>
 *     <li>Union: Merge two subsets into a single subset.</li>
 * </ul>
 *
 * @see <a href="https://en.wikipedia.org/wiki/Disjoint-set_data_structure">Disjoint Set Union (Wikipedia)</a>"""
    def makeSet(self, value):
        """* Creates a new disjoint set containing the single specified element.
     *
     * @param value the element to be placed in a new singleton set
     * @return a node representing the new set"""
        # 
     * Creates a new disjoint set containing the single specified element.
     *
     * @param value the element to be placed in a new singleton set
     * @return a node representing the new set
     
        return new Node<>(value)
    def findSet(self, node):
        """* Finds and returns the representative (root) of the set containing the given node.
     * This method applies path compression to flatten the tree structure for future efficiency.
     *
     * @param node the node whose set representative is to be found
     * @return the representative (root) node of the set"""
        # 
     * Finds and returns the representative (root) of the set containing the given node.
     * This method applies path compression to flatten the tree structure for future efficiency.
     *
     * @param node the node whose set representative is to be found
     * @return the representative (root) node of the set
     
        if node != node.parent:
            node.parent = findSet(node.parent)
        return node.parent
    def unionSets(self, x, y):
        """* Merges the sets containing the two given nodes. Union by rank is used to attach the smaller tree under the larger one.
     * If both sets have the same rank, one becomes the parent and its rank is incremented.
     *
     * @param x a node in the first set
     * @param y a node in the second set"""
        # 
     * Merges the sets containing the two given nodes. Union by rank is used to attach the smaller tree under the larger one.
     * If both sets have the same rank, one becomes the parent and its rank is incremented.
     *
     * @param x a node in the first set
     * @param y a node in the second set
     
        rootX = findSet(x)
        rootY = findSet(y)
        if rootX == rootY:
            return
        if rootX.rank > rootY.rank:
            rootX.rank
            rootY.rank
        else:
            rootY.parent = rootX

if __name__ == "__main__":
    pass
