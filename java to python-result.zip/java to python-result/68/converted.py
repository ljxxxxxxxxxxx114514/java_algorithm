# --- File: CreateAndDetectLoop.java ---

# package: com.thealgorithms.datastructures.lists

class CreateAndDetectLoop:
    """* CreateAndDetectLoop provides utility methods for creating and detecting loops
 * (cycles) in a singly linked list. Loops in a linked list are created by
 * connecting the "next" pointer of one node to a previous node in the list,
 * forming a cycle."""
    def __init__(self):
        """* Private constructor to prevent instantiation of this utility class."""
        raise UnsupportedOperationException("Utility class")
    @staticmethod
    def createLoop(head, position1, position2):
        """* Creates a loop in a linked list by connecting the next pointer of a node
     * at a specified starting position (position2) to another node at a specified
     * destination position (position1). If either position is invalid, no loop
     * will be created.
     *
     * @param head the head node of the linked list
     * @param position1 the position in the list where the loop should end
     * @param position2 the position in the list where the loop should start"""
        if position1 == 0 or position2 == 0:
            return
        node1 = head
        node2 = head
        count1 = 1
        count2 = 1
        while count1 < position1 and node1 != None:
            node1 = node1.next
            count1 += 1
        while count2 < position2 and node2 != None:
            node2 = node2.next
            count2 += 1
        if node1 != None and node2 != None:
            node2.next = node1
    @staticmethod
    def detectLoop(head):
        """* Detects the presence of a loop in the linked list using Floyd's cycle-finding
     * algorithm, also known as the "tortoise and hare" method.
     *
     * @param head the head node of the linked list
     * @return true if a loop is detected, false otherwise
     * @see <a href="https://en.wikipedia.org/wiki/Cycle_detection#Floyd's_tortoise_and_hare">
     *     Floyd's Cycle Detection Algorithm</a>"""
        sptr = head
        fptr = head
        while fptr != None and fptr.next != None:
            sptr = sptr.next
            fptr = fptr.next.next
            if sptr == fptr:
                return True
        return False

    class Node:
        """* Node represents an individual element in the linked list, containing
     * data and a reference to the next node."""
        def __init__(self, data):
            self.data = data
            next = None

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.977
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
