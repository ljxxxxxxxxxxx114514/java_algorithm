# --- File: Heap.java ---

# package: com.thealgorithms.datastructures.heaps

import abc

class Heap(abc.ABC):
    """* Interface common to heap data structures.<br>
 *
 * <p>
 * Heaps are tree-like data structures that allow storing elements in a specific
 * way. Each node corresponds to an element and has one parent node (except for
 * the root) and at most two children nodes. Every element contains a key, and
 * those keys indicate how the tree shall be built. For instance, for a
 * min-heap, the key of a node shall be greater than or equal to its parent's
 * and lower than or equal to its children's (the opposite rule applies to a
 * max-heap).
 *
 * <p>
 * All heap-related operations (inserting or deleting an element, extracting the
 * min or max) are performed in O(log n) time.
 *
 * @author Nicolas Renard"""
    @abc.abstractmethod
    def getElement(self):
        raise NotImplementedError
    @abc.abstractmethod
    def insertElement(self, element):
        raise NotImplementedError
    @abc.abstractmethod
    def deleteElement(self, elementIndex):
        raise NotImplementedError

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.625
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
