# --- File: HighestSetBit.java ---

# package: com.thealgorithms.bitmanipulation

# import: java.util.Optional

class HighestSetBit:
    """* Find Highest Set Bit
 *
 * This class provides a utility method to calculate the position of the highest
 * (most significant) bit that is set to 1 in a given non-negative integer.
 * It is often used in bit manipulation tasks to find the left-most set bit in binary
 * representation of a number.
 *
 * Example:
 * - For input 18 (binary 10010), the highest set bit is at position 4 (zero-based index).
 *
 * @author Bama Charan Chhandogi
 * @version 1.0
 * @since 2021-06-23"""
    def __init__(self):
        pass
    @staticmethod
    def findHighestSetBit(num):
        """* Finds the highest (most significant) set bit in the given integer.
     * The method returns the position (index) of the highest set bit as an {@link Optional}.
     *
     * - If the number is 0, no bits are set, and the method returns {@link Optional#empty()}.
     * - If the number is negative, the method throws {@link IllegalArgumentException}.
     *
     * @param num The input integer for which the highest set bit is to be found. It must be non-negative.
     * @return An {@link Optional} containing the index of the highest set bit (zero-based).
     *         Returns {@link Optional#empty()} if the number is 0.
     * @throws IllegalArgumentException if the input number is negative."""
        if num < 0:
            raise ValueError("Input cannot be negative")
        if num == 0:
            return Optional.empty()
        position = 0
        while num > 0:
            num >> = 1
            position += 1
        return Optional.of(position - 1)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.821
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 41:20 invalid syntax
#    >             num >> = 1
# 语法问题: [class HighestSetBit] 行 41 invalid syntax
#    >             num >> = 1
# --- 报告结束 ---
