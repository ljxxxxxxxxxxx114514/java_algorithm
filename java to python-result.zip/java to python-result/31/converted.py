# --- File: MRUCache.java ---

# package: com.thealgorithms.datastructures.caches

# import: java.util.HashMap

# import: java.util.Map

class MRUCache:
    """* Represents a Most Recently Used (MRU) Cache.
 * <p>
 * In contrast to the Least Recently Used (LRU) strategy, the MRU caching policy
 * evicts the most recently accessed items first. This class provides methods to
 * store key-value pairs and manage cache eviction based on this policy.
 *
 * For more information, refer to:
 * <a href="https://en.wikipedia.org/wiki/Cache_replacement_policies#Most_recently_used_(MRU)">MRU on Wikipedia</a>.
 *
 * @param <K> the type of keys maintained by this cache
 * @param <V> the type of values associated with the keys"""
    DEFAULT_CAP: int = 100
    def __init__(self, cap=None):
        """* Creates an MRUCache with the default capacity."""
        if cap is None:
            # 
     * Creates an MRUCache with the default capacity.
     
            setCapacity(DEFAULT_CAP)
        elif cap is not None:
            # 
     * Creates an MRUCache with a specified capacity.
     *
     * @param cap the maximum number of items the cache can hold
     
            setCapacity(cap)
    def setCapacity(self, newCapacity):
        """* Sets the capacity of the cache and evicts items if the new capacity
     * is less than the current number of items.
     *
     * @param newCapacity the new capacity to set"""
        # 
     * Sets the capacity of the cache and evicts items if the new capacity
     * is less than the current number of items.
     *
     * @param newCapacity the new capacity to set
     
        checkCapacity(newCapacity)
        while data.size() > newCapacity:
            Entry<K, V> evicted = evict()
            data.pop(evicted.getKey())
        self.cap = newCapacity
    def checkCapacity(self, capacity):
        """* Checks if the specified capacity is valid.
     *
     * @param capacity the capacity to check
     * @throws IllegalArgumentException if the capacity is less than or equal to zero"""
        # 
     * Checks if the specified capacity is valid.
     *
     * @param capacity the capacity to check
     * @throws IllegalArgumentException if the capacity is less than or equal to zero
     
        if capacity <= 0:
            raise ValueError("Capacity must be greater than 0!")
    def evict(self):
        """* Evicts the most recently used entry from the cache.
     *
     * @return the evicted entry
     * @throws RuntimeException if the cache is empty"""
        # 
     * Evicts the most recently used entry from the cache.
     *
     * @return the evicted entry
     * @throws RuntimeException if the cache is empty
     
        if head == null:
            raise Exception("Cache cannot be empty!")
        final Entry<K, V> evicted = self.tail
        tail = evicted.getPreEntry()
        if tail != null:
            tail.setNextEntry(null)
        evicted.setNextEntry(null)
        return evicted
    def get(self, key):
        """* Retrieves the value associated with the specified key.
     *
     * @param key the key whose associated value is to be returned
     * @return the value associated with the specified key, or null if the key does not exist"""
        # 
     * Retrieves the value associated with the specified key.
     *
     * @param key the key whose associated value is to be returned
     * @return the value associated with the specified key, or null if the key does not exist
     
        if !data.containsKey(key):
            return null
        final Entry<K, V> entry = data.get(key)
        moveEntryToLast(entry)
        return entry.getValue()
    def put(self, key, value):
        """* Associates the specified value with the specified key in the cache.
     * If the key already exists, its value is updated and the entry is moved to the most recently used position.
     * If the cache is full, the most recently used entry is evicted before adding the new entry.
     *
     * @param key   the key with which the specified value is to be associated
     * @param value the value to be associated with the specified key"""
        # 
     * Associates the specified value with the specified key in the cache.
     * If the key already exists, its value is updated and the entry is moved to the most recently used position.
     * If the cache is full, the most recently used entry is evicted before adding the new entry.
     *
     * @param key   the key with which the specified value is to be associated
     * @param value the value to be associated with the specified key
     
        if data.containsKey(key):
            final Entry<K, V> existingEntry = data.get(key)
            existingEntry.setValue(value)
            moveEntryToLast(existingEntry)
            return
        # expr: Entry<K, V> newEntry
        if data.size() == cap:
            newEntry = evict()
            data.pop(newEntry.getKey())
        else:
            newEntry = Entry()
        newEntry.setKey(key)
        newEntry.setValue(value)
        addNewEntry(newEntry)
        data[key] = newEntry
    def addNewEntry(self, newEntry):
        """* Adds a new entry to the cache and updates the head and tail pointers accordingly.
     *
     * @param newEntry the new entry to be added"""
        # 
     * Adds a new entry to the cache and updates the head and tail pointers accordingly.
     *
     * @param newEntry the new entry to be added
     
        if data.isEmpty():
            head = newEntry
            tail = newEntry
            return
        tail.setNextEntry(newEntry)
        newEntry.setPreEntry(tail)
        newEntry.setNextEntry(null)
        tail = newEntry
    def moveEntryToLast(self, entry):
        """* Moves the specified entry to the most recently used position in the cache.
     *
     * @param entry the entry to be moved"""
        # 
     * Moves the specified entry to the most recently used position in the cache.
     *
     * @param entry the entry to be moved
     
        if tail == entry:
            return
        final Entry<K, V> preEntry = entry.getPreEntry()
        final Entry<K, V> nextEntry = entry.getNextEntry()
        if preEntry != null:
            preEntry.setNextEntry(nextEntry)
        if nextEntry != null:
            nextEntry.setPreEntry(preEntry)
        if head == entry:
            head = nextEntry
        tail.setNextEntry(entry)
        entry.setPreEntry(tail)
        entry.setNextEntry(null)
        tail = entry

    class Entry:
        """* A nested class representing an entry in the cache, which holds a key-value pair
     * and references to the previous and next entries in the linked list structure.
     *
     * @param <I> the type of the key
     * @param <J> the type of the value"""
        def __init__(self, preEntry=None, nextEntry=None, key=None, value=None):
            if preEntry is None and nextEntry is None and key is None and value is None:
                pass
            elif preEntry is not None and nextEntry is not None and key is not None and value is not None:
                self.preEntry = preEntry
                self.nextEntry = nextEntry
                self.key = key
                self.value = value
        def getPreEntry(self):
            return preEntry
        def setPreEntry(self, preEntry):
            self.preEntry = preEntry
        def getNextEntry(self):
            return nextEntry
        def setNextEntry(self, nextEntry):
            self.nextEntry = nextEntry
        def getKey(self):
            return key
        def setKey(self, key):
            self.key = key
        def getValue(self):
            return value
        def setValue(self, value):
            self.value = value

if __name__ == "__main__":
    pass
