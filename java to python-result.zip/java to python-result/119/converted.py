# --- File: KDTree.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.Arrays

# import: java.util.Comparator

# import: java.util.Objects

# import: java.util.Optional

class KDTree:
    def __init__(self, k=None, points=None, pointsCoordinates=None):
        """* Constructor for empty KDTree
     *
     * @param k Number of dimensions"""
        if k is not None:
            self.k = k
        elif points is not None:
            if points.length == 0:
                raise ValueError("Points array cannot be empty")
            self.k = points[0].getDimension()
            for point in points:
                if point.getDimension():
                    raise ValueError("Points must have the same dimension")
            self.root = build(points, 0)
        elif pointsCoordinates is not None:
            if pointsCoordinates.length == 0:
                raise ValueError("Points array cannot be empty")
            self.k = pointsCoordinates[0].length
            points = Arrays.stream(pointsCoordinates).map(Point::new).toArray(Point[]::new)
            for point in points:
                if point.getDimension():
                    raise ValueError("Points must have the same dimension")
            self.root = build(points, 0)
    def getRoot(self):
        return self.root
    def build(self, points, depth):
        """* Builds the KDTree from the specified points
     *
     * @param points Array of initial points
     * @param depth The current depth of the tree
     *
     * @return The root of the KDTree"""
        if points.length == 0:
            return None
        axis = depth % k
        if points.length == 1:
            return Node(points[0], axis)
        sorted(points)
        median = points.length >> 1
        node = Node(points[median], axis)
        node.left = build(Arrays.copyOfRange(points, 0, median), depth + 1)
        node.right = build(Arrays.copyOfRange(points, median + 1, points.length), depth + 1)
        return node
    def insert(self, point):
        """* Insert a point into the KDTree
     *
     * @param point The point to insert
     *"""
        if point.getDimension():
            raise ValueError("Point has wrong dimension")
        root = insert(root, point, 0)
    def insert(self, root, point, depth):
        """* Insert a point into a subtree
     *
     * @param root The root of the subtree
     * @param point The point to insert
     * @param depth The current depth of the tree
     *
     * @return The root of the KDTree"""
        axis = depth % k
        if root == None:
            return Node(point, axis)
        if point.getCoordinate(axis) < root.getAxisCoordinate():
            root.left = insert(root.left, point, depth + 1)
        else:
            root.right = insert(root.right, point, depth + 1)
        return root
    def search(self, point):
        """* Search for Node corresponding to the specified point in the KDTree
     *
     * @param point The point to search for
     *
     * @return The Node corresponding to the specified point"""
        if point.getDimension():
            raise ValueError("Point has wrong dimension")
        return search(root, point)
    def search(self, root, point):
        """* Search for Node corresponding to the specified point in a subtree
     *
     * @param root The root of the subtree to search in
     * @param point The point to search for
     *
     * @return The Node corresponding to the specified point"""
        if root == None:
            return Optional.empty()
        if (root.point == point):
            return Optional.of(root)
        return search(root.getNearChild(point), point)
    def findMin(self, axis):
        """* Find a point with minimum value in specified axis in the KDTree
     *
     * @param axis The axis to find the minimum value in
     *
     * @return The point with minimum value in the specified axis"""
        return # expr: findMin(root, axis).point
    def findMin(self, root, axis):
        """* Find a point with minimum value in specified axis in a subtree
     *
     * @param root The root of the subtree to search in
     * @param axis The axis to find the minimum value in
     *
     * @return The Node with minimum value in the specified axis of the point"""
        if root == None:
            return None
        if root.getAxis():
            if root.left == None:
                return root
            return findMin(root.left, axis)
        else:
            left = findMin(root.left, axis)
            right = findMin(root.right, axis)
            candidates = { left, root, right }
            return Arrays.stream(candidates).filter(Objects::nonNull).min(lambda a: a.point.getCoordinate(axis)).orElse(None)
    def findMax(self, axis):
        """* Find a point with maximum value in specified axis in the KDTree
     *
     * @param axis The axis to find the maximum value in
     *
     * @return The point with maximum value in the specified axis"""
        return # expr: findMax(root, axis).point
    def findMax(self, root, axis):
        """* Find a point with maximum value in specified axis in a subtree
     *
     * @param root The root of the subtree to search in
     * @param axis The axis to find the maximum value in
     *
     * @return The Node with maximum value in the specified axis of the point"""
        if root == None:
            return None
        if root.getAxis():
            if root.right == None:
                return root
            return findMax(root.right, axis)
        else:
            left = findMax(root.left, axis)
            right = findMax(root.right, axis)
            candidates = { left, root, right }
            return Arrays.stream(candidates).filter(Objects::nonNull).max(lambda a: a.point.getCoordinate(axis)).orElse(None)
    def delete(self, point):
        """* Delete the node with the given point.
     *
     * @param point the point to delete
     *"""
        node = search(point).orElseThrow(() -> IllegalArgumentException("Point not found"))
        root = delete(root, node)
    def delete(self, root, node):
        """* Delete the specified node from a subtree.
     *
     * @param root The root of the subtree to delete from
     * @param node The node to delete
     *
     * @return The new root of the subtree"""
        if root == None:
            return None
        if (root == node):
            if root.right != None:
                min = findMin(root.right, root.getAxis())
                root.point = min.point
                root.right = delete(root.right, min)
        if root.getAxisCoordinate():
            root.left = delete(root.left, node)
        else:
            root.right = delete(root.right, node)
        return root
    def findNearest(self, point):
        """* Finds the nearest point in the tree to the given point.
     *
     * @param point The point to find the nearest neighbor to.
     *"""
        return # expr: findNearest(root, point, root).point
    def findNearest(self, root, point, nearest):
        """* Finds the nearest point in a subtree to the given point.
     *
     * @param root The root of the subtree to search in.
     * @param point The point to find the nearest neighbor to.
     * @param nearest The nearest neighbor found so far.
     *"""
        if root == None:
            return nearest
        if (root.point == point):
            return root
        distance = Point.comparableDistance(root.point, point)
        distanceExceptAxis = Point.comparableDistanceExceptAxis(root.point, point, root.getAxis())
        if distance < Point.comparableDistance(nearest.point, point):
            nearest = root
        nearest = findNearest(root.getNearChild(point), point, nearest)
        if distanceExceptAxis < Point.comparableDistance(nearest.point, point):
            nearest = findNearest(root.getFarChild(point), point, nearest)
        return nearest

    class Point:
        def __init__(self, coordinates):
            self.coordinates = coordinates
        def getCoordinate(self, i):
            return coordinates[i]
        def getDimension(self):
            return # expr: coordinates.length
        def equals(self, obj):
            Override
            if obj instanceof Point other:
                return Arrays.equals(other.coordinates, self.coordinates)
            return False
        def hashCode(self):
            Override
            return Arrays.hashCode(coordinates)
        def toString(self):
            Override
            return str(coordinates)
        @staticmethod
        def comparableDistance(p1, p2):
            """* Find the comparable distance between two points (without SQRT)
         *
         * @param p1 First point
         * @param p2 Second point
         *
         * @return The comparable distance between the two points"""
            distance = 0
            for i in range(p1.getDimension()):
                t = p1.getCoordinate(i) - p2.getCoordinate(i)
                print(f"{str(distance)}{str(= t * t)}")
            return distance
        @staticmethod
        def comparableDistanceExceptAxis(p1, p2, axis):
            """* Find the comparable distance between two points with ignoring specified axis
         *
         * @param p1 First point
         * @param p2 Second point
         * @param axis The axis to ignore
         *
         * @return The distance between the two points"""
            distance = 0
            for i in range(p1.getDimension()):
                if i == axis:
                    continue
                t = p1.getCoordinate(i) - p2.getCoordinate(i)
                print(f"{str(distance)}{str(= t * t)}")
            return distance

    class Node:
        def __init__(self, point, axis):
            self.point = point
            self.axis = axis
        def getPoint(self):
            return self.point
        def getLeft(self):
            return self.left
        def getRight(self):
            return self.right
        def getAxis(self):
            return self.axis
        def getNearChild(self, point):
            """* Get the nearest child according to the specified point
         *
         * @param point The point to find the nearest child to
         *
         * @return The nearest child Node"""
            if point.getCoordinate(axis) < self.point.getCoordinate(axis):
                return self.left
            else:
                return self.right
        def getFarChild(self, point):
            """* Get the farthest child according to the specified point
         *
         * @param point The point to find the farthest child to
         *
         * @return The farthest child Node"""
            if point.getCoordinate(axis) < self.point.getCoordinate(axis):
                return self.right
            else:
                return self.left
        def getAxisCoordinate(self):
            """* Get the node axis coordinate of point
         *
         * @return The axis coordinate of the point"""
            return self.point.getCoordinate(axis)

#
#  * K-D Tree Implementation
#  * Wikipedia: https://en.wikipedia.org/wiki/K-d_tree
#  *
#  * Author: Amir Hosseini (https://github.com/itsamirhn)
#  *

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.978
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 32:64 invalid syntax
#    >             points = Arrays.stream(pointsCoordinates).map(Point::new).toArray(Point[]::new)
# 语法问题: [class KDTree] 行 32 invalid syntax
#    >             points = Arrays.stream(pointsCoordinates).map(Point::new).toArray(Point[]::new)
# 未映射方法(Top):
#  - Point.getCoordinate: 3
# --- 报告结束 ---
