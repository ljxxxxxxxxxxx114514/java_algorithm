# --- File: NQueens.java ---

# package: com.thealgorithms.backtracking

# import: java.util.ArrayList

# import: java.util.List

class NQueens:
    """* Problem statement: Given a N x N chess board. Return all arrangements in
 * which N queens can be placed on the board such no two queens attack each
 * other. Ex. N = 6 Solution= There are 4 possible ways Arrangement: 1 ".Q....",
 * "...Q..", ".....Q", "Q.....", "..Q...", "....Q."
 *
 * Arrangement: 2 "..Q...", ".....Q", ".Q....", "....Q.", "Q.....", "...Q.."
 *
 * Arrangement: 3 "...Q..", "Q.....", "....Q.", ".Q....", ".....Q", "..Q..."
 *
 * Arrangement: 4 "....Q.", "..Q...", "Q.....", ".....Q", "...Q..", ".Q...."
 *
 * Solution: Brute Force approach:
 *
 * Generate all possible arrangement to place N queens on N*N board. Check each
 * board if queens are placed safely. If it is safe, include arrangement in
 * solution set. Otherwise, ignore it
 *
 * Optimized solution: This can be solved using backtracking in below steps
 *
 * Start with first column and place queen on first row Try placing queen in a
 * row on second column If placing second queen in second column attacks any of
 * the previous queens, change the row in second column otherwise move to next
 * column and try to place next queen In case if there is no rows where a queen
 * can be placed such that it doesn't attack previous queens, then go back to
 * previous column and change row of previous queen. Keep doing this until last
 * queen is not placed safely. If there is no such way then return an empty list
 * as solution"""
    def __init__(self):
        pass
    @staticmethod
    def getNQueensArrangements(queens):
        arrangements = list()
        getSolution(queens, arrangements, [None] * queens, 0)
        return arrangements
    @staticmethod
    def placeQueens(queens):
        arrangements = list()
        getSolution(queens, arrangements, [None] * queens, 0)
        if arrangements.isEmpty():
            print("There is no way to place " + str(queens) + " queens on board of size " + str(queens) + "x" + str(queens))
        else:
            print("Arrangement for placing " + str(queens) + " queens")
        for arrangement in arrangements:
            arrangement.forEach(System.out::println)
            System.out.println()
    @staticmethod
    def getSolution(boardSize, solutions, columns, columnIndex):
        """* This is backtracking function which tries to place queen recursively
     *
     * @param boardSize: size of chess board
     * @param solutions: this holds all possible arrangements
     * @param columns: columns[i] = rowId where queen is placed in ith column.
     * @param columnIndex: This is the column in which queen is being placed"""
        if columnIndex == boardSize:
            sol = list()
            for i in range(boardSize):
                sb = StringBuilder()
                for j in range(boardSize):
                    "Q" if sb.append(j == columns[i] else ".")
                sol.append(sb.toString())
            solutions.append(sol)
            return
        for rowIndex in range(boardSize):
            columns[columnIndex] = rowIndex
            if isPlacedCorrectly(columns, rowIndex, columnIndex):
                getSolution(boardSize, solutions, columns, columnIndex + 1)
    @staticmethod
    def isPlacedCorrectly(columns, rowIndex, columnIndex):
        """* This function checks if queen can be placed at row = rowIndex in column =
     * columnIndex safely
     *
     * @param columns: columns[i] = rowId where queen is placed in ith column.
     * @param rowIndex: row in which queen has to be placed
     * @param columnIndex: column in which queen is being placed
     * @return true: if queen can be placed safely false: otherwise"""
        for i in range(columnIndex):
            diff = Math.abs(columns[i] - rowIndex)
            if diff == 0 or columnIndex - i == diff:
                return False
        return True

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.914
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 53:43 invalid syntax
#    >             arrangement.forEach(System.out::println)
# 语法问题: [class NQueens] 行 53 invalid syntax
#    >             arrangement.forEach(System.out::println)
# --- 报告结束 ---
