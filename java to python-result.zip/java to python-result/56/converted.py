# --- File: HeapElement.java ---

# package: com.thealgorithms.datastructures.heaps

class HeapElement:
    """* Class representing an element in a heap.
 *
 * <p>
 * A heap element contains two attributes: a key used for ordering in the heap
 * (which can be of type int or double, either as primitive types or as wrapper objects)
 * and an additional immutable object that can store any supplementary information the user desires.
 * Note that using mutable objects may compromise the integrity of this information.
 * </p>
 *
 * <p>
 * The key attribute is used to determine the order of elements in the heap,
 * while the additionalInfo attribute can carry user-defined data associated with the key.
 * </p>
 *
 * <p>
 * This class provides multiple constructors to accommodate various key types and includes
 * methods to retrieve the key and additional information.
 * </p>
 *
 * @author Nicolas Renard"""
    def __init__(self, key=None, info=None):
        """* Creates a HeapElement with the specified key and additional information.
     *
     * @param key  the key of the element (primitive type double)
     * @param info any immutable object containing additional information, may be null"""
        if key is not None and info is not None:
            self.key = key
            self.additionalInfo = info
        elif key is not None and info is not None:
            self.key = key
            self.additionalInfo = info
        elif key is not None and info is not None:
            self.key = key
            self.additionalInfo = info
        elif key is not None and info is not None:
            self.key = key
            self.additionalInfo = info
        elif key is not None:
            self.key = key
            self.additionalInfo = None
        elif key is not None:
            self.key = key
            self.additionalInfo = None
        elif key is not None:
            self.key = key
            self.additionalInfo = None
        elif key is not None:
            self.key = key
            self.additionalInfo = None
    def getInfo(self):
        """* Returns the object containing the additional information provided by the user.
     *
     * @return the additional information"""
        return self.additionalInfo
    def getKey(self):
        """* Returns the key value of the element.
     *
     * @return the key of the element"""
        return self.key
    def toString(self):
        """* Returns a string representation of the heap element.
     *
     * @return a string describing the key and additional information"""
        Override
        return self.additionalInfo.toString()
    def equals(self, o):
        """* @param o : an object to compare with the current element
     * @return true if the keys on both elements are identical and the
     * additional info objects are identical."""
        Override
        if o instanceof HeapElement otherHeapElement:
            return (self.additionalInfo == otherHeapElement.additionalInfo) if self.key == otherHeapElement.key and (self.additionalInfo != None else otherHeapElement.additionalInfo == None)
        return False
    def hashCode(self):
        """* Returns a hash code value for the heap element.
     *
     * @return a hash code value for this heap element"""
        Override
        result = 31 * (int) key
        self.additionalInfo.hashCode()
        return result
    def getValue(self):
        return self.additionalInfo.toString()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.982
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 76:23 invalid syntax
#    >         if o instanceof HeapElement otherHeapElement:
# 语法问题: [class HeapElement] 行 76 invalid syntax
#    >         if o instanceof HeapElement otherHeapElement:
# --- 报告结束 ---
