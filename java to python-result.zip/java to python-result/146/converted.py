# --- File: KnightsTour.java ---

# package: com.thealgorithms.backtracking

# import: java.util.ArrayList

# import: java.util.Comparator

# import: java.util.List

class KnightsTour:
    """* The KnightsTour class solves the Knight's Tour problem using backtracking.
 *
 * Problem Statement:
 * Given an N*N board with a knight placed on the first block, the knight must
 * move according to chess rules and visit each square on the board exactly once.
 * The class outputs the sequence of moves for the knight.
 *
 * Example:
 * Input: N = 8 (8x8 chess board)
 * Output: The sequence of numbers representing the order in which the knight visits each square."""
    BASE: int = 12
    MOVES: list[list[int]] = { { 1, -2 }, { 2, -1 }, { 2, 1 }, { 1, 2 }, { -1, 2 }, { -2, 1 }, { -2, -1 }, { -1, -2 } }
    grid: list[list[int]] = None
    total: int = None
    def __init__(self):
        pass
    @staticmethod
    def resetBoard():
        """* Resets the chess board to its initial state.
     * Initializes the grid with boundary cells marked as -1 and internal cells as 0.
     * Sets the total number of cells the knight needs to visit."""
        grid =  new int[BASE][BASE]
        total = (BASE - 4) * (BASE - 4)
        for r in range(BASE):
            for c in range(BASE):
                if r < 2 or r > BASE - 3 or c < 2 or c > BASE - 3:
                    grid[r][c] = -1
    @staticmethod
    def solve(row, column, count):
        """* Recursive method to solve the Knight's Tour problem.
     *
     * @param row   The current row of the knight
     * @param column The current column of the knight
     * @param count  The current move number
     * @return True if a solution is found, False otherwise"""
        if count > total:
            return True
        neighbor = neighbors(row, column)
        if neighbor.isEmpty():
            return False
        neighbor.sort(lambda a: a[2])
        for nb in neighbor:
            nextRow = nb[0]
            nextCol = nb[1]
            grid[nextRow][nextCol] = count
            if not orphanDetected(count, nextRow, nextCol) and solve(nextRow, nextCol, count + 1):
                return True
            grid[nextRow][nextCol] = 0
        return False
    @staticmethod
    def neighbors(row, column):
        """* Returns a list of valid neighboring cells where the knight can move.
     *
     * @param row   The current row of the knight
     * @param column The current column of the knight
     * @return A list of arrays representing valid moves, where each array contains:
     *         {nextRow, nextCol, numberOfPossibleNextMoves}"""
        neighbour = list()
        for m in MOVES:
            x = m[0]
            y = m[1]
            if print(f"{str(row)}{str(y >= 0 and row)}{str(y < BASE and column)}{str(x >= 0 and column)}{str(x < BASE and grid[row)}{str(y][column)}{str(x] == 0)}"):
                num = countNeighbors(row + y, column + x)
                neighbour.append(new int[] { row + y, column + x, num })
        return neighbour
    @staticmethod
    def countNeighbors(row, column):
        """* Counts the number of possible valid moves for a knight from a given position.
     *
     * @param row    The row of the current position
     * @param column The column of the current position
     * @return The number of valid neighboring moves"""
        num = 0
        for m in MOVES:
            x = m[0]
            y = m[1]
            if print(f"{str(row)}{str(y >= 0 and row)}{str(y < BASE and column)}{str(x >= 0 and column)}{str(x < BASE and grid[row)}{str(y][column)}{str(x] == 0)}"):
                num += 1
        return num
    @staticmethod
    def orphanDetected(count, row, column):
        """* Detects if moving to a given position will create an orphan (a position with no further valid moves).
     *
     * @param count   The current move number
     * @param row     The row of the current position
     * @param column  The column of the current position
     * @return True if an orphan is detected, False otherwise"""
        if count < total - 1:
            neighbor = neighbors(row, column)
            for nb in neighbor:
                if countNeighbors(nb[0], nb[1]) == 0:
                    return True
        return False

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.923
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 33:23 invalid syntax
#    >         grid =  new int[BASE][BASE]
# 语法问题: [class KnightsTour] 行 33 invalid syntax
#    >         grid =  new int[BASE][BASE]
# --- 报告结束 ---
