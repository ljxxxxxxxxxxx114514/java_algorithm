# --- File: CountLeadingZeros.java ---

# package: com.thealgorithms.bitmanipulation

class CountLeadingZeros:
    """* CountLeadingZeros class contains a method to count the number of leading zeros in the binary representation of a number.
 * The number of leading zeros is the number of zeros before the leftmost 1 bit.
 * For example, the number 5 has 29 leading zeros in its 32-bit binary representation.
 * The number 0 has 32 leading zeros.
 * The number 1 has 31 leading zeros.
 * The number -1 has no leading zeros.
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def countLeadingZeros(num):
        """* Counts the number of leading zeros in the binary representation of a number.
     * Method: Keep shifting the mask to the right until the leftmost bit is 1.
     * The number of shifts is the number of leading zeros.
     *
     * @param num The input number.
     * @return The number of leading zeros."""
        if num == 0:
            return 32
        count = 0
        mask = 1 << 31
        while (mask & num) == 0:
            count += 1
            mask >>> = 1
        return count

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.854
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 30:20 invalid syntax
#    >             mask >>> = 1
# 语法问题: [class CountLeadingZeros] 行 30 invalid syntax
#    >             mask >>> = 1
# --- 报告结束 ---
