# --- File: BitSwap.java ---

# package: com.thealgorithms.bitmanipulation

class BitSwap:
    """* Utility class for performing bit-swapping operations on integers.
 * This class cannot be instantiated."""
    def __init__(self):
        pass
    @staticmethod
    def bitSwap(data, posA, posB):
        if posA < 0 or posA > = Integer.SIZE or posB < 0 or posB >= Integer.SIZE:
            raise ValueError("Bit positions must be between 0 and 31")
        bitA = ((data >> posA) & 1) != 0
        bitB = ((data >> posB) & 1) != 0
        if bitA != bitB:
            data ^ = (1 << posA) ^ (1 << posB)
        return data

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.841
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 12:31 invalid syntax
#    >         if posA < 0 or posA > = Integer.SIZE or posB < 0 or posB >= Integer.SIZE:
# 语法问题: [class BitSwap] 行 12 invalid syntax
#    >         if posA < 0 or posA > = Integer.SIZE or posB < 0 or posB >= Integer.SIZE:
# --- 报告结束 ---
