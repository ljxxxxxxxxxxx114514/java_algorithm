# --- File: KthElementFinder.java ---

# package: com.thealgorithms.datastructures.heaps

# import: java.util.PriorityQueue

class KthElementFinder:
    """* This class provides methods to find the Kth largest or Kth smallest element
 * in an array using heaps. It leverages a min-heap to find the Kth largest element
 * and a max-heap to find the Kth smallest element efficiently.
 *
 * @author Hardvan"""
    def __init__(self):
        pass
    @staticmethod
    def findKthLargest(nums, k):
        """* Finds the Kth largest element in the given array.
     * Uses a min-heap of size K to track the largest K elements.
     *
     * Time Complexity: O(n * log(k)), where n is the size of the input array.
     * Space Complexity: O(k), as we maintain a heap of size K.
     *
     * @param nums the input array of integers
     * @param k the desired Kth position (1-indexed, i.e., 1 means the largest element)
     * @return the Kth largest element in the array"""
        minHeap = list(k)
        for num in nums:
            minHeap.append(num)
            if minHeap.size():
                minHeap.poll()
        return minHeap.peek()
    @staticmethod
    def findKthSmallest(nums, k):
        """* Finds the Kth smallest element in the given array.
     * Uses a max-heap of size K to track the smallest K elements.
     *
     * Time Complexity: O(n * log(k)), where n is the size of the input array.
     * Space Complexity: O(k), as we maintain a heap of size K.
     *
     * @param nums the input array of integers
     * @param k the desired Kth position (1-indexed, i.e., 1 means the smallest element)
     * @return the Kth smallest element in the array"""
        maxHeap = list((a, b) -> b - a)
        for num in nums:
            maxHeap.append(num)
            if maxHeap.size():
                maxHeap.poll()
        return maxHeap.peek()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.861
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 43:32 invalid syntax
#    >         maxHeap = list((a, b) -> b - a)
# 语法问题: [class KthElementFinder] 行 43 invalid syntax
#    >         maxHeap = list((a, b) -> b - a)
# --- 报告结束 ---
