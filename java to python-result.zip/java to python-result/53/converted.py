# --- File: FibonacciHeap.java ---

# package: com.thealgorithms.datastructures.heaps

class FibonacciHeap:
    """* The {@code FibonacciHeap} class implements a Fibonacci Heap data structure,
 * which is a collection of trees that satisfy the minimum heap property.
 * This heap allows for efficient merging of heaps, as well as faster
 * decrease-key and delete operations compared to other heap data structures.
 *
 * <p>Key features of the Fibonacci Heap include:
 * <ul>
 *   <li>Amortized O(1) time complexity for insert and decrease-key operations.</li>
 *   <li>Amortized O(log n) time complexity for delete and delete-min operations.</li>
 *   <li>Meld operation that combines two heaps in O(1) time.</li>
 *   <li>Potential function that helps analyze the amortized time complexity.</li>
 * </ul>
 *
 * <p>This implementation maintains additional statistics such as the total number
 * of link and cut operations performed during the lifetime of the heap, which can
 * be accessed through static methods.
 *
 * <p>The Fibonacci Heap is composed of nodes represented by the inner class
 * {@code HeapNode}. Each node maintains a key, rank, marked status, and pointers
 * to its children and siblings. Nodes can be linked and cut as part of the heap
 * restructuring processes.
 *
 * @see HeapNode"""
    GOLDEN_RATIO: float = (1 + Math.sqrt(5)) / 2
    totalLinks: int = 0
    totalCuts: int = 0
    def __init__(self, key=None):
        if key is None:
            #
            #      * a constructor for an empty Heap
            #      * set the min to be null
            #
            self.min = None
        elif key is not None:
            #
            #      * a constructor for a Heap with one element
            #      * set the min to be the HeapNode with the given key
            #      * @pre key>=0
            #      * @post empty == false
            #
            self.min = HeapNode(key)
            self.numOfTrees += 1
            self.numOfHeapNodes += 1
    def empty(self):
        #
        #      * check if the heap is empty
        #      * $ret == true - if the tree is empty
        #
        return (self.min == None)
    def insert(self, key):
        """* Creates a node (of type HeapNode) which contains the given key, and inserts it into the heap.
     *
     * @pre key>=0
     * @post (numOfnodes = = $prev numOfnodes + 1)
     * @post empty == false
     * $ret = the HeapNode we inserted"""
        toInsert = HeapNode(key)
        if this.empty():
            self.min = toInsert
        else:
            self.min.setNext(toInsert)
            self.updateMin(toInsert)
        self.numOfHeapNodes += 1
        self.numOfTrees += 1
        return toInsert
    def deleteMin(self):
        """* Delete the node containing the minimum key in the heap
     * updates new min
     *
     * @post (numOfnodes = = $prev numOfnodes - 1)"""
        if this.empty():
            return
        if self.numOfHeapNodes == 1:
            self.min = None
            self.numOfTrees -= 1
            self.numOfHeapNodes -= 1
            return
        if self.min.child != None:
            child = self.min.child
            tmpChild = child
            child.parent = None
            while child.next != tmpChild:
                child = child.next
                child.parent = None
        if self.numOfTrees > 1:
            (self.min.prev).next = self.min.next
            (self.min.next).prev = self.min.prev
            if self.min.child != None:
                (self.min.prev).setNext(self.min.child)
        else:
            self.min = self.min.child
        self.numOfHeapNodes -= 1
        self.successiveLink(self.min.getNext())
    def findMin(self):
        """* Return the node of the heap whose key is minimal.
     * $ret == null if (empty==true)"""
        return # expr: self.min
    def meld(self, heap2):
        """* Meld the heap with heap2
     *
     * @pre heap2 != null
     * @post (numOfnodes = = $prev numOfnodes + heap2.numOfnodes)"""
        if heap2.empty():
            return
        if this.empty():
            self.min = heap2.min
        else:
            self.min.setNext(heap2.min)
            self.updateMin(heap2.min)
        print(f"{str(self.numOfTrees)}{str(= heap2.numOfTrees)}")
        print(f"{str(self.numOfHeapNodes)}{str(= heap2.numOfHeapNodes)}")
    def size(self):
        """* Return the number of elements in the heap
     * $ret == 0 if heap is empty"""
        return # expr: self.numOfHeapNodes
    def countersRep(self):
        """* Return a counters array, where the value of the i-th index is the number of trees with rank i
     * in the heap. returns an empty array for an empty heap"""
        # Unhandled node type: ArrayType
        if this.empty():
            return new int[0]
        rankArray = new int[(int) Math.floor(Math.log(len(self)) / Math.log(GOLDEN_RATIO)) + 1]
        rankArray[self.min.rank]++
        curr = self.min.next
        while curr != self.min:
            rankArray[curr.rank]++
            curr = curr.next
        return rankArray
    def delete(self, x):
        """* Deletes the node x from the heap (using decreaseKey(x) to -1)
     *
     * @pre heap contains x
     * @post (numOfnodes = = $prev numOfnodes - 1)"""
        self.decreaseKey(x, x.getKey() + 1)
        this.deleteMin()
    def decreaseKey(self, x, delta):
        """* The function decreases the key of the node x by delta.
     *
     * @pre x.key >= delta (we don't realize it when calling from delete())
     * @pre heap contains x"""
        newKey = x.getKey() - delta
        x.key = newKey
        if x.isRoot():
            self.updateMin(x)
            return
        if x.getKey():
            return
        prevParent = x.parent
        self.cut(x)
        self.cascadingCuts(prevParent)
    def potential(self):
        """* returns the current potential of the heap, which is:
     * Potential = #trees + 2*#markedNodes"""
        return numOfTrees + (2 * markedHeapNodesCounter)
    @staticmethod
    def totalLinks():
        """* This static function returns the total number of link operations made during the run-time of
     * the program. A link operation is the operation which gets as input two trees of the same
     * rank, and generates a tree of rank bigger by one."""
        return totalLinks
    @staticmethod
    def totalCuts():
        """* This static function returns the total number of cut operations made during the run-time of
     * the program. A cut operation is the operation which disconnects a subtree from its parent
     * (during decreaseKey/delete methods)."""
        return totalCuts
    def updateMin(self, posMin):
        #
        #      * updates the min of the heap (if needed)
        #      * @pre this.min == @param (posMin) if and only if (posMin.key < this.min.key)
        #
        if posMin.getKey():
            self.min = posMin
    def cascadingCuts(self, curr):
        #
        #      * Recursively "runs" all the way up from @param (curr) and mark the nodes.
        #      * stop the recursion if we had arrived to a marked node or to a root.
        #      * if we arrived to a marked node, we cut it and continue recursively.
        #      * called after a node was cut.
        #      * @post (numOfnodes == $prev numOfnodes)
        #
        if not curr.isMarked():
            curr.mark()
            if not curr.isRoot():
                self.markedHeapNodesCounter += 1
        else:
            if curr.isRoot():
                return
            prevParent = curr.parent
            self.cut(curr)
            self.cascadingCuts(prevParent)
    def cut(self, curr):
        #
        #      * cut a node (and his "subtree") from his origin tree and connect it to the heap as a new tree.
        #      * called after a node was cut.
        #      * @post (numOfnodes == $prev numOfnodes)
        #
        curr.parent.rank -= 1
        if # expr: curr.marked:
            self.markedHeapNodesCounter -= 1
            curr.marked = False
        if curr.parent.child == curr:
            if curr.next == curr:
                curr.parent.child = None
            else:
                curr.parent.child = curr.next
        curr.prev.next = curr.next
        curr.next.prev = curr.prev
        curr.next = curr
        curr.prev = curr
        curr.parent = None
        self.min.setNext(curr)
        self.updateMin(curr)
        self.numOfTrees += 1
        totalCuts += 1
    def successiveLink(self, curr):
        #
        #      *
        #
        buckets = self.toBuckets(curr)
        self.min = self.fromBuckets(buckets)
    def toBuckets(self, curr):
        #
        #      *
        #
        # Unhandled node type: ArrayType
        buckets = new HeapNode[(int) Math.floor(Math.log(len(self)) / Math.log(GOLDEN_RATIO)) + 1]
        curr.prev.next = None
        # expr: HeapNode tmpCurr
        while curr != None:
            tmpCurr = curr
            curr = curr.next
            tmpCurr.next = tmpCurr
            tmpCurr.prev = tmpCurr
            while buckets[tmpCurr.rank] != None:
                tmpCurr = self.link(tmpCurr, buckets[tmpCurr.rank])
                buckets[tmpCurr.rank - 1] = None
            buckets[tmpCurr.rank] = tmpCurr
        return buckets
    def fromBuckets(self, buckets):
        #
        #      *
        #
        tmpMin = None
        self.numOfTrees = 0
        for i in range(buckets.length):
            if buckets[i] != None:
                self.numOfTrees += 1
                if tmpMin == None:
                    tmpMin = buckets[i]
                    tmpMin.next = tmpMin
                    tmpMin.prev = tmpMin
                else:
                    tmpMin.setNext(buckets[i])
                    if buckets[i].getKey() < tmpMin.getKey():
                        tmpMin = buckets[i]
        return tmpMin
    def link(self, c1, c2):
        #
        #      * link between two nodes (and their trees)
        #      * defines the smaller node to be the parent
        #
        if c1.getKey():
            c3 = c1
            c1 = c2
            c2 = c3
        if c1.child == None:
            c1.child = c2
        else:
            c1.child.setNext(c2)
        c2.parent = c1
        c1.rank += 1
        totalLinks += 1
        return c1

    class HeapNode:
        """* public class HeapNode
     * each HeapNode belongs to a heap (Inner class)"""
        def __init__(self, key):
            #
            #          * a constructor for a heapNode with key @param (key)
            #          * prev == next == this
            #          * parent == child == null
            #
            self.key = key
            self.marked = False
            self.next = this
            self.prev = this
        def getKey(self):
            #
            #          * returns the key of the node.
            #
            return # expr: self.key
        def isMarked(self):
            #
            #          * checks whether the node is marked
            #          * $ret = true if one child has been cut
            #
            return # expr: self.marked
        def mark(self):
            #
            #          * mark a node (after a child was cut)
            #          * @inv root.mark() == false.
            #
            if this.isRoot():
                return
            self.marked = True
        def setNext(self, newNext):
            #
            #          * add the node @param (newNext) to be between this and this.next
            #          * works fine also if @param (newNext) does not "stands" alone
            #
            tmpNext = self.next
            self.next = newNext
            self.next.prev.next = tmpNext
            tmpNext.prev = newNext.prev
            self.next.prev = this
        def getNext(self):
            #
            #          * returns the next node to this node
            #
            return # expr: self.next
        def isRoot(self):
            #
            #          * check if the node is a root
            #          * root definition - this.parent == null (uppest in his tree)
            #
            return (self.parent == None)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.990
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 126:26 invalid syntax
#    >             return new int[0]
# 语法问题: [class FibonacciHeap] 行 126 invalid syntax
#    >             return new int[0]
# 未处理节点类型(Top):
#  - ExpressionStmt: 1
# 未映射方法(Top):
#  - HeapNode.setNext: 5
# --- 报告结束 ---
