# --- File: SingleElement.java ---

# package: com.thealgorithms.bitmanipulation

class SingleElement:
    """* Utility class to find the single non-duplicate element from an array
 * where all other elements appear twice.
 * <p>
 * The algorithm runs in O(n) time complexity and O(1) space complexity
 * using bitwise XOR.
 * </p>
 *
 * @author <a href="http://github.com/tuhinm2002">Tuhin M</a>"""
    def __init__(self):
        """* Private constructor to prevent instantiation of this utility class.
     * Throws an UnsupportedOperationException if attempted."""
        raise UnsupportedOperationException("Utility Class")
    @staticmethod
    def findSingleElement(arr):
        """* Finds the single non-duplicate element in an array where every other
     * element appears exactly twice. Uses bitwise XOR to achieve O(n) time
     * complexity and O(1) space complexity.
     *
     * @param arr the input array containing integers where every element
     *            except one appears exactly twice
     * @return the single non-duplicate element"""
        ele = 0
        for i in range(arr.length):
            ele ^ = arr[i]
        return ele

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.917
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 29:19 invalid syntax
#    >             ele ^ = arr[i]
# 语法问题: [class SingleElement] 行 29 invalid syntax
#    >             ele ^ = arr[i]
# --- 报告结束 ---
