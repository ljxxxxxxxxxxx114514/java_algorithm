# --- File: Cycles.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

# import: java.util.Scanner

class Cycle:
    def __init__(self):
        in = Scanner(System.in)
        print("Enter the no. of nodes: ", end="")
        nodes = in.nextInt()
        print("Enter the no. of Edges: ", end="")
        final int edges = in.nextInt()
        adjacencyMatrix =  new int[nodes][nodes]
        visited =  new boolean[nodes]
        for i in range(self.nodes):
            visited[i] = false
        print("Enter the details of each edges <Start Node> <End Node>")
        for i in range(edges):
            # expr: int start
            # expr: int end
            start = in.nextInt()
            end = in.nextInt()
            adjacencyMatrix[start][end] = 1
        in.close()
    def start(self):
        for i in range(self.nodes):
            temp = []
            dfs(i, i, temp)
            for j in range(self.nodes):
                adjacencyMatrix[i][j] = 0
                adjacencyMatrix[j][i] = 0
    def dfs(self, start, curr, temp):
        temp.append(curr)
        visited[curr] = true
        for i in range(self.nodes):
            if adjacencyMatrix[curr][i] == 1:
                if i == start:
                    cycles.append(new ArrayList<Integer>(temp))
                else:
                    if !visited[i]:
                        dfs(start, i, temp)
        if temp.size() > 0:
            temp.remove(temp.size() - 1)
        visited[curr] = false
    def printAll(self):
        for i in range(cycles.size()):
            for j in range(cycles.get(i).size()):
                print(f"{str(cycles.get(i).get(j))} -> ", end="")
            print(cycles.get(i).get(0))
            print()

class Cycles:
    def __init__(self):
        pass

def main(args=None):
    if args is None:
        args = []
    c = Cycle()
    c.start()
    c.printAll()

if __name__ == "__main__":
    main()
