# --- File: ProcessDetails.java ---

# package: com.thealgorithms.devutils.entities

class ProcessDetails:
    def __init__(self, processId=None, arrivalTime=None, burstTime=None, priority=None):
        if processId is not None and arrivalTime is not None and burstTime is not None and priority is not None:
            self.processId = processId
            self.arrivalTime = arrivalTime
            self.burstTime = burstTime
            self.priority = priority
        elif processId is not None and arrivalTime is not None and burstTime is not None:
            self.processId = processId
            self.arrivalTime = arrivalTime
            self.burstTime = burstTime
    def getProcessId(self):
        return self.processId
    def getArrivalTime(self):
        return self.arrivalTime
    def getBurstTime(self):
        return self.burstTime
    def getWaitingTime(self):
        return self.waitingTime
    def getTurnAroundTimeTime(self):
        return self.turnAroundTime
    def getPriority(self):
        return self.priority
    def setProcessId(self, processId):
        self.processId = processId
    def setArrivalTime(self, arrivalTime):
        self.arrivalTime = arrivalTime
    def setBurstTime(self, burstTime):
        self.burstTime = burstTime
    def setWaitingTime(self, waitingTime):
        self.waitingTime = waitingTime
    def setTurnAroundTimeTime(self, turnAroundTime):
        self.turnAroundTime = turnAroundTime

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.977
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
