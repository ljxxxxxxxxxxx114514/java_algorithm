# --- File: SameTreesCheck.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayDeque

# import: java.util.Deque

class SameTreesCheck:
    """* Given 2 binary trees.
 * This code checks whether they are the same (structurally identical and have the same values) or
 * not. <p> Example:
 * 1. Binary trees:
 *      1                 1
 *     / \               / \
 *    2   3             2   3
 *   /\   /\           /\   /\
 *  4  5 6  7         4  5 6  7
 * These trees are the same, so the code returns 'true'.
 * <p>
 * 2. Binary trees:
 *      1   1
 *     /     \
 *    2       2
 * These trees are NOT the same (the structure differs), so the code returns 'false'.
 * <p>
 * This solution implements the breadth-first search (BFS) algorithm.
 * For each tree we create a queue and iterate the trees using these queues.
 * On each step we check the nodes for equality, and if the nodes are not the same, return false.
 * Otherwise, add children nodes to the queues and continue traversing the trees.
 * <p>
 * Complexities:
 * O(N) - time, where N is the number of nodes in a binary tree,
 * O(N) - space, where N is the number of nodes in a binary tree.
 *
 * @author Albina Gimaletdinova on 13/01/2023"""
    def __init__(self):
        pass
    @staticmethod
    def check(p, q):
        if p == None and q == None:
            return True
        if p == None or q == None:
            return False
        q1 = ArrayDeque()
        q2 = ArrayDeque()
        q1.append(p)
        q2.append(q)
        while not (not q1) and not (not q2):
            first = q1.poll()
            second = q2.poll()
            if not equalNodes(first, second):
                return False
            if first != None:
                if not equalNodes(first.left, second.left):
                    return False
                if first.left != None:
                    q1.append(first.left)
                    q2.append(second.left)
                if not equalNodes(first.right, second.right):
                    return False
                if first.right != None:
                    q1.append(first.right)
                    q2.append(second.right)
        return True
    @staticmethod
    def equalNodes(p, q):
        if p == None and q == None:
            return True
        if p == None or q == None:
            return False
        return p.data == q.data

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.912
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
