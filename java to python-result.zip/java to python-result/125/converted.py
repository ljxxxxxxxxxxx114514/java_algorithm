# --- File: PreOrderTraversal.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.Deque

# import: java.util.LinkedList

# import: java.util.List

class PreOrderTraversal:
    """* Given tree is traversed in a 'pre-order' way: ROOT -> LEFT -> RIGHT.
 * Below are given the recursive and iterative implementations.
 *
 * Complexities:
 * Recursive: O(n) - time, O(n) - space, where 'n' is the number of nodes in a tree.
 *
 * Iterative: O(n) - time, O(h) - space, where 'n' is the number of nodes in a tree
 * and 'h' is the height of a binary tree.
 * In the worst case 'h' can be O(n) if tree is completely unbalanced, for instance:
 * 5
 *  \
 *   6
 *    \
 *     7
 *      \
 *       8
 *
 * @author Albina Gimaletdinova on 17/02/2023"""
    def __init__(self):
        pass
    @staticmethod
    def recursivePreOrder(root):
        result = list()
        recursivePreOrder(root, result)
        return result
    @staticmethod
    def iterativePreOrder(root):
        result = list()
        if root == None:
            return result
        stack = LinkedList()
        stack.push(root)
        while not (not stack):
            node = stack.pop()
            result.append(node.data)
            if node.right != None:
                stack.push(node.right)
            if node.left != None:
                stack.push(node.left)
        return result
    @staticmethod
    def recursivePreOrder(root, result):
        if root == None:
            return
        result.append(root.data)
        recursivePreOrder(root.left, result)
        recursivePreOrder(root.right, result)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.847
# 可解析度: 1.000 (2/2)
# 未映射方法(Top):
#  - Deque.push: 3
# --- 报告结束 ---
