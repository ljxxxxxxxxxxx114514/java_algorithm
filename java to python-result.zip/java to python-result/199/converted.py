# --- File: SearchAlgorithm.java ---

# package: com.thealgorithms.devutils.searches

import abc

class SearchAlgorithm(abc.ABC):
    """* The common interface of most searching algorithms
 *
 * @author Podshivalov Nikita (https://github.com/nikitap492)"""
    @abc.abstractmethod
    def find(self, array, key):
        raise NotImplementedError

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.625
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
