# --- File: Intersection.java ---

# package: com.thealgorithms.datastructures.hashmap.hashing

# import: java.util.ArrayList

# import: java.util.Collections

# import: java.util.HashMap

# import: java.util.List

# import: java.util.Map

class Intersection:
    """* The {@code Intersection} class provides a method to compute the intersection of two integer arrays.
 * <p>
 * This intersection includes duplicate values — meaning elements are included in the result
 * as many times as they appear in both arrays (i.e., multiset intersection).
 * </p>
 *
 * <p>
 * The algorithm uses a {@link java.util.HashMap} to count occurrences of elements in the first array,
 * then iterates through the second array to collect common elements based on these counts.
 * </p>
 *
 * <p>
 * Example usage:
 * <pre>{@code
 * int[] array1 = {1, 2, 2, 1};
 * int[] array2 = {2, 2};
 * List<Integer> result = Intersection.intersection(array1, array2); // result: [2, 2]
 * }</pre>
 * </p>
 *
 * <p>
 * Note: The order of elements in the returned list depends on the order in the second input array.
 * </p>"""
    def __init__(self):
        pass
    @staticmethod
    def intersection(arr1, arr2):
        """* Computes the intersection of two integer arrays, preserving element frequency.
     * For example, given [1,2,2,3] and [2,2,4], the result will be [2,2].
     *
     * Steps:
     * 1. Count the occurrences of each element in the first array using a map.
     * 2. Iterate over the second array and collect common elements.
     *
     * @param arr1 the first array of integers
     * @param arr2 the second array of integers
     * @return a list containing the intersection of the two arrays (with duplicates),
     *         or an empty list if either array is null or empty"""
        # 
     * Computes the intersection of two integer arrays, preserving element frequency.
     * For example, given [1,2,2,3] and [2,2,4], the result will be [2,2].
     *
     * Steps:
     * 1. Count the occurrences of each element in the first array using a map.
     * 2. Iterate over the second array and collect common elements.
     *
     * @param arr1 the first array of integers
     * @param arr2 the second array of integers
     * @return a list containing the intersection of the two arrays (with duplicates),
     *         or an empty list if either array is null or empty
     
        if arr1 == null || arr2 == null || arr1.length == 0 || arr2.length == 0:
            return Collections.emptyList()
        Map<Integer, Integer> countMap = HashMap()
        for num in arr1:
            countMap.put(num, countMap.getOrDefault(num, 0) + 1)
        result = []
        for num in arr2:
            if countMap.getOrDefault(num, 0) > 0:
                result.append(num)
                countMap.computeIfPresent(num, (k, v) -> v - 1)
        return result

if __name__ == "__main__":
    pass
