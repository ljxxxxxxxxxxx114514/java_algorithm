# --- File: ParenthesesGenerator.java ---

# package: com.thealgorithms.backtracking

# import: java.util.ArrayList

# import: java.util.List

class ParenthesesGenerator:
    """* This class generates all valid combinations of parentheses for a given number of pairs using backtracking."""
    def __init__(self):
        pass
    @staticmethod
    def generateParentheses(n):
        """* Generates all valid combinations of parentheses for a given number of pairs.
     *
     * @param n The number of pairs of parentheses.
     * @return A list of strings representing valid combinations of parentheses.
     * @throws IllegalArgumentException if n is less than 0."""
        if n < 0:
            raise ValueError("The number of pairs of parentheses cannot be negative")
        result = list()
        generateParenthesesHelper(result, "", 0, 0, n)
        return result
    @staticmethod
    def generateParenthesesHelper(result, current, open, close, n):
        """* Helper function for generating all valid combinations of parentheses recursively.
     *
     * @param result  The list to store valid combinations.
     * @param current The current combination being formed.
     * @param open    The number of open parentheses.
     * @param close   The number of closed parentheses.
     * @param n       The total number of pairs of parentheses."""
        if current.length():
            result.append(current)
            return
        if open < n:
            generateParenthesesHelper(result, current + "(", open + 1, close, n)
        if close < open:
            generateParenthesesHelper(result, current + ")", open, close + 1, n)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.829
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
