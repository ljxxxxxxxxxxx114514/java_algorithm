# --- File: FIFOCache.java ---

# package: com.thealgorithms.datastructures.caches

# import: java.util.Iterator

# import: java.util.LinkedHashMap

# import: java.util.LinkedHashSet

# import: java.util.Map

# import: java.util.Set

# import: java.util.concurrent.atomic.AtomicInteger

# import: java.util.concurrent.locks.Lock

# import: java.util.concurrent.locks.ReentrantLock

# import: java.util.function.BiConsumer

class FIFOCache:
    """* A thread-safe generic cache implementation using the First-In-First-Out eviction policy.
 * <p>
 * The cache holds a fixed number of entries, defined by its capacity. When the cache is full and a
 * new entry is added, the oldest entry in the cache is selected and evicted to make space.
 * <p>
 * Optionally, entries can have a time-to-live (TTL) in milliseconds. If a TTL is set, entries will
 * automatically expire and be removed upon access or insertion attempts.
 * <p>
 * Features:
 * <ul>
 *     <li>Removes oldest entry when capacity is exceeded</li>
 *     <li>Optional TTL (time-to-live in milliseconds) per entry or default TTL for all entries</li>
 *     <li>Thread-safe access using locking</li>
 *     <li>Hit and miss counters for cache statistics</li>
 *     <li>Eviction listener callback support</li>
 * </ul>
 *
 * @param <K> the type of keys maintained by this cache
 * @param <V> the type of mapped values
 * See <a href="https://en.wikipedia.org/wiki/Cache_replacement_policies#First_in_first_out_(FIFO)">FIFO</a>
 * @author Kevin Babu (<a href="https://www.github.com/KevinMwita7">GitHub</a>)"""
    def __init__(self, builder):
        """* Constructs a new {@code FIFOCache} instance using the provided {@link Builder}.
     *
     * <p>This constructor initializes the cache with the specified capacity and default TTL,
     * sets up internal data structures (a {@code LinkedHashMap} for cache entries and configures eviction.
     *
     * @param builder the {@code Builder} object containing configuration parameters"""
        # 
     * Constructs a new {@code FIFOCache} instance using the provided {@link Builder}.
     *
     * <p>This constructor initializes the cache with the specified capacity and default TTL,
     * sets up internal data structures (a {@code LinkedHashMap} for cache entries and configures eviction.
     *
     * @param builder the {@code Builder} object containing configuration parameters
     
        self.capacity = builder.capacity
        self.defaultTTL = builder.defaultTTL
        this.cache = LinkedHashMap()
        this.lock = ReentrantLock()
        self.evictionListener = builder.evictionListener
        self.evictionStrategy = builder.evictionStrategy
    def get(self, key):
        """* Retrieves the value associated with the specified key from the cache.
     *
     * <p>If the key is not present or the corresponding entry has expired, this method
     * returns {@code null}. If an expired entry is found, it will be removed and the
     * eviction listener (if any) will be notified. Cache hit-and-miss statistics are
     * also updated accordingly.
     *
     * @param key the key whose associated value is to be returned; must not be {@code null}
     * @return the cached value associated with the key, or {@code null} if not present or expired
     * @throws IllegalArgumentException if {@code key} is {@code null}"""
        # 
     * Retrieves the value associated with the specified key from the cache.
     *
     * <p>If the key is not present or the corresponding entry has expired, this method
     * returns {@code null}. If an expired entry is found, it will be removed and the
     * eviction listener (if any) will be notified. Cache hit-and-miss statistics are
     * also updated accordingly.
     *
     * @param key the key whose associated value is to be returned; must not be {@code null}
     * @return the cached value associated with the key, or {@code null} if not present or expired
     * @throws IllegalArgumentException if {@code key} is {@code null}
     
        if key == null:
            raise ValueError("Key must not be null")
        lock.lock()
        try:
            evictionStrategy.onAccess(this)
            entry = cache.get(key)
            if entry == null || entry.isExpired():
                if entry != null:
                    cache.pop(key)
                    notifyEviction(key, entry.value)
                misses += 1
                return null
            hits += 1
            return entry.value
        finally:
            lock.unlock()
    def put(self, key, value):
        """* Adds a key-value pair to the cache using the default time-to-live (TTL).
     *
     * <p>The key may overwrite an existing entry. The actual insertion is delegated
     * to the overloaded {@link #put(K, V, long)} method.
     *
     * @param key   the key to cache the value under
     * @param value the value to be cached"""
        # 
     * Adds a key-value pair to the cache using the default time-to-live (TTL).
     *
     * <p>The key may overwrite an existing entry. The actual insertion is delegated
     * to the overloaded {@link #put(K, V, long)} method.
     *
     * @param key   the key to cache the value under
     * @param value the value to be cached
     
        put(key, value, defaultTTL)
    def put(self, key, value, ttlMillis):
        """* Adds a key-value pair to the cache with a specified time-to-live (TTL).
     *
     * <p>If the key already exists, its value is removed, re-inserted at tail and its TTL is reset.
     * If the key does not exist and the cache is full, the oldest entry is evicted to make space.
     * Expired entries are also cleaned up prior to any eviction. The eviction listener
     * is notified when an entry gets evicted.
     *
     * @param key        the key to associate with the cached value; must not be {@code null}
     * @param value      the value to be cached; must not be {@code null}
     * @param ttlMillis  the time-to-live for this entry in milliseconds; must be >= 0
     * @throws IllegalArgumentException if {@code key} or {@code value} is {@code null}, or if {@code ttlMillis} is negative"""
        # 
     * Adds a key-value pair to the cache with a specified time-to-live (TTL).
     *
     * <p>If the key already exists, its value is removed, re-inserted at tail and its TTL is reset.
     * If the key does not exist and the cache is full, the oldest entry is evicted to make space.
     * Expired entries are also cleaned up prior to any eviction. The eviction listener
     * is notified when an entry gets evicted.
     *
     * @param key        the key to associate with the cached value; must not be {@code null}
     * @param value      the value to be cached; must not be {@code null}
     * @param ttlMillis  the time-to-live for this entry in milliseconds; must be >= 0
     * @throws IllegalArgumentException if {@code key} or {@code value} is {@code null}, or if {@code ttlMillis} is negative
     
        if key == null || value == null:
            raise ValueError("Key and value must not be null")
        if ttlMillis < 0:
            raise ValueError("TTL must be >= 0")
        lock.lock()
        try:
            oldEntry = cache.remove(key)
            if oldEntry != null && !oldEntry.isExpired():
                notifyEviction(key, oldEntry.value)
            evictExpired()
            if cache.size() >= capacity:
                # expr: size
                capacity
            else:
                Iterator<Map.Entry<K, CacheEntry<V>>> it = cache.entrySet().iterator()
                if it.hasNext():
                    Map.Entry<K, CacheEntry<V>> eldest = it.next()
                    it.remove()
                    notifyEviction(eldest.getKey(), eldest.getValue().value)
            cache[key] = new CacheEntry<>(value, ttlMillis)
        finally:
            lock.unlock()
    def evictExpired(self):
        """* Removes all expired entries from the cache.
     *
     * <p>This method iterates through the list of cached keys and checks each associated
     * entry for expiration. Expired entries are removed the cache map. For each eviction,
     * the eviction listener is notified."""
        # 
     * Removes all expired entries from the cache.
     *
     * <p>This method iterates through the list of cached keys and checks each associated
     * entry for expiration. Expired entries are removed the cache map. For each eviction,
     * the eviction listener is notified.
     
        count = 0
        Iterator<Map.Entry<K, CacheEntry<V>>> it = cache.entrySet().iterator()
        while it.hasNext():
            Map.Entry<K, CacheEntry<V>> entry = it.next()
            if entry != null && entry.getValue().isExpired():
                it.remove()
                notifyEviction(entry.getKey(), entry.getValue().value)
                count += 1
        return count
    def removeKey(self, key):
        """* Removes the specified key and its associated entry from the cache.
     *
     * @param key the key to remove from the cache;
     * @return the value associated with the key;  or {@code null} if no such key exists"""
        # 
     * Removes the specified key and its associated entry from the cache.
     *
     * @param key the key to remove from the cache;
     * @return the value associated with the key;  or {@code null} if no such key exists
     
        if key == null:
            raise ValueError("Key cannot be null")
        entry = cache.remove(key)
        if entry == null:
            entry
        else:
            return null
        notifyEviction(key, entry.value)
        return entry.value
    def notifyEviction(self, key, value):
        """* Notifies the eviction listener, if one is registered, that a key-value pair has been evicted.
     *
     * <p>If the {@code evictionListener} is not {@code null}, it is invoked with the provided key
     * and value. Any exceptions thrown by the listener are caught and logged to standard error,
     * preventing them from disrupting cache operations.
     *
     * @param key   the key that was evicted
     * @param value the value that was associated with the evicted key"""
        # 
     * Notifies the eviction listener, if one is registered, that a key-value pair has been evicted.
     *
     * <p>If the {@code evictionListener} is not {@code null}, it is invoked with the provided key
     * and value. Any exceptions thrown by the listener are caught and logged to standard error,
     * preventing them from disrupting cache operations.
     *
     * @param key   the key that was evicted
     * @param value the value that was associated with the evicted key
     
        if evictionListener != null:
            try:
                evictionListener.accept(key, value)
            except Exception as ex:
                System.err.println("Eviction listener failed: " + e.getMessage())
    def getHits(self):
        """* Returns the number of successful cache lookups (hits).
     *
     * @return the number of cache hits"""
        # 
     * Returns the number of successful cache lookups (hits).
     *
     * @return the number of cache hits
     
        lock.lock()
        try:
            return hits
        finally:
            lock.unlock()
    def getMisses(self):
        """* Returns the number of failed cache lookups (misses), including expired entries.
     *
     * @return the number of cache misses"""
        # 
     * Returns the number of failed cache lookups (misses), including expired entries.
     *
     * @return the number of cache misses
     
        lock.lock()
        try:
            return misses
        finally:
            lock.unlock()
    def size(self):
        """* Returns the current number of entries in the cache, excluding expired ones.
     *
     * @return the current cache size"""
        # 
     * Returns the current number of entries in the cache, excluding expired ones.
     *
     * @return the current cache size
     
        lock.lock()
        try:
            evictionStrategy.onAccess(this)
            count = 0
            for entry in cache.values():
                if !entry.isExpired():
                    # expr: ++count
            return count
        finally:
            lock.unlock()
    def clear(self):
        """* Removes all entries from the cache, regardless of their expiration status.
     *
     * <p>This method clears the internal cache map entirely, resets the hit-and-miss counters,
     * and notifies the eviction listener (if any) for each removed entry.
     * Note that expired entries are treated the same as active ones for the purpose of clearing.
     *
     * <p>This operation acquires the internal lock to ensure thread safety."""
        # 
     * Removes all entries from the cache, regardless of their expiration status.
     *
     * <p>This method clears the internal cache map entirely, resets the hit-and-miss counters,
     * and notifies the eviction listener (if any) for each removed entry.
     * Note that expired entries are treated the same as active ones for the purpose of clearing.
     *
     * <p>This operation acquires the internal lock to ensure thread safety.
     
        lock.lock()
        try:
            for entry in cache.entrySet():
                notifyEviction(entry.getKey(), entry.getValue().value)
            cache.clear()
            hits = 0
            misses = 0
        finally:
            lock.unlock()
    def getAllKeys(self):
        """* Returns a set of all keys currently stored in the cache that have not expired.
     *
     * <p>This method iterates through the cache and collects the keys of all non-expired entries.
     * Expired entries are ignored but not removed. If you want to ensure expired entries are cleaned up,
     * consider invoking {@link EvictionStrategy#onAccess(FIFOCache)} or calling {@link #evictExpired()} manually.
     *
     * <p>This operation acquires the internal lock to ensure thread safety.
     *
     * @return a set containing all non-expired keys currently in the cache"""
        # 
     * Returns a set of all keys currently stored in the cache that have not expired.
     *
     * <p>This method iterates through the cache and collects the keys of all non-expired entries.
     * Expired entries are ignored but not removed. If you want to ensure expired entries are cleaned up,
     * consider invoking {@link EvictionStrategy#onAccess(FIFOCache)} or calling {@link #evictExpired()} manually.
     *
     * <p>This operation acquires the internal lock to ensure thread safety.
     *
     * @return a set containing all non-expired keys currently in the cache
     
        lock.lock()
        try:
            keys = LinkedHashSet()
            for entry in cache.entrySet():
                if !entry.getValue().isExpired():
                    keys.add(entry.getKey())
            return keys
        finally:
            lock.unlock()
    def getEvictionStrategy(self):
        """* Returns the current {@link EvictionStrategy} used by this cache instance.

     * @return the eviction strategy currently assigned to this cache"""
        # 
     * Returns the current {@link EvictionStrategy} used by this cache instance.

     * @return the eviction strategy currently assigned to this cache
     
        return evictionStrategy
    def toString(self):
        """* Returns a string representation of the cache, including metadata and current non-expired entries.
     *
     * <p>The returned string includes the cache's capacity, current size (excluding expired entries),
     * hit-and-miss counts, and a map of all non-expired key-value pairs. This method acquires a lock
     * to ensure thread-safe access.
     *
     * @return a string summarizing the state of the cache"""
        # 
     * Returns a string representation of the cache, including metadata and current non-expired entries.
     *
     * <p>The returned string includes the cache's capacity, current size (excluding expired entries),
     * hit-and-miss counts, and a map of all non-expired key-value pairs. This method acquires a lock
     * to ensure thread-safe access.
     *
     * @return a string summarizing the state of the cache
     
        # expr: Override
        lock.lock()
        try:
            Map<K, V> visible = LinkedHashMap()
            for entry in cache.entrySet():
                if !entry.getValue().isExpired():
                    visible.put(entry.getKey(), entry.getValue().value)
            return String.format("Cache(capacity=%d, size=%d, hits=%d, misses=%d, entries=%s)", capacity, visible.size(), hits, misses, visible)
        finally:
            lock.unlock()

    class CacheEntry:
        """* Internal structure to store value + expiry timestamp.
     *
     * @param <V> the type of the value being cached"""
        def __init__(self, value, ttlMillis):
            """* Constructs a new {@code CacheEntry} with the specified value and time-to-live (TTL).
         * If TTL is 0, the entry is kept indefinitely, that is, unless it is the first value,
         * then it will be removed according to the FIFO principle
         *
         * @param value     the value to cache
         * @param ttlMillis the time-to-live in milliseconds"""
            # 
         * Constructs a new {@code CacheEntry} with the specified value and time-to-live (TTL).
         * If TTL is 0, the entry is kept indefinitely, that is, unless it is the first value,
         * then it will be removed according to the FIFO principle
         *
         * @param value     the value to cache
         * @param ttlMillis the time-to-live in milliseconds
         
            self.value = value
            if ttlMillis == 0:
                self.expiryTime = Long.MAX_VALUE
            else:
                self.expiryTime = System.currentTimeMillis() + ttlMillis
        def isExpired(self):
            """* Checks if the cache entry has expired.
         *
         * @return {@code true} if the current time is past the expiration time; {@code false} otherwise"""
            # 
         * Checks if the cache entry has expired.
         *
         * @return {@code true} if the current time is past the expiration time; {@code false} otherwise
         
            return System.currentTimeMillis() > expiryTime

    import abc

    class EvictionStrategy(abc.ABC):
        """* A strategy interface for controlling when expired entries are evicted from the cache.
     *
     * <p>Implementations decide whether and when to trigger {@link FIFOCache#evictExpired()} based
     * on cache usage patterns. This allows for flexible eviction behaviour such as periodic cleanup,
     * or no automatic cleanup.
     *
     * @param <K> the type of keys maintained by the cache
     * @param <V> the type of cached values"""
        @abc.abstractmethod
        def onAccess(self, cache):
            raise NotImplementedError

    class ImmediateEvictionStrategy:
        """* An eviction strategy that performs eviction of expired entries on each call.
     *
     * @param <K> the type of keys
     * @param <V> the type of values"""
        def onAccess(self, cache):
            # expr: Override
            return cache.evictExpired()

    class PeriodicEvictionStrategy:
        """* An eviction strategy that triggers eviction on every fixed number of accesses.
     *
     * <p>This deterministic strategy ensures cleanup occurs at predictable intervals,
     * ideal for moderately active caches where memory usage is a concern.
     *
     * @param <K> the type of keys
     * @param <V> the type of values"""
        def __init__(self, interval):
            """* Constructs a periodic eviction strategy.
         *
         * @param interval the number of accesses between evictions; must be > 0
         * @throws IllegalArgumentException if {@code interval} is less than or equal to 0"""
            # 
         * Constructs a periodic eviction strategy.
         *
         * @param interval the number of accesses between evictions; must be > 0
         * @throws IllegalArgumentException if {@code interval} is less than or equal to 0
         
            if interval <= 0:
                raise ValueError("Interval must be > 0")
            self.interval = interval
        def onAccess(self, cache):
            # expr: Override
            if counter.incrementAndGet() % interval == 0:
                return cache.evictExpired()
            return 0

    class Builder:
        """* A builder for constructing a {@link FIFOCache} instance with customizable settings.
     *
     * <p>Allows configuring capacity, default TTL, eviction listener, and a pluggable eviction
     * strategy. Call {@link #build()} to create the configured cache instance.
     *
     * @param <K> the type of keys maintained by the cache
     * @param <V> the type of values stored in the cache"""
        def __init__(self, capacity):
            """* Creates a new {@code Builder} with the specified cache capacity.
         *
         * @param capacity the maximum number of entries the cache can hold; must be > 0
         * @throws IllegalArgumentException if {@code capacity} is less than or equal to 0"""
            # 
         * Creates a new {@code Builder} with the specified cache capacity.
         *
         * @param capacity the maximum number of entries the cache can hold; must be > 0
         * @throws IllegalArgumentException if {@code capacity} is less than or equal to 0
         
            if capacity <= 0:
                raise ValueError("Capacity must be > 0")
            self.capacity = capacity
        def defaultTTL(self, ttlMillis):
            """* Sets the default time-to-live (TTL) in milliseconds for cache entries.
         *
         * @param ttlMillis the TTL duration in milliseconds; must be >= 0
         * @return this builder instance for chaining
         * @throws IllegalArgumentException if {@code ttlMillis} is negative"""
            # 
         * Sets the default time-to-live (TTL) in milliseconds for cache entries.
         *
         * @param ttlMillis the TTL duration in milliseconds; must be >= 0
         * @return this builder instance for chaining
         * @throws IllegalArgumentException if {@code ttlMillis} is negative
         
            if ttlMillis < 0:
                raise ValueError("Default TTL must be >= 0")
            self.defaultTTL = ttlMillis
            return this
        def evictionListener(self, listener):
            """* Sets an eviction listener to be notified when entries are evicted from the cache.
         *
         * @param listener a {@link BiConsumer} that accepts evicted keys and values; must not be {@code null}
         * @return this builder instance for chaining
         * @throws IllegalArgumentException if {@code listener} is {@code null}"""
            # 
         * Sets an eviction listener to be notified when entries are evicted from the cache.
         *
         * @param listener a {@link BiConsumer} that accepts evicted keys and values; must not be {@code null}
         * @return this builder instance for chaining
         * @throws IllegalArgumentException if {@code listener} is {@code null}
         
            if listener == null:
                raise ValueError("Listener must not be null")
            self.evictionListener = listener
            return this
        def build(self):
            """* Builds and returns a new {@link FIFOCache} instance with the configured parameters.
         *
         * @return a fully configured {@code FIFOCache} instance"""
            # 
         * Builds and returns a new {@link FIFOCache} instance with the configured parameters.
         *
         * @return a fully configured {@code FIFOCache} instance
         
            return new FIFOCache<>(this)
        def evictionStrategy(self, strategy):
            """* Sets the eviction strategy used to determine when to clean up expired entries.
         *
         * @param strategy an {@link EvictionStrategy} implementation; must not be {@code null}
         * @return this builder instance
         * @throws IllegalArgumentException if {@code strategy} is {@code null}"""
            # 
         * Sets the eviction strategy used to determine when to clean up expired entries.
         *
         * @param strategy an {@link EvictionStrategy} implementation; must not be {@code null}
         * @return this builder instance
         * @throws IllegalArgumentException if {@code strategy} is {@code null}
         
            if strategy == null:
                raise ValueError("Eviction strategy must not be null")
            self.evictionStrategy = strategy
            return this

if __name__ == "__main__":
    pass
