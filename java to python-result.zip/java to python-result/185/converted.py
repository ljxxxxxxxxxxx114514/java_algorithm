# --- File: OnesComplement.java ---

# package: com.thealgorithms.bitmanipulation

class OnesComplement:
    """* @author - https://github.com/Monk-AbhinayVerma
 * @Wikipedia - https://en.wikipedia.org/wiki/Ones%27_complement
 *            The class OnesComplement computes the complement of binary number
 *            and returns
 *            the complemented binary string.
 * @return the complimented binary string"""
    def __init__(self):
        pass
    @staticmethod
    def onesComplement(binary):
        """* Returns the 1's complement of a binary string.
     *
     * @param binary A string representing a binary number (e.g., "1010").
     * @return A string representing the 1's complement.
     * @throws IllegalArgumentException if the input is null or contains characters other than '0' or '1'."""
        if binary == None or (not binary):
            raise ValueError("Input must be a non-empty binary string.")
        complement = StringBuilder(binary.length())
        for bit in binary.toCharArray():
            # switch bit
                bit
                # Unhandled node type: SwitchEntry
        return complement.toString()

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.825
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
