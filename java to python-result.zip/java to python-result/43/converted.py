# --- File: GenericHashMapUsingArray.java ---

# package: com.thealgorithms.datastructures.hashmap.hashing

# import: java.util.LinkedList

class GenericHashMapUsingArray:
    """* A generic implementation of a hash map using an array of linked lists for collision resolution.
 * This class provides a way to store key-value pairs efficiently, allowing for average-case
 * constant time complexity for insertion, deletion, and retrieval operations.
 *
 * <p>
 * The hash map uses separate chaining for collision resolution. Each bucket in the hash map is a
 * linked list that stores nodes containing key-value pairs. When a collision occurs (i.e., when
 * two keys hash to the same index), the new key-value pair is simply added to the corresponding
 * linked list.
 * </p>
 *
 * <p>
 * The hash map automatically resizes itself when the load factor exceeds 0.75. The load factor is
 * defined as the ratio of the number of entries to the number of buckets. When resizing occurs,
 * all existing entries are rehashed and inserted into the new buckets.
 * </p>
 *
 * @param <K> the type of keys maintained by this hash map
 * @param <V> the type of mapped values"""
    def __init__(self):
        """* Constructs a new empty hash map with an initial capacity of 16."""
        # 
     * Constructs a new empty hash map with an initial capacity of 16.
     
        initBuckets(16)
        size = 0
    def initBuckets(self, n):
        """* Initializes the buckets for the hash map with the specified number of buckets.
     *
     * @param n the number of buckets to initialize"""
        # 
     * Initializes the buckets for the hash map with the specified number of buckets.
     *
     * @param n the number of buckets to initialize
     
        buckets =  new LinkedList[n]
        for i in range(buckets.length):
            buckets[i] = LinkedList()
    def put(self, key, value):
        """* Associates the specified value with the specified key in this map.
     * If the map previously contained a mapping for the key, the old value is replaced.
     *
     * @param key the key with which the specified value is to be associated
     * @param value the value to be associated with the specified key"""
        # 
     * Associates the specified value with the specified key in this map.
     * If the map previously contained a mapping for the key, the old value is replaced.
     *
     * @param key the key with which the specified value is to be associated
     * @param value the value to be associated with the specified key
     
        bucketIndex = hashFunction(key)
        nodes = buckets[bucketIndex]
        for node in nodes:
            if node.key.equals(key):
                node.value = value
                return
        nodes.append(new Node(key, value))
        size += 1
        loadFactorThreshold = 0.75f
        if (float) size / buckets.length > loadFactorThreshold:
            reHash()
    def hashFunction(self, key):
        """* Returns the index of the bucket in which the key would be stored.
     *
     * @param key the key whose bucket index is to be computed
     * @return the bucket index"""
        # 
     * Returns the index of the bucket in which the key would be stored.
     *
     * @param key the key whose bucket index is to be computed
     * @return the bucket index
     
        return Math.floorMod(key.hashCode(), buckets.length)
    def reHash(self):
        """* Rehashes the map by doubling the number of buckets and re-inserting all entries."""
        # 
     * Rehashes the map by doubling the number of buckets and re-inserting all entries.
     
        oldBuckets = self.buckets
        initBuckets(oldBuckets.length * 2)
        self.size = 0
        for nodes in oldBuckets:
            for node in nodes:
                put(node.key, node.value)
    def remove(self, key):
        """* Removes the mapping for the specified key from this map if present.
     *
     * @param key the key whose mapping is to be removed from the map"""
        # 
     * Removes the mapping for the specified key from this map if present.
     *
     * @param key the key whose mapping is to be removed from the map
     
        bucketIndex = hashFunction(key)
        nodes = buckets[bucketIndex]
        target = null
        for node in nodes:
            if node.key.equals(key):
                target = node
                break
        if target != null:
            nodes.remove(target)
            size -= 1
    def size(self):
        """* Returns the number of key-value pairs in this map.
     *
     * @return the number of key-value pairs"""
        # 
     * Returns the number of key-value pairs in this map.
     *
     * @return the number of key-value pairs
     
        return this.size
    def get(self, key):
        """* Returns the value to which the specified key is mapped, or null if this map contains no mapping for the key.
     *
     * @param key the key whose associated value is to be returned
     * @return the value associated with the specified key, or null if no mapping exists"""
        # 
     * Returns the value to which the specified key is mapped, or null if this map contains no mapping for the key.
     *
     * @param key the key whose associated value is to be returned
     * @return the value associated with the specified key, or null if no mapping exists
     
        bucketIndex = hashFunction(key)
        nodes = buckets[bucketIndex]
        for node in nodes:
            if node.key.equals(key):
                return node.value
        return null
    def toString(self):
        # expr: Override
        builder = StringBuilder()
        builder.append("{")
        for nodes in buckets:
            for node in nodes:
                builder.append(node.key)
                builder.append(" : ")
                builder.append(node.value)
                builder.append(", ")
        if builder.length() > 1:
            # expr: length
            ''
        else:
            builder.setLength(builder.length() - 2)
        builder.append("}")
        return builder.toString()
    def containsKey(self, key):
        """* Returns true if this map contains a mapping for the specified key.
     *
     * @param key the key whose presence in this map is to be tested
     * @return true if this map contains a mapping for the specified key"""
        # 
     * Returns true if this map contains a mapping for the specified key.
     *
     * @param key the key whose presence in this map is to be tested
     * @return true if this map contains a mapping for the specified key
     
        return get(key) != null

    class Node:
        """* A private class representing a key-value pair (node) in the hash map."""
        def __init__(self, key, value):
            """* Constructs a new Node with the specified key and value.
         *
         * @param key the key of the key-value pair
         * @param value the value of the key-value pair"""
            # 
         * Constructs a new Node with the specified key and value.
         *
         * @param key the key of the key-value pair
         * @param value the value of the key-value pair
         
            self.key = key
            self.value = value

if __name__ == "__main__":
    pass
