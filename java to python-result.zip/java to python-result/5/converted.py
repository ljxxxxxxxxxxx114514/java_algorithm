# --- File: ConnectedComponent.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

# import: java.util.HashSet

# import: java.util.Set

class Graph:
    """* A class that counts the number of different connected components in a graph
 *
 * @author Lukas Keul, Florian Mercks"""
    def __init__(self):
        edgeList = []
        nodeList = []
    def addEdge(self, startNode, endNode):
        """* Adds a new Edge to the graph. If the nodes aren't yet in nodeList, they
     * will be added to it.
     *
     * @param startNode the starting Node from the edge
     * @param endNode the ending Node from the edge"""
        # 
     * Adds a new Edge to the graph. If the nodes aren't yet in nodeList, they
     * will be added to it.
     *
     * @param startNode the starting Node from the edge
     * @param endNode the ending Node from the edge
     
        start = null
        end = null
        for node in nodeList:
            if startNode.compareTo(node.name) == 0:
                start = node
            else:
                end = node
        if start == null:
            start = Node(startNode)
            nodeList.append(start)
        if end == null:
            end = Node(endNode)
            nodeList.append(end)
        edgeList.append(new Edge(start, end))
    def countGraphs(self):
        """* Main method used for counting the connected components. Iterates through
     * the array of nodes to do a depth first search to get all nodes of the
     * graph from the actual node. These nodes are added to the array
     * markedNodes and will be ignored if they are chosen in the nodeList.
     *
     * @return returns the amount of unconnected graphs"""
        # 
     * Main method used for counting the connected components. Iterates through
     * the array of nodes to do a depth first search to get all nodes of the
     * graph from the actual node. These nodes are added to the array
     * markedNodes and will be ignored if they are chosen in the nodeList.
     *
     * @return returns the amount of unconnected graphs
     
        count = 0
        markedNodes = HashSet()
        for n in nodeList:
            if markedNodes.add(n):
                markedNodes.update(depthFirstSearch(n, new ArrayList<Node>()))
                count += 1
        return count
    def depthFirstSearch(self, n, visited):
        """* Implementation of depth first search.
     *
     * @param n the actual visiting node
     * @param visited A list of already visited nodes in the depth first search
     * @return returns a set of visited nodes"""
        # 
     * Implementation of depth first search.
     *
     * @param n the actual visiting node
     * @param visited A list of already visited nodes in the depth first search
     * @return returns a set of visited nodes
     
        visited.add(n)
        for e in edgeList:
            if e.startNode.equals(n) && !visited.contains(e.endNode):
                depthFirstSearch(e.endNode, visited)
        return visited

    class Node:
        def __init__(self, name):
            self.name = name

    class Edge:
        def __init__(self, startNode, endNode):
            self.startNode = startNode
            self.endNode = endNode

class ConnectedComponent:
    def __init__(self):
        pass

def main(args=None):
    if args is None:
        args = []
    graphChars = Graph()
    graphChars.addEdge('a', 'b')
    graphChars.addEdge('a', 'e')
    graphChars.addEdge('b', 'e')
    graphChars.addEdge('b', 'c')
    graphChars.addEdge('c', 'd')
    graphChars.addEdge('d', 'a')
    graphChars.addEdge('x', 'y')
    graphChars.addEdge('x', 'z')
    graphChars.addEdge('w', 'w')
    graphInts = Graph()
    graphInts.addEdge(1, 2)
    graphInts.addEdge(2, 3)
    graphInts.addEdge(2, 4)
    graphInts.addEdge(3, 5)
    graphInts.addEdge(7, 8)
    graphInts.addEdge(8, 10)
    graphInts.addEdge(10, 8)
    print(f"Amount of different char-graphs: {str(graphChars.countGraphs())}")
    print(f"Amount of different int-graphs: {str(graphInts.countGraphs())}")

if __name__ == "__main__":
    main()
