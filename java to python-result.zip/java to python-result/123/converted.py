# --- File: nearestRightKey.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.Scanner

# import: java.util.concurrent.ThreadLocalRandom

class NearestRightKey:
    def __init__(self):
        pass
class NRKTree:
    def __init__(self, x=None, right=None, left=None):
        if x is not None:
            self.left = None
            self.right = None
            self.data = x
        elif right is not None and left is not None and x is not None:
            self.left = left
            self.right = right
            self.data = x
    def insertKey(self, current, value):
        if current == None:
            return NRKTree(value)
        if value < current.data:
            current.left = insertKey(current.left, value)
        return current

def main(args=None):
    if args is None:
        args = []
    root = buildTree()
    sc = Scanner(System.in)
    print("Enter first number: ", end="")
    inputX0 = sc.nextInt()
    toPrint = nearestRightKey(root, inputX0)
    print(f"Key: {str(toPrint)}")
    sc.close()
def buildTree():
    randomX = ThreadLocalRandom.current().nextInt(0, 100 + 1)
    root = NRKTree(None, None, randomX)
    for i in range(1000):
        randomX = ThreadLocalRandom.current().nextInt(0, 100 + 1)
        root = root.insertKey(root, randomX)
    return root
def nearestRightKey(root, x0):
    if root == None:
        return 0
    else:
        if root.data - x0 > 0:
            temp = nearestRightKey(root.left, x0)
            if temp == 0:
                return # expr: root.data
            return temp
        else:
            return nearestRightKey(root.right, x0)

if __name__ == "__main__":
    main()

# --- 转换测试报告 ---
# 转换效率: 0.926
# 可解析度: 0.833 (5/6)
# 语法问题: 模块无法解析
#  - 行 33:26 invalid syntax
#    >     sc = Scanner(System.in)
# 语法问题: [def main] 行 33 invalid syntax
#    >     sc = Scanner(System.in)
# 未映射方法(Top):
#  - NRKTree.insertKey: 1
# --- 报告结束 ---
