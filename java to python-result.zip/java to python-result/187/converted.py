# --- File: ReverseBits.java ---

# package: com.thealgorithms.bitmanipulation

class ReverseBits:
    """* This class provides a method to reverse the bits of a 32-bit integer.
 * Reversing the bits means that the least significant bit (LSB) becomes
 * the most significant bit (MSB) and vice versa.
 *
 * Example:
 * Input (binary): 00000010100101000001111010011100 (43261596)
 * Output (binary): 00111001011110000010100101000000 (964176192)
 *
 * Time Complexity: O(32) - A fixed number of 32 iterations
 * Space Complexity: O(1) - No extra space used
 *
 * Note:
 * - If the input is negative, Java handles it using two’s complement representation.
 * - This function works on 32-bit integers by default.
 *
 * @author Bama Charan Chhandogi"""
    def __init__(self):
        pass
    @staticmethod
    def reverseBits(n):
        """* Reverses the bits of a 32-bit integer.
     *
     * @param n the integer whose bits are to be reversed
     * @return the integer obtained by reversing the bits of the input"""
        result = 0
        bitCount = 32
        for i in range(bitCount):
            result << = 1
            result | = (n & 1)
            n >> = 1
        return result

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.841
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 33:23 invalid syntax
#    >             result << = 1
# 语法问题: [class ReverseBits] 行 33 invalid syntax
#    >             result << = 1
# --- 报告结束 ---
