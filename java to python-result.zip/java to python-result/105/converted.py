# --- File: BSTFromSortedArray.java ---

# package: com.thealgorithms.datastructures.trees

# import: com.thealgorithms.datastructures.trees.BinaryTree.Node

class BSTFromSortedArray:
    """* Given a sorted array. Create a balanced binary search tree from it.
 *
 * Steps: 1. Find the middle element of array. This will act as root 2. Use the
 * left half recursively to create left subtree 3. Use the right half
 * recursively to create right subtree"""
    def __init__(self):
        pass
    @staticmethod
    def createBST(array):
        if array == None or array.length == 0:
            return None
        return createBST(array, 0, array.length - 1)
    @staticmethod
    def createBST(array, startIdx, endIdx):
        if startIdx > endIdx:
            return None
        mid = startIdx + (endIdx - startIdx) / 2
        root = Node(array[mid])
        root.left = createBST(array, startIdx, mid - 1)
        root.right = createBST(array, mid + 1, endIdx)
        return root

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.844
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
