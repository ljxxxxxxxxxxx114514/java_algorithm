# --- File: HashMap.java ---

# package: com.thealgorithms.datastructures.hashmap.hashing

class HashMap:
    """* A generic HashMap implementation that uses separate chaining with linked lists
 * to handle collisions. The class supports basic operations such as insert, delete,
 * and search, as well as displaying the contents of the hash map.
 *
 * @param <K> the type of keys maintained by this map
 * @param <V> the type of mapped values"""
    def __init__(self, hashSize):
        """* Constructs a HashMap with the specified hash size.
     *
     * @param hashSize the number of buckets in the hash map"""
        # 
     * Constructs a HashMap with the specified hash size.
     *
     * @param hashSize the number of buckets in the hash map
     
        # expr: SuppressWarnings
        self.hashSize = hashSize
        this.buckets =  new LinkedList[hashSize]
        for i in range(self.hashSize):
            buckets[i] = LinkedList()
    def computeHash(self, key):
        """* Computes the hash code for the specified key.
     * Null keys are hashed to bucket 0.
     *
     * @param key the key for which the hash code is to be computed
     * @return the hash code corresponding to the key"""
        # 
     * Computes the hash code for the specified key.
     * Null keys are hashed to bucket 0.
     *
     * @param key the key for which the hash code is to be computed
     * @return the hash code corresponding to the key
     
        if key == null:
            return 0
        hash = key.hashCode() % hashSize
        return hash < 0 ? hash + hashSize : hash
    def insert(self, key, value):
        """* Inserts the specified key-value pair into the hash map.
     * If the key already exists, the value is updated.
     *
     * @param key   the key to be inserted
     * @param value the value to be associated with the key"""
        # 
     * Inserts the specified key-value pair into the hash map.
     * If the key already exists, the value is updated.
     *
     * @param key   the key to be inserted
     * @param value the value to be associated with the key
     
        hash = computeHash(key)
        buckets[hash].insert(key, value)
    def delete(self, key):
        """* Deletes the key-value pair associated with the specified key from the hash map.
     *
     * @param key the key whose key-value pair is to be deleted"""
        # 
     * Deletes the key-value pair associated with the specified key from the hash map.
     *
     * @param key the key whose key-value pair is to be deleted
     
        hash = computeHash(key)
        buckets[hash].delete(key)
    def search(self, key):
        """* Searches for the value associated with the specified key in the hash map.
     *
     * @param key the key whose associated value is to be returned
     * @return the value associated with the specified key, or null if the key does not exist"""
        # 
     * Searches for the value associated with the specified key in the hash map.
     *
     * @param key the key whose associated value is to be returned
     * @return the value associated with the specified key, or null if the key does not exist
     
        hash = computeHash(key)
        Node<K, V> node = buckets[hash].findKey(key)
        return node != null ? node.getValue() : null
    def display(self):
        """* Displays the contents of the hash map, showing each bucket and its key-value pairs."""
        # 
     * Displays the contents of the hash map, showing each bucket and its key-value pairs.
     
        for i in range(self.hashSize):
            print("Bucket %d: %s%n", i, buckets[i].display(), end="")
    def clear(self):
        """* Clears the contents of the hash map by reinitializing each bucket."""
        # 
     * Clears the contents of the hash map by reinitializing each bucket.
     
        for i in range(self.hashSize):
            buckets[i] = LinkedList()
    def size(self):
        """* Gets the number of key-value pairs in the hash map.
     *
     * @return the number of key-value pairs in the hash map"""
        # 
     * Gets the number of key-value pairs in the hash map.
     *
     * @return the number of key-value pairs in the hash map
     
        size = 0
        for i in range(self.hashSize):
            size += buckets[i].isEmpty() ? 0 : 1
        return size

    class LinkedList:
        """* A nested static class that represents a linked list used for separate chaining in the hash map.
     *
     * @param <K> the type of keys maintained by this linked list
     * @param <V> the type of mapped values"""
        def insert(self, key, value):
            """* Inserts the specified key-value pair into the linked list.
         * If the linked list is empty, the pair becomes the head.
         * Otherwise, the pair is added to the end of the list.
         *
         * @param key   the key to be inserted
         * @param value the value to be associated with the key"""
            # 
         * Inserts the specified key-value pair into the linked list.
         * If the linked list is empty, the pair becomes the head.
         * Otherwise, the pair is added to the end of the list.
         *
         * @param key   the key to be inserted
         * @param value the value to be associated with the key
         
            Node<K, V> existingNode = findKey(key)
            if existingNode != null:
                existingNode.setValue(value)
            else:
                if isEmpty():
                    head = Node(key, value)
                else:
                    Node<K, V> temp = findEnd(head)
                    temp.setNext(new Node<>(key, value))
        def findEnd(self, node):
            """* Finds the last node in the linked list.
         *
         * @param node the starting node
         * @return the last node in the linked list"""
            # 
         * Finds the last node in the linked list.
         *
         * @param node the starting node
         * @return the last node in the linked list
         
            while node.getNext() != null:
                node = node.getNext()
            return node
        def findKey(self, key):
            """* Finds the node associated with the specified key in the linked list.
         *
         * @param key the key to search for
         * @return the node associated with the specified key, or null if not found"""
            # 
         * Finds the node associated with the specified key in the linked list.
         *
         * @param key the key to search for
         * @return the node associated with the specified key, or null if not found
         
            Node<K, V> temp = head
            while temp != null:
                if (key == null && temp.getKey() == null) || (temp.getKey() != null && temp.getKey().equals(key)):
                    return temp
                temp = temp.getNext()
            return null
        def delete(self, key):
            """* Deletes the node associated with the specified key from the linked list.
         * Handles the case where the key could be null.
         *
         * @param key the key whose associated node is to be deleted"""
            # 
         * Deletes the node associated with the specified key from the linked list.
         * Handles the case where the key could be null.
         *
         * @param key the key whose associated node is to be deleted
         
            if isEmpty():
                return
            if (key == null && head.getKey() == null) || (head.getKey() != null && head.getKey().equals(key)):
                pass
            else:
                head = head.getNext()
                return
            Node<K, V> current = head
            while current.getNext() != null:
                if (key == null && current.getNext().getKey() == null) || (current.getNext().getKey() != null && current.getNext().getKey().equals(key)):
                    current.setNext(current.getNext().getNext())
                    return
                current = current.getNext()
        def display(self):
            """* Displays the contents of the linked list as a string.
         *
         * @return a string representation of the linked list"""
            # 
         * Displays the contents of the linked list as a string.
         *
         * @return a string representation of the linked list
         
            return display(head)
        def display(self, node):
            """* Constructs a string representation of the linked list non-recursively.
         *
         * @param node the starting node
         * @return a string representation of the linked list starting from the given node"""
            # 
         * Constructs a string representation of the linked list non-recursively.
         *
         * @param node the starting node
         * @return a string representation of the linked list starting from the given node
         
            sb = StringBuilder()
            while node != null:
                sb.append(node.getKey()).append("=").append(node.getValue())
                node = node.getNext()
                if node != null:
                    sb.append(" -> ")
            return sb.toString().isEmpty() ? "null" : sb.toString()
        def isEmpty(self):
            """* Checks if the linked list is empty.
         *
         * @return true if the linked list is empty, false otherwise"""
            # 
         * Checks if the linked list is empty.
         *
         * @return true if the linked list is empty, false otherwise
         
            return head == null

        def __init__(self):
            self.head = None

    class Node:
        """* A nested static class representing a node in the linked list.
     *
     * @param <K> the type of key maintained by this node
     * @param <V> the type of value maintained by this node"""
        def __init__(self, key, value):
            """* Constructs a Node with the specified key and value.
         *
         * @param key   the key associated with this node
         * @param value the value associated with this node"""
            # 
         * Constructs a Node with the specified key and value.
         *
         * @param key   the key associated with this node
         * @param value the value associated with this node
         
            self.key = key
            self.value = value
        def getKey(self):
            """* Gets the key associated with this node.
         *
         * @return the key associated with this node"""
            # 
         * Gets the key associated with this node.
         *
         * @return the key associated with this node
         
            return key
        def getValue(self):
            """* Gets the value associated with this node.
         *
         * @return the value associated with this node"""
            # 
         * Gets the value associated with this node.
         *
         * @return the value associated with this node
         
            return value
        def setValue(self, value):
            self.value = value
        def getNext(self):
            """* Gets the next node in the linked list.
         *
         * @return the next node in the linked list"""
            # 
         * Gets the next node in the linked list.
         *
         * @return the next node in the linked list
         
            return next
        def setNext(self, next):
            """* Sets the next node in the linked list.
         *
         * @param next the next node to be linked"""
            # 
         * Sets the next node in the linked list.
         *
         * @param next the next node to be linked
         
            self.next = next

if __name__ == "__main__":
    pass
