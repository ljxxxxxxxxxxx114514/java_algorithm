# --- File: BinaryTree.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.LinkedList

# import: java.util.Queue

class BinaryTree:
    """* A binary tree is a data structure in which an element has two
 * successors(children). The left child is usually smaller than the parent, and
 * the right child is usually bigger.
 *
 * @author Unknown"""
    def __init__(self, root=None):
        """* Constructor"""
        if root is None:
            root = None
        elif root is not None:
            self.root = root
    def find(self, key):
        """* Method to find a Node with a certain value
     *
     * @param key Value being looked for
     * @return The node if it finds it, otherwise returns the parent"""
        current = self.root
        while current != None:
            if key < current.data:
                if current.left == None:
                    return current
                current = current.left
        return None
    def put(self, value):
        """* Inserts certain value into the Binary Tree
     *
     * @param value Value to be inserted"""
        newNode = Node(value)
        if root == None:
            root = newNode
        else:
            parent = find(value)
            if value < parent.data:
                parent.left = newNode
                parent.left.parent = parent
            else:
                parent.right = newNode
                parent.right.parent = parent
    def remove(self, value):
        """* Deletes a given value from the Binary Tree
     *
     * @param value Value to be deleted
     * @return If the value was deleted"""
        temp = find(value)
        if temp.data != value:
            return False
        if temp.right == None and temp.left == None:
            if temp == root:
                root = None
            return True
    def findSuccessor(self, n):
        """* This method finds the Successor to the Node given. Move right once and go
     * left down the tree as far as you can
     *
     * @param n Node that you want to find the Successor of
     * @return The Successor of the node"""
        if n.right == None:
            return n
        current = n.right
        parent = n.right
        while current != None:
            parent = current
            current = current.left
        return parent
    def getRoot(self):
        """* Returns the root of the Binary Tree
     *
     * @return the root of the Binary Tree"""
        return self.root
    def inOrder(self, localRoot):
        """* Prints leftChild - root - rightChild This is the equivalent of a depth
     * first search
     *
     * @param localRoot The local root of the binary tree"""
        if localRoot != None:
            inOrder(localRoot.left)
            print(f"{str(localRoot.data)} ", end="")
            inOrder(localRoot.right)
    def preOrder(self, localRoot):
        """* Prints root - leftChild - rightChild
     *
     * @param localRoot The local root of the binary tree"""
        if localRoot != None:
            print(f"{str(localRoot.data)} ", end="")
            preOrder(localRoot.left)
            preOrder(localRoot.right)
    def postOrder(self, localRoot):
        """* Prints leftChild - rightChild - root
     *
     * @param localRoot The local root of the binary tree"""
        if localRoot != None:
            postOrder(localRoot.left)
            postOrder(localRoot.right)
            print(f"{str(localRoot.data)} ", end="")
    def bfs(self, localRoot):
        """* Prints the tree in a breadth first search order This is similar to
     * pre-order traversal, but instead of being implemented with a stack (or
     * recursion), it is implemented with a queue
     *
     * @param localRoot The local root of the binary tree"""
        queue = LinkedList()
        if localRoot != None:
            queue.append(localRoot)
        while not (not queue):
            localRoot = queue.remove()
            print(f"{str(localRoot.data)} ", end="")
            if localRoot.right != None:
                queue.append(localRoot.right)
            if localRoot.left != None:
                queue.append(localRoot.left)

    class Node:
        """* This class implements the nodes that will go on the Binary Tree. They
     * consist of the data in them, the node to the left, the node to the right,
     * and the parent from which they came from.
     *
     * @author Unknown"""
        def __init__(self, value):
            """* Constructor of Node
         *
         * @param value Value to put in the node"""
            data = value
            left = None
            right = None
            parent = None

#
#  * This entire class is used to build a Binary Tree data structure. There is the
#  * Node Class and the Tree Class, both explained below.
#

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.971
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
