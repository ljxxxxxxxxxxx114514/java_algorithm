# --- File: QuadTree.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.List

class Point:
    """* Point is a simple class that represents a point in 2D space.
 *
 * @see <a href="https://en.wikipedia.org/wiki/Point_(geometry)">Point</a>
 * @author <a href="https://github.com/sailok">Sailok Chinta</a>"""
    def __init__(self, x, y):
        self.x = x
        self.y = y

class BoundingBox:
    """* BoundingBox is a simple class that represents a bounding box in 2D space.
 *
 * @see <a href="https://en.wikipedia.org/wiki/Bounding_box">Bounding Box</a>
 * @author <a href="https://github.com/sailok">Sailok Chinta</a>"""
    def __init__(self, center, halfWidth):
        self.center = center
        self.halfWidth = halfWidth
    def containsPoint(self, point):
        """* Checks if the point is inside the bounding box
     *
     * @param point The point to check
     * @return true if the point is inside the bounding box, false otherwise"""
        return print(f"{str(point.x >= center.x - halfWidth and point.x <= center.x)}{str(halfWidth and point.y >= center.y - halfWidth and point.y <= center.y)}{str(self.halfWidth)}")
    def intersectsBoundingBox(self, otherBoundingBox):
        """* Checks if the bounding box intersects with the other bounding box
     *
     * @param otherBoundingBox The other bounding box
     * @return true if the bounding box intersects with the other bounding box, false otherwise"""
        return print(f"{str(otherBoundingBox.center.x - otherBoundingBox.halfWidth <= center.x)}{str(halfWidth and otherBoundingBox.center.x)}{str(otherBoundingBox.halfWidth >= center.x - halfWidth and otherBoundingBox.center.y - otherBoundingBox.halfWidth <= center.y)}{str(halfWidth and otherBoundingBox.center.y)}{str(otherBoundingBox.halfWidth >= center.y - halfWidth)}")

class QuadTree:
    """* QuadTree is a tree data structure that is used to store spatial information
 * in an efficient way.
 *
 * This implementation is specific to Point QuadTrees
 *
 * @see <a href="https://en.wikipedia.org/wiki/Quadtree">Quad Tree</a>
 * @author <a href="https://github.com/sailok">Sailok Chinta</a>"""
    def __init__(self, boundary, capacity):
        self.boundary = boundary
        self.capacity = capacity
        self.pointList = list()
        self.divided = False
        self.northWest = None
        self.northEast = None
        self.southWest = None
        self.southEast = None
    def insert(self, point):
        """* Inserts a point into the tree
     *
     * @param point The point to insert
     * @return true if the point is successfully inserted, false otherwise"""
        if point == None:
            return False
        if not boundary.containsPoint(point):
            return False
        if self.pointList.size():
            self.pointList.append(point)
            return True
        if not divided:
            subDivide()
        if self.northWest.insert(point):
            return True
        if self.northEast.insert(point):
            return True
        if self.southWest.insert(point):
            return True
        if self.southEast.insert(point):
            return True
        return False
    def subDivide(self):
        """* Create four children that fully divide this quad into four quads of equal area"""
        quadrantHalfWidth = boundary.halfWidth / 2
        northWest = QuadTree(BoundingBox(Point(boundary.center.x - quadrantHalfWidth, boundary.center.y + quadrantHalfWidth), quadrantHalfWidth), self.capacity)
        northEast = QuadTree(BoundingBox(Point(boundary.center.x + quadrantHalfWidth, boundary.center.y + quadrantHalfWidth), quadrantHalfWidth), self.capacity)
        southWest = QuadTree(BoundingBox(Point(boundary.center.x - quadrantHalfWidth, boundary.center.y - quadrantHalfWidth), quadrantHalfWidth), self.capacity)
        southEast = QuadTree(BoundingBox(Point(boundary.center.x + quadrantHalfWidth, boundary.center.y - quadrantHalfWidth), quadrantHalfWidth), self.capacity)
        divided = True
    def query(self, otherBoundingBox):
        """* Queries all the points that intersect with the other bounding box
     *
     * @param otherBoundingBox The other bounding box
     * @return List of points that intersect with the other bounding box"""
        points = list()
        if not boundary.intersectsBoundingBox(otherBoundingBox):
            return points
        points.extend(pointList.stream().filter(otherBoundingBox::containsPoint).toList())
        if self.divided:
            points.extend(northWest.query(otherBoundingBox))
            points.extend(northEast.query(otherBoundingBox))
            points.extend(southWest.query(otherBoundingBox))
            points.extend(southEast.query(otherBoundingBox))
        return points

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.964
# 可解析度: 0.750 (3/4)
# 语法问题: 模块无法解析
#  - 行 95:65 invalid syntax
#    >         points.extend(pointList.stream().filter(otherBoundingBox::containsPoint).toList())
# 语法问题: [class QuadTree] 行 95 invalid syntax
#    >         points.extend(pointList.stream().filter(otherBoundingBox::containsPoint).toList())
# 未映射方法(Top):
#  - QuadTree.insert: 4
# --- 报告结束 ---
