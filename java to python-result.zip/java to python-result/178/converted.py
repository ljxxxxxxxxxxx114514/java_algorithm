# --- File: LowestSetBit.java ---

# package: com.thealgorithms.bitmanipulation

class LowestSetBit:
    def __init__(self):
        #  Private constructor to hide the default public one
    @staticmethod
    def isolateLowestSetBit(n):
        """* Isolates the lowest set bit of the given number. For example, if n = 18
     * (binary: 10010), the result will be 2 (binary: 00010).
     *
     * @param n the number whose lowest set bit will be isolated
     * @return the isolated lowest set bit of n"""
        return # expr: n & -n
    @staticmethod
    def clearLowestSetBit(n):
        """* Clears the lowest set bit of the given number.
     * For example, if n = 18 (binary: 10010), the result will be 16 (binary: 10000).
     *
     * @param n the number whose lowest set bit will be cleared
     * @return the number after clearing its lowest set bit"""
        return n & (n - 1)

# Unhandled node type: JavadocComment
#
#  * Lowest Set Bit
#  * @author Prayas Kumar (https://github.com/prayas7102)
#

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.750
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 8:5 expected an indented block
#    >     @staticmethod
# 语法问题: [class LowestSetBit] 行 8 expected an indented block
#    >     @staticmethod
# --- 报告结束 ---
