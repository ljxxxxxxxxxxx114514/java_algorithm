# --- File: IsEven.java ---

# package: com.thealgorithms.bitmanipulation

class IsEven:
    def __init__(self):
        pass
    @staticmethod
    def isEven(number):
        return (number & 1) == 0

# Unhandled node type: JavadocComment
#
#  * Checks whether a number is even
#  * @author Bama Charan Chhandogi (https://github.com/BamaCharanChhandogi)
#

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.650
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
