# --- File: RedBlackBST.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.Scanner

class RedBlackBST:
    """* @author jack870131"""
    RED: int = 0
    BLACK: int = 1
    def printTree(self, node):
        if node == nil:
            return
        printTree(node.left)
        " R " if System.out.print(((node.color == RED) else " B ") + "Key: " + node.key + " Parent: " + node.p.key + "\n")
        printTree(node.right)
    def printTreepre(self, node):
        if node == nil:
            return
        " R " if System.out.print(((node.color == RED) else " B ") + "Key: " + node.key + " Parent: " + node.p.key + "\n")
        printTreepre(node.left)
        printTreepre(node.right)
    def findNode(self, findNode, node):
        if root == nil:
            return None
        if findNode.key < node.key:
            if node.left != nil:
                return findNode(findNode, node.left)
        return None
    def insert(self, node):
        temp = self.root
        if root == nil:
            root = node
            node.color = BLACK
            node.p = nil
        else:
            node.color = RED
            while True:
                if node.key < temp.key:
                    if temp.left == nil:
                        temp.left = node
                        node.p = temp
                        break
                    else:
                        temp = temp.left
            fixTree(node)
    def fixTree(self, node):
        while node.p.color == RED:
            y = self.nil
            if node.p == node.p.p.left:
                y = node.p.p.right
                if y != nil and y.color == RED:
                    node.p.color = BLACK
                    y.color = BLACK
                    node.p.p.color = RED
                    node = node.p.p
                    continue
                if node == node.p.right:
                    node = node.p
                    rotateLeft(node)
                node.p.color = BLACK
                node.p.p.color = RED
                rotateRight(node.p.p)
            else:
                y = node.p.p.left
                if y != nil and y.color == RED:
                    node.p.color = BLACK
                    y.color = BLACK
                    node.p.p.color = RED
                    node = node.p.p
                    continue
                if node == node.p.left:
                    node = node.p
                    rotateRight(node)
                node.p.color = BLACK
                node.p.p.color = RED
                rotateLeft(node.p.p)
        root.color = BLACK
    def rotateLeft(self, node):
        if node.p != nil:
            if node == node.p.left:
                node.p.left = node.right
            else:
                node.p.right = node.right
            node.right.p = node.p
            node.p = node.right
            if node.right.left != nil:
                node.right.left.p = node
            node.right = node.right.left
            node.p.left = node
        else:
            right = root.right
            root.right = right.left
            right.left.p = root
            root.p = right
            right.left = root
            right.p = nil
            root = right
    def rotateRight(self, node):
        if node.p != nil:
            if node == node.p.left:
                node.p.left = node.left
            else:
                node.p.right = node.left
            node.left.p = node.p
            node.p = node.left
            if node.left.right != nil:
                node.left.right.p = node
            node.left = node.left.right
            node.p.right = node
        else:
            left = root.left
            root.left = root.left.right
            left.right.p = root
            root.p = left
            left.right = root
            left.p = nil
            root = left
    def transplant(self, target, with_):
        if target.p == nil:
            root = with_
        with_.p = target.p
    def treeMinimum(self, subTreeRoot):
        while subTreeRoot.left != nil:
            subTreeRoot = subTreeRoot.left
        return subTreeRoot
    def delete(self, z):
        result = findNode(z, root)
        if result == None:
            return False
        # expr: Node x
        y = z
        yorigcolor = y.color
        if z.left == nil:
            x = z.right
            transplant(z, z.right)
        if yorigcolor == BLACK:
            deleteFixup(x)
        return True
    def deleteFixup(self, x):
        while x != root and x.color == BLACK:
            if x == x.p.left:
                w = x.p.right
                if w.color == RED:
                    w.color = BLACK
                    x.p.color = RED
                    rotateLeft(x.p)
                    w = x.p.right
                if w.left.color == BLACK and w.right.color == BLACK:
                    w.color = RED
                    x = x.p
                    continue
                if w.right.color == RED:
                    w.color = x.p.color
                    x.p.color = BLACK
                    w.right.color = BLACK
                    rotateLeft(x.p)
                    x = root
            else:
                w = x.p.left
                if w.color == RED:
                    w.color = BLACK
                    x.p.color = RED
                    rotateRight(x.p)
                    w = x.p.left
                if w.right.color == BLACK and w.left.color == BLACK:
                    w.color = RED
                    x = x.p
                    continue
                if w.left.color == RED:
                    w.color = x.p.color
                    x.p.color = BLACK
                    w.left.color = BLACK
                    rotateRight(x.p)
                    x = root
        x.color = BLACK
    def insertDemo(self):
        scan = Scanner(System.in)
        print("Add items")
        # expr: int item
        # expr: Node node
        item = scan.int(input())()
        while item != -999:
            node = Node(item)
            insert(node)
            item = scan.int(input())()
        printTree(root)
        print("Pre order")
        printTreepre(root)
        scan.close()
    def deleteDemo(self):
        scan = Scanner(System.in)
        print("Delete items")
        # expr: int item
        # expr: Node node
        item = scan.int(input())()
        node = Node(item)
        print(f"Deleting item {str(item)}", end="")
        if delete(node):
            print(": deletednot ", end="")
        else:
            print(": does not existnot ", end="")
        System.out.println()
        printTree(root)
        print("Pre order")
        printTreepre(root)
        scan.close()

    def __init__(self):
        self.nil = new Node(-1)
        self.root = nil

    class Node:
        def __init__(self, key):
            self.key = key

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.966
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 15:59 invalid syntax
#    >         " R " if System.out.print(((node.color == RED) else " B ") + "Key: " + node.key + " Parent: " + node.p.key + "\n")
# 语法问题: [class RedBlackBST] 行 15 invalid syntax
#    >         " R " if System.out.print(((node.color == RED) else " B ") + "Key: " + node.key + " Parent: " + node.p.key + "\n")
# 未处理节点类型(Top):
#  - ExpressionStmt: 5
# --- 报告结束 ---
