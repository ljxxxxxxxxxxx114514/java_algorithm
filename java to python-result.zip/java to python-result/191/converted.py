# --- File: Xs3Conversion.java ---

# package: com.thealgorithms.bitmanipulation

class Xs3Conversion:
    """* This class provides methods to convert between XS-3 (Excess-3) and binary.
 *
 * Excess-3, also called XS-3, is a binary-coded decimal (BCD) code in which each decimal digit is represented by its corresponding 4-bit binary value plus 3.
 *
 * For more information, refer to the
 * <a href="https://en.wikipedia.org/wiki/Excess-3">Excess-3</a> Wikipedia page.
 *
 * <b>Example usage:</b>
 * <pre>
 * int binary = Xs3Conversion.xs3ToBinary(0x4567);
 * System.out.println("XS-3 0x4567 to binary: " + binary); // Output: 1234
 *
 * int xs3 = Xs3Conversion.binaryToXs3(1234);
 * System.out.println("Binary 1234 to XS-3: " + Integer.toHexString(xs3)); // Output: 0x4567
 * </pre>"""
    def __init__(self):
        pass
    @staticmethod
    def xs3ToBinary(xs3):
        """* Converts an XS-3 (Excess-3) number to binary.
     *
     * @param xs3 The XS-3 number.
     * @return The corresponding binary number."""
        binary = 0
        multiplier = 1
        while xs3 > 0:
            digit = (xs3 & 0xF) - 3
            print(str(binary) + str(= digit * multiplier))
            multiplier * = 10
            xs3 >> = 4
        return binary
    @staticmethod
    def binaryToXs3(binary):
        """* Converts a binary number to XS-3 (Excess-3).
     *
     * @param binary The binary number.
     * @return The corresponding XS-3 number."""
        xs3 = 0
        shift = 0
        while binary > 0:
            digit = (binary % 10) + 3
            xs3 | = (digit << (shift * 4))
            binary / = 10
            shift += 1
        return xs3

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.917
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 33:37 invalid syntax
#    >             print(str(binary) + str(= digit * multiplier))
# 语法问题: [class Xs3Conversion] 行 33 invalid syntax
#    >             print(str(binary) + str(= digit * multiplier))
# --- 报告结束 ---
