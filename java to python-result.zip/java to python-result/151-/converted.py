# --- File: Permutation.java ---

# package: com.thealgorithms.backtracking

# import: java.util.LinkedList

# import: java.util.List

class Permutation:
    """* Finds all permutations of given array
 * @author Alan Piao (<a href="https://github.com/cpiao3">Git-Alan Piao</a>)"""
    def __init__(self):
        pass
    @staticmethod
    def permutation(arr):
        """* Find all permutations of given array using backtracking
     * @param arr the array.
     * @param <T> the type of elements in the array.
     * @return a list of all permutations."""
        array = arr.clone()
        result = LinkedList()
        backtracking(array, 0, result)
        return result
    @staticmethod
    def backtracking(arr, index, result):
        """* Backtrack all possible orders of a given array
     * @param arr the array.
     * @param index the starting index.
     * @param result the list contains all permutations.
     * @param <T> the type of elements in the array."""
        if index == arr.length:
            result.append(arr.clone())
        for i in range(index, arr.length):
            swap(index, i, arr)
            backtracking(arr, index + 1, result)
            swap(index, i, arr)
    @staticmethod
    def swap(a, b, arr):
        """* Swap two element for a given array
     * @param a first index
     * @param b second index
     * @param arr the array.
     * @param <T> the type of elements in the array."""
        temp = arr[a]
        arr[a] = arr[b]
        arr[b] = temp

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.845
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
