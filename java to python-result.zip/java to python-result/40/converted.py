# --- File: DisjointSetUnionBySize.java ---

# package: com.thealgorithms.datastructures.disjointsetunion

class DisjointSetUnionBySize:
    """* Disjoint Set Union (DSU) with Union by Size.
 * This data structure tracks a set of elements partitioned into disjoint (non-overlapping) subsets.
 * It supports two primary operations efficiently:
 *
 * <ul>
 *     <li>Find: Determine which subset a particular element belongs to.</li>
 *     <li>Union: Merge two subsets into a single subset using union by size.</li>
 * </ul>
 *
 * Union by size always attaches the smaller tree under the root of the larger tree.
 * This helps keep the tree shallow, improving the efficiency of find operations.
 *
 * @see <a href="https://en.wikipedia.org/wiki/Disjoint-set_data_structure">Disjoint Set Union (Wikipedia)</a>"""
    def makeSet(self, value):
        """* Creates a new disjoint set containing the single specified element.
     * @param value the element to be placed in a new singleton set
     * @return a node representing the new set"""
        # 
     * Creates a new disjoint set containing the single specified element.
     * @param value the element to be placed in a new singleton set
     * @return a node representing the new set
     
        return new Node<>(value)
    def findSet(self, node):
        """* Finds and returns the representative (root) of the set containing the given node.
     * This method applies path compression to flatten the tree structure for future efficiency.
     * @param node the node whose set representative is to be found
     * @return the representative (root) node of the set"""
        # 
     * Finds and returns the representative (root) of the set containing the given node.
     * This method applies path compression to flatten the tree structure for future efficiency.
     * @param node the node whose set representative is to be found
     * @return the representative (root) node of the set
     
        if node != node.parent:
            node.parent = findSet(node.parent)
        return node.parent
    def unionSets(self, x, y):
        """* Merges the sets containing the two given nodes using union by size.
     * The root of the smaller set is attached to the root of the larger set.
     * @param x a node in the first set
     * @param y a node in the second set"""
        # 
     * Merges the sets containing the two given nodes using union by size.
     * The root of the smaller set is attached to the root of the larger set.
     * @param x a node in the first set
     * @param y a node in the second set
     
        rootX = findSet(x)
        rootY = findSet(y)
        if rootX == rootY:
            return
        if rootX.size < rootY.size:
            rootX.size
            rootY.size
        else:
            rootX.parent = rootY
            print(f"{str(rootY.size)}{str(= rootX.size)}")

    class Node:
        """* Node class for DSU by size.
     * Each node keeps track of its parent and the size of the set it represents."""
        def __init__(self, value):
            self.value = value
            self.parent = this
            self.size = 1

#  This implementation uses union by size instead of union by rank.
#  The size field tracks the number of elements in each set.
#  When two sets are merged, the smaller set is always attached to the larger set's root.
#  This helps keep the tree shallow and improves the efficiency of find operations.

if __name__ == "__main__":
    pass
