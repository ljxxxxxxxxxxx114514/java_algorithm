# --- File: BoundaryTraversal.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.ArrayList

# import: java.util.Deque

# import: java.util.LinkedList

# import: java.util.List

class BoundaryTraversal:
    """* BoundaryTraversal
 * <p>
 * Start with the Root:
 * Add the root node to the boundary list.
 * Traverse the Left Boundary (Excluding Leaf Nodes):
 * Move down the left side of the tree, adding each non-leaf node to the boundary list.
 * If a node has a left child, go left; otherwise, go right.
 * Visit All Leaf Nodes:
 * Traverse the tree and add all leaf nodes to the boundary list, from left to right.
 * Traverse the Right Boundary (Excluding Leaf Nodes) in Reverse Order:
 * Move up the right side of the tree, adding each non-leaf node to a temporary list.
 * If a node has a right child, go right; otherwise, go left.
 * Reverse the temporary list and add it to the boundary list.
 * Combine and Output:
 * The final boundary list contains the root, left boundary, leaf nodes, and reversed right boundary in that order."""
    def __init__(self):
        pass
    @staticmethod
    def boundaryTraversal(root):
        #  Main function for boundary traversal, returns a list of boundary nodes in order
        result = list()
        if root == None:
            return result
        if not isLeaf(root):
            result.append(root.data)
        addLeftBoundary(root, result)
        addLeaves(root, result)
        addRightBoundary(root, result)
        return result
    @staticmethod
    def addLeftBoundary(node, result):
        #  Adds the left boundary, including nodes that have no left child but have a right child
        cur = node.left
        if cur == None and node.right != None:
            cur = node.right
        while cur != None:
            if not isLeaf(cur):
                result.append(cur.data)
            if cur.left != None:
                cur = cur.left
    @staticmethod
    def addLeaves(node, result):
        #  Adds leaf nodes (nodes without children)
        if node == None:
            return
        if isLeaf(node):
            result.append(node.data)
        else:
            addLeaves(node.left, result)
            addLeaves(node.right, result)
    @staticmethod
    def addRightBoundary(node, result):
        #  Adds the right boundary, excluding leaf nodes
        cur = node.right
        temp = list()
        if cur != None and node.left == None:
            return
        while cur != None:
            if not isLeaf(cur):
                temp.append(cur.data)
            if cur.right != None:
                cur = cur.right
        for i in range(temp.size(), = 0, -1):
            result.append(temp[i])
    @staticmethod
    def isLeaf(node):
        #  Checks if a node is a leaf node
        return node.left == None and node.right == None
    @staticmethod
    def iterativeBoundaryTraversal(root):
        #  Iterative boundary traversal
        result = list()
        if root == None:
            return result
        if not isLeaf(root):
            result.append(root.data)
        cur = root.left
        if cur == None and root.right != None:
            cur = root.right
        while cur != None:
            if not isLeaf(cur):
                result.append(cur.data)
            cur.left if cur = (cur.left != None) else cur.right
        addLeaves(root, result)
        cur = root.right
        stack = LinkedList()
        if cur != None and root.left == None:
            return result
        while cur != None:
            if not isLeaf(cur):
                stack.push(cur.data)
            cur.right if cur = (cur.right != None) else cur.left
        while not (not stack):
            result.append(stack.pop())
        return result

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.934
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 76:37 invalid syntax
#    >         for i in range(temp.size(), = 0, -1):
# 语法问题: [class BoundaryTraversal] 行 76 invalid syntax
#    >         for i in range(temp.size(), = 0, -1):
# 未映射方法(Top):
#  - Deque.push: 1
# --- 报告结束 ---
