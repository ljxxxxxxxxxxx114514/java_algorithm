# --- File: CheckTreeIsSymmetric.java ---

# package: com.thealgorithms.datastructures.trees

# import: com.thealgorithms.datastructures.trees.BinaryTree.Node

class CheckTreeIsSymmetric:
    """* Check if a binary tree is symmetric or not.
 * A binary tree is a symmetric tree if the left and right subtree of root are mirror image.
 * Below is a symmetric tree
 *                               1
 *                   /                         \
 *                2                           2
 *         /                \             /             \
 *      3                    4         4                3
 *
 * Below is not symmetric because values is different in last level
 *                               1
 *                   /                         \
 *                 2                           2
 *         /                \             /             \
 *      3                    5         4                3
 * <p>
 * Approach:
 * Recursively check for left and right subtree of root
 * 1. left subtrees root's values should be equal right subtree's root value
 * 2. recursively check with left subtrees' left child VS right subtree's right child AND
 * left subtree's right child VS right subtree left child
 * Complexity
 * 1. Time: O(n)
 * 2. Space: O(lg(n)) for height of tree
 *
 * @author kumanoit on 10/10/22 IST 12:52 AM"""
    def __init__(self):
        pass
    @staticmethod
    def isSymmetric(root):
        if root == None:
            return True
        return isSymmetric(root.left, root.right)
    @staticmethod
    def isSymmetric(leftSubtreeRoot, rightSubtreeRoot):
        if leftSubtreeRoot == None and rightSubtreeRoot == None:
            return True
        if isInvalidSubtree(leftSubtreeRoot, rightSubtreeRoot):
            return False
        return isSymmetric(leftSubtreeRoot.right, rightSubtreeRoot.left) and isSymmetric(leftSubtreeRoot.left, rightSubtreeRoot.right)
    @staticmethod
    def isInvalidSubtree(leftSubtreeRoot, rightSubtreeRoot):
        return leftSubtreeRoot == None or rightSubtreeRoot == None or leftSubtreeRoot.data != rightSubtreeRoot.data

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.844
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
