# --- File: KahnsAlgorithm.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

# import: java.util.HashMap

# import: java.util.LinkedHashMap

# import: java.util.LinkedList

# import: java.util.Map

# import: java.util.Queue

# import: java.util.Set

class AdjacencyList:
    """* A class representing the adjacency list of a directed graph. The adjacency list
 * maintains a mapping of vertices to their adjacent vertices.
 *
 * @param <E> the type of vertices, extending Comparable to ensure that vertices
 * can be compared"""
    def __init__(self):
        """* Constructor to initialize the adjacency list."""
        # 
     * Constructor to initialize the adjacency list.
     
        adj = LinkedHashMap()
    def addEdge(self, from, to):
        """* Adds a directed edge from one vertex to another in the adjacency list.
     * If the vertex does not exist, it will be added to the list.
     *
     * @param from the starting vertex of the directed edge
     * @param to   the destination vertex of the directed edge"""
        # 
     * Adds a directed edge from one vertex to another in the adjacency list.
     * If the vertex does not exist, it will be added to the list.
     *
     * @param from the starting vertex of the directed edge
     * @param to   the destination vertex of the directed edge
     
        if !adj.containsKey(from):
            adj[from] = new ArrayList<>()
        adj.get(from).add(to)
        if !adj.containsKey(to):
            adj[to] = new ArrayList<>()
    def getAdjacents(self, v):
        """* Retrieves the list of adjacent vertices for a given vertex.
     *
     * @param v the vertex whose adjacent vertices are to be fetched
     * @return an ArrayList of adjacent vertices for vertex v"""
        # 
     * Retrieves the list of adjacent vertices for a given vertex.
     *
     * @param v the vertex whose adjacent vertices are to be fetched
     * @return an ArrayList of adjacent vertices for vertex v
     
        return adj.get(v)
    def getVertices(self):
        """* Retrieves the set of all vertices present in the graph.
     *
     * @return a set containing all vertices in the graph"""
        # 
     * Retrieves the set of all vertices present in the graph.
     *
     * @return a set containing all vertices in the graph
     
        return adj.keySet()

class TopologicalSort:
    """* A class that performs topological sorting on a directed graph using Kahn's algorithm.
 *
 * @param <E> the type of vertices, extending Comparable to ensure that vertices
 * can be compared"""
    def __init__(self, graph):
        """* Constructor to initialize the topological sorting class with a given graph.
     *
     * @param graph the directed graph represented as an adjacency list"""
        # 
     * Constructor to initialize the topological sorting class with a given graph.
     *
     * @param graph the directed graph represented as an adjacency list
     
        self.graph = graph
    def calculateInDegree(self):
        """* Calculates the in-degree of all vertices in the graph. The in-degree is
     * the number of edges directed into a vertex."""
        # 
     * Calculates the in-degree of all vertices in the graph. The in-degree is
     * the number of edges directed into a vertex.
     
        inDegree = HashMap()
        for vertex in graph.getVertices():
            inDegree.setdefault(vertex, 0)
            for adjacent in graph.getAdjacents(vertex):
                inDegree[adjacent] = inDegree.getOrDefault(adjacent, 0) + 1
    def topSortOrder(self):
        """* Returns an ArrayList containing the vertices of the graph arranged in
     * topological order. Topological sorting ensures that for any directed edge
     * (u, v), vertex u appears before vertex v in the ordering.
     *
     * @return an ArrayList of vertices in topological order
     * @throws IllegalStateException if the graph contains a cycle"""
        # 
     * Returns an ArrayList containing the vertices of the graph arranged in
     * topological order. Topological sorting ensures that for any directed edge
     * (u, v), vertex u appears before vertex v in the ordering.
     *
     * @return an ArrayList of vertices in topological order
     * @throws IllegalStateException if the graph contains a cycle
     
        calculateInDegree()
        q = LinkedList()
        for entry in inDegree.entrySet():
            if entry.getValue() == 0:
                q.append(entry.getKey())
        answer = []
        processedVertices = 0
        while !q.isEmpty():
            current = q.poll()
            answer.append(current)
            processedVertices += 1
            for adjacent in graph.getAdjacents(current):
                inDegree[adjacent] = inDegree.get(adjacent) - 1
                if inDegree.get(adjacent) == 0:
                    q.append(adjacent)
        if processedVertices != graph.getVertices().size():
            raise IllegalStateException("Graph contains a cycle, topological sort not possible")
        return answer

class KahnsAlgorithm:
    """* A driver class that sorts a given graph in topological order using Kahn's algorithm."""
    def __init__(self):
        pass

def main(args=None):
    if args is None:
        args = []
    graph = AdjacencyList()
    graph.addEdge("a", "b")
    graph.addEdge("c", "a")
    graph.addEdge("a", "d")
    graph.addEdge("b", "d")
    graph.addEdge("c", "u")
    graph.addEdge("u", "b")
    topSort = TopologicalSort(graph)
    for s in topSort.topSortOrder():
        print(f"{str(s)} ", end="")

if __name__ == "__main__":
    main()
