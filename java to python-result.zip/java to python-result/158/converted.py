# --- File: BcdConversion.java ---

# package: com.thealgorithms.bitmanipulation

class BcdConversion:
    """* This class provides methods to convert between BCD (Binary-Coded Decimal) and decimal numbers.
 *
 * BCD is a class of binary encodings of decimal numbers where each decimal digit is represented by a fixed number of binary digits, usually four or eight.
 *
 * For more information, refer to the
 * <a href="https://en.wikipedia.org/wiki/Binary-coded_decimal">Binary-Coded Decimal</a> Wikipedia page.
 *
 * <b>Example usage:</b>
 * <pre>
 * int decimal = BcdConversion.bcdToDecimal(0x1234);
 * System.out.println("BCD 0x1234 to decimal: " + decimal); // Output: 1234
 *
 * int bcd = BcdConversion.decimalToBcd(1234);
 * System.out.println("Decimal 1234 to BCD: " + Integer.toHexString(bcd)); // Output: 0x1234
 * </pre>"""
    def __init__(self):
        pass
    @staticmethod
    def bcdToDecimal(bcd):
        """* Converts a BCD (Binary-Coded Decimal) number to a decimal number.
     * <p>Steps:
     * <p>1. Validate the BCD number to ensure all digits are between 0 and 9.
     * <p>2. Extract the last 4 bits (one BCD digit) from the BCD number.
     * <p>3. Multiply the extracted digit by the corresponding power of 10 and add it to the decimal number.
     * <p>4. Shift the BCD number right by 4 bits to process the next BCD digit.
     * <p>5. Repeat steps 1-4 until the BCD number is zero.
     *
     * @param bcd The BCD number.
     * @return The corresponding decimal number.
     * @throws IllegalArgumentException if the BCD number contains invalid digits."""
        decimal = 0
        multiplier = 1
        while bcd > 0:
            digit = bcd & 0xF
            if digit > 9:
                raise ValueError("Invalid BCD digit: " + digit)
            print(str(decimal) + str(= digit * multiplier))
            multiplier * = 10
            bcd >> = 4
        return decimal
    @staticmethod
    def decimalToBcd(decimal):
        """* Converts a decimal number to BCD (Binary-Coded Decimal).
     * <p>Steps:
     * <p>1. Check if the decimal number is within the valid range for BCD (0 to 9999).
     * <p>2. Extract the last decimal digit from the decimal number.
     * <p>3. Shift the digit to the correct BCD position and add it to the BCD number.
     * <p>4. Remove the last decimal digit from the decimal number.
     * <p>5. Repeat steps 2-4 until the decimal number is zero.
     *
     * @param decimal The decimal number.
     * @return The corresponding BCD number.
     * @throws IllegalArgumentException if the decimal number is greater than 9999."""
        if decimal < 0 or decimal > 9999:
            raise ValueError("Value out of bounds for BCD representation: " + decimal)
        bcd = 0
        shift = 0
        while decimal > 0:
            digit = decimal % 10
            bcd | = (digit << (shift * 4))
            decimal / = 10
            shift += 1
        return bcd

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.930
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 42:38 invalid syntax
#    >             print(str(decimal) + str(= digit * multiplier))
# 语法问题: [class BcdConversion] 行 42 invalid syntax
#    >             print(str(decimal) + str(= digit * multiplier))
# --- 报告结束 ---
