# --- File: LeftistHeap.java ---

# package: com.thealgorithms.datastructures.heaps

# import: java.util.ArrayList

class LeftistHeap:
    """* This class implements a Leftist Heap, which is a type of priority queue
 * that follows similar operations to a binary min-heap but allows for
 * unbalanced structures based on the leftist property.
 *
 * <p>
 * A Leftist Heap maintains the leftist property, which ensures that the
 * left subtree is heavier than the right subtree based on the
 * null-path length (npl) values. This allows for efficient merging
 * of heaps and supports operations like insertion, extraction of
 * the minimum element, and in-order traversal.
 * </p>
 *
 * <p>
 * For more information on Leftist Heaps, visit:
 * <a href="https://iq.opengenus.org/leftist-heap/">OpenGenus</a>
 * </p>"""
    def __init__(self):
        #  Constructor initializing an empty Leftist Heap
        root = None
    def isEmpty(self):
        """* Checks if the heap is empty.
     *
     * @return true if the heap is empty; false otherwise"""
        return root == None
    def clear(self):
        """* Resets the heap to its initial state, effectively clearing all elements."""
        root = None
    def merge(self, h1):
        """* Merges the contents of another Leftist Heap into this one.
     *
     * @param h1 the LeftistHeap to be merged into this heap"""
        root = merge(root, h1.root)
        h1.root = None
    def merge(self, a, b):
        """* Merges two nodes, maintaining the leftist property.
     *
     * @param a the first node
     * @param b the second node
     * @return the merged node maintaining the leftist property"""
        if a == None:
            return b
        if b == None:
            return a
        if a.element > b.element:
            temp = a
            a = b
            b = temp
        a.right = merge(a.right, b)
        if a.left == None:
            a.left = a.right
            a.right = None
        else:
            if a.left.npl < a.right.npl:
                temp = a.left
                a.left = a.right
                a.right = temp
            print(f"{str(a.npl = a.right.npl)}{str(1)}")
        return a
    def insert(self, a):
        """* Inserts a new element into the Leftist Heap.
     *
     * @param a the element to be inserted"""
        root = merge(Node(a), root)
    def extractMin(self):
        """* Extracts and removes the minimum element from the heap.
     *
     * @return the minimum element in the heap, or -1 if the heap is empty"""
        if isEmpty():
            return -1
        min = root.element
        root = merge(root.left, root.right)
        return min
    def inOrder(self):
        """* Returns a list of the elements in the heap in in-order traversal.
     *
     * @return an ArrayList containing the elements in in-order"""
        lst = list()
        inOrderAux(root, lst)
        return list(lst)
    def inOrderAux(self, n, lst):
        """* Auxiliary function for in-order traversal
     *
     * @param n the current node
     * @param lst the list to store the elements in in-order"""
        if n == None:
            return
        inOrderAux(n.left, lst)
        lst.append(n.element)
        inOrderAux(n.right, lst)

    class Node:
        def __init__(self, element):
            #  Node constructor that initializes the element and sets child pointers to null
            self.element = element
            left = None
            right = None
            npl = 0

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.973
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 64:25 keyword can't be an expression
# 语法问题: [class LeftistHeap] 行 64 keyword can't be an expression
#    >             print(f"{str(a.npl = a.right.npl)}{str(1)}")
# --- 报告结束 ---
