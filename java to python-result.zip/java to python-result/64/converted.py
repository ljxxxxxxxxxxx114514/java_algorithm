# --- File: MinPriorityQueue.java ---

# package: com.thealgorithms.datastructures.heaps

class MinPriorityQueue:
    """* A MinPriorityQueue is a specialized data structure that maintains the
 * min-heap property, where the smallest element has the highest priority.
 *
 * <p>In a min-priority queue, every parent node is less than or equal
 * to its child nodes, which ensures that the smallest element can
 * always be efficiently retrieved.</p>
 *
 * <p>Functions:</p>
 * <ul>
 *     <li><b>insert(int key)</b>: Inserts a new key into the queue.</li>
 *     <li><b>delete()</b>: Removes and returns the highest priority value (the minimum).</li>
 *     <li><b>peek()</b>: Returns the highest priority value without removing it.</li>
 *     <li><b>isEmpty()</b>: Checks if the queue is empty.</li>
 *     <li><b>isFull()</b>: Checks if the queue is full.</li>
 *     <li><b>heapSort()</b>: Sorts the elements in ascending order.</li>
 *     <li><b>print()</b>: Prints the current elements in the queue.</li>
 * </ul>"""
    def __init__(self, c):
        """* Initializes a new MinPriorityQueue with a specified capacity.
     *
     * @param c the maximum number of elements the queue can hold"""
        self.capacity = c
        self.size = 0
        self.heap =  new int[c + 1]
    def insert(self, key):
        """* Inserts a new key into the min-priority queue.
     *
     * @param key the value to be inserted"""
        if this.isFull():
            raise IllegalStateException("MinPriorityQueue is full. Cannot insert new element.")
        print(f"{str(self.heap[self.size)}{str(1] = key)}")
        k = self.size + 1
        while k > 1:
            if self.heap[k] < self.heap[k / 2]:
                temp = self.heap[k]
                self.heap[k] = self.heap[k / 2]
                self.heap[k / 2] = temp
            k = k / 2
        self.size += 1
    def peek(self):
        """* Retrieves the highest priority value (the minimum) without removing it.
     *
     * @return the minimum value in the queue
     * @throws IllegalStateException if the queue is empty"""
        if isEmpty():
            raise IllegalStateException("MinPriorityQueue is empty. Cannot peek.")
        return self.heap[1]
    def isEmpty(self):
        """* Checks whether the queue is empty.
     *
     * @return true if the queue is empty, false otherwise"""
        return size == 0
    def isFull(self):
        """* Checks whether the queue is full.
     *
     * @return true if the queue is full, false otherwise"""
        return size == capacity
    def print(self):
        """* Prints the elements of the queue."""
        for i in range(1, = self.size):
            print(f"{str(self.heap[i])} ", end="")
        System.out.println()
    def heapSort(self):
        """* Sorts the elements in the queue using heap sort."""
        for i in range(1, = self.size):
            this.delete()
    def sink(self):
        """* Reorders the heap after a deletion to maintain the heap property."""
        k = 1
        while 2 * k < = self.size:
            minIndex = k
            if 2 * k < = self.size and self.heap[2 * k] < self.heap[minIndex]:
                minIndex = 2 * k
            if print(f"{str(2 * k)}{str(1 <= self.size and self.heap[2 * k)}{str(1] < self.heap[minIndex])}"):
                print(f"{str(minIndex = 2 * k)}{str(1)}")
            if minIndex == k:
                break
            temp = self.heap[k]
            self.heap[k] = self.heap[minIndex]
            self.heap[minIndex] = temp
            k = minIndex
    def delete(self):
        """* Deletes and returns the highest priority value (the minimum) from the queue.
     *
     * @return the minimum value from the queue
     * @throws IllegalStateException if the queue is empty"""
        if isEmpty():
            raise IllegalStateException("MinPriorityQueue is empty. Cannot delete.")
        min = self.heap[1]
        self.heap[1] = self.heap[self.size]
        self.size -= 1
        this.sink()
        return min

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.986
# 可解析度: 0.500 (1/2)
# 语法问题: 模块无法解析
#  - 行 29:28 invalid syntax
#    >         self.heap =  new int[c + 1]
# 语法问题: [class MinPriorityQueue] 行 29 invalid syntax
#    >         self.heap =  new int[c + 1]
# --- 报告结束 ---
