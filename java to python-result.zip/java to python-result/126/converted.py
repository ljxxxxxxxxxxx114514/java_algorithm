# --- File: PrintTopViewofTree.java ---

# package: com.thealgorithms.datastructures.trees

# import: java.util.HashSet

# import: java.util.LinkedList

# import: java.util.Queue

class TreeNode:
    def __init__(self, key):
        #  Constructor
        self.key = key
        left = None
        right = None

class QItem:
    def __init__(self, n, h):
        node = n
        hd = h

class Tree:
    def __init__(self, n=None):
        if n is None:
            #  Constructors
            root = None
        elif n is not None:
            root = n
    def printTopView(self):
        #  This method prints nodes in top view of binary tree
        if root == None:
            return
        set = HashSet()
        queue = LinkedList()
        queue.append(QItem(root, 0))
        while not (not queue):
            qi = queue.remove()
            hd = qi.hd
            n = qi.node
            if not hd in set:
                set.append(hd)
                print(f"{str(n.key)} ", end="")
            if n.left != None:
                queue.append(QItem(n.left, hd - 1))
            if n.right != None:
                queue.append(QItem(n.right, hd + 1))

class PrintTopViewofTree:
    def __init__(self):
        pass
#  A class to represent a queue item. The queue is used to do Level
#  order traversal. Every Queue item contains node and horizontal

def main(args=None):
    if args is None:
        args = []
    root = TreeNode(1)
    root.left = TreeNode(2)
    root.right = TreeNode(3)
    root.left.right = TreeNode(4)
    root.left.right.right = TreeNode(5)
    root.left.right.right.right = TreeNode(6)
    t = Tree(root)
    print("Following are nodes in top view of Binary Tree")
    t.printTopView()

if __name__ == "__main__":
    main()

# --- 转换测试报告 ---
# 转换效率: 0.915
# 可解析度: 1.000 (6/6)
# --- 报告结束 ---
