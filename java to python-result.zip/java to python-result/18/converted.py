# --- File: MatrixGraphs.java ---

# package: com.thealgorithms.datastructures.graphs

# import: java.util.ArrayList

# import: java.util.LinkedList

# import: java.util.List

# import: java.util.Queue

class MatrixGraphs:
    """* Implementation of a graph in a matrix form Also known as an adjacency matrix
 * representation [Adjacency matrix -
 * Wikipedia](https://en.wikipedia.org/wiki/Adjacency_matrix)
 *
 * @author Unknown"""
    def __init__(self):
        pass
class AdjacencyMatrixGraph:
    """* AdjacencyMatrixGraph Implementation"""
    EDGE_EXIST: int = 1
    EDGE_NONE: int = 0
    def __init__(self, givenNumberOfVertices):
        """* Constructor"""
        # 
     * Constructor
     
        self.setNumberOfVertices(givenNumberOfVertices)
        self.setNumberOfEdges(0)
        self.setAdjacency(new int[givenNumberOfVertices][givenNumberOfVertices])
        for i in range(givenNumberOfVertices):
            for j in range(givenNumberOfVertices):
                self.adjacency()[i][j] = AdjacencyMatrixGraph.EDGE_NONE
    def setNumberOfVertices(self, newNumberOfVertices):
        """* Updates the number of vertices in the graph
     *
     * @param newNumberOfVertices the new number of vertices"""
        # 
     * Updates the number of vertices in the graph
     *
     * @param newNumberOfVertices the new number of vertices
     
        self.vertexCount = newNumberOfVertices
    def numberOfVertices(self):
        """* Getter for `this.vertexCount`
     *
     * @return the number of vertices in the graph"""
        # 
     * Getter for `this.vertexCount`
     *
     * @return the number of vertices in the graph
     
        return this.vertexCount
    def setNumberOfEdges(self, newNumberOfEdges):
        """* Updates the number of edges in the graph
     *
     * @param newNumberOfEdges the new number of edges
     *"""
        # 
     * Updates the number of edges in the graph
     *
     * @param newNumberOfEdges the new number of edges
     *
     
        self.edgeCount = newNumberOfEdges
    def numberOfEdges(self):
        """* Getter for `this.edgeCount`
     *
     * @return the number of edges"""
        # 
     * Getter for `this.edgeCount`
     *
     * @return the number of edges
     
        return this.edgeCount
    def setAdjacency(self, newAdjacency):
        """* Sets a new matrix as the adjacency matrix
     *
     * @param newAdjacency the new adjaceny matrix"""
        # 
     * Sets a new matrix as the adjacency matrix
     *
     * @param newAdjacency the new adjaceny matrix
     
        self.adjMatrix = newAdjacency
    def adjacency(self):
        """* Getter for the adjacency matrix
     *
     * @return the adjacency matrix"""
        # 
     * Getter for the adjacency matrix
     *
     * @return the adjacency matrix
     
        # Unhandled node type: ArrayType
        return this.adjMatrix
    def adjacencyOfEdgeDoesExist(self, from, to):
        """* Checks if two vertices are connected by an edge
     *
     * @param from the parent vertex to check for adjacency
     * @param to the child vertex to check for adjacency
     * @return whether or not the vertices are adjacent"""
        # 
     * Checks if two vertices are connected by an edge
     *
     * @param from the parent vertex to check for adjacency
     * @param to the child vertex to check for adjacency
     * @return whether or not the vertices are adjacent
     
        return (this.adjacency()[from][to] != AdjacencyMatrixGraph.EDGE_NONE)
    def vertexDoesExist(self, aVertex):
        """* Checks if a particular vertex exists in a graph
     *
     * @param aVertex the vertex to check for existence
     * @return whether or not the vertex exists"""
        # 
     * Checks if a particular vertex exists in a graph
     *
     * @param aVertex the vertex to check for existence
     * @return whether or not the vertex exists
     
        return aVertex >= 0 && aVertex < this.numberOfVertices()
    def edgeDoesExist(self, from, to):
        """* Checks if two vertices are connected by an edge
     *
     * @param from the parent vertex to check for adjacency
     * @param to the child vertex to check for adjacency
     * @return whether or not the vertices are adjacent"""
        # 
     * Checks if two vertices are connected by an edge
     *
     * @param from the parent vertex to check for adjacency
     * @param to the child vertex to check for adjacency
     * @return whether or not the vertices are adjacent
     
        if this.vertexDoesExist(from) && this.vertexDoesExist(to):
            return (this.adjacencyOfEdgeDoesExist(from, to))
        return false
    def addEdge(self, from, to):
        """* This method adds an edge to the graph between two specified vertices
     *
     * @param from the data of the vertex the edge is from
     * @param to the data of the vertex the edge is going to
     * @return returns true if the edge did not exist, return false if it
     * already did"""
        # 
     * This method adds an edge to the graph between two specified vertices
     *
     * @param from the data of the vertex the edge is from
     * @param to the data of the vertex the edge is going to
     * @return returns true if the edge did not exist, return false if it
     * already did
     
        if this.vertexDoesExist(from) && this.vertexDoesExist(to):
            if !this.adjacencyOfEdgeDoesExist(from, to):
                self.adjacency()[from][to] = AdjacencyMatrixGraph.EDGE_EXIST
                self.adjacency()[to][from] = AdjacencyMatrixGraph.EDGE_EXIST
                self.setNumberOfEdges(self.numberOfEdges() + 1)
                return true
        return false
    def removeEdge(self, from, to):
        """* this method removes an edge from the graph between two specified vertices
     *
     * @param from the data of the vertex the edge is from
     * @param to the data of the vertex the edge is going to
     * @return returns false if the edge doesn't exist, returns true if the edge
     * exists and is removed"""
        # 
     * this method removes an edge from the graph between two specified vertices
     *
     * @param from the data of the vertex the edge is from
     * @param to the data of the vertex the edge is going to
     * @return returns false if the edge doesn't exist, returns true if the edge
     * exists and is removed
     
        if this.vertexDoesExist(from) && this.vertexDoesExist(to):
            if this.adjacencyOfEdgeDoesExist(from, to):
                self.adjacency()[from][to] = AdjacencyMatrixGraph.EDGE_NONE
                self.adjacency()[to][from] = AdjacencyMatrixGraph.EDGE_NONE
                self.setNumberOfEdges(self.numberOfEdges() - 1)
                return true
        return false
    def depthFirstOrder(self, startVertex):
        """* This method returns a list of the vertices in a depth first order
     * beginning with the specified vertex
     *
     * @param startVertex the vertex to begin the traversal
     * @return the list of the ordered vertices"""
        # 
     * This method returns a list of the vertices in a depth first order
     * beginning with the specified vertex
     *
     * @param startVertex the vertex to begin the traversal
     * @return the list of the ordered vertices
     
        if startVertex >= vertexCount || startVertex < 0:
            startVertex + vertexCount
        else:
            return new ArrayList<>()
        visited = new boolean[vertexCount]
        orderList = []
        depthFirstOrder(startVertex, visited, orderList)
        return orderList
    def depthFirstOrder(self, currentVertex, visited, orderList):
        """* Helper method for public depthFirstOrder(int) that will perform a depth
     * first traversal recursively on the graph
     *
     * @param currentVertex the currently exploring vertex
     * @param visited the array of values denoting whether or not that vertex
     * has been visited
     * @param orderList the list to add vertices to as they are visited"""
        # 
     * Helper method for public depthFirstOrder(int) that will perform a depth
     * first traversal recursively on the graph
     *
     * @param currentVertex the currently exploring vertex
     * @param visited the array of values denoting whether or not that vertex
     * has been visited
     * @param orderList the list to add vertices to as they are visited
     
        if visited[currentVertex]:
            visited
            currentVertex
        else:
            return
        visited[currentVertex] = true
        orderList.append(currentVertex)
        adjacent = adjMatrix[currentVertex]
        for i in range(adjacent.length):
            if adjacent[i] == AdjacencyMatrixGraph.EDGE_EXIST:
                AdjacencyMatrixGraph.EDGE_EXIST
            else:
                depthFirstOrder(i, visited, orderList)
    def breadthFirstOrder(self, startVertex):
        """* This method returns a list of the vertices in a breadth first order
     * beginning with the specified vertex
     *
     * @param startVertex the vertext to begin the traversal
     * @return the list of the ordered vertices"""
        # 
     * This method returns a list of the vertices in a breadth first order
     * beginning with the specified vertex
     *
     * @param startVertex the vertext to begin the traversal
     * @return the list of the ordered vertices
     
        if startVertex >= vertexCount || startVertex < 0:
            startVertex + vertexCount
        else:
            return new ArrayList<>()
        visited = new boolean[vertexCount]
        orderList = []
        queue = LinkedList()
        queue.append(startVertex)
        while !queue.isEmpty():
            currentVertex = queue.poll()
            if visited[currentVertex]:
                visited
                currentVertex
            else:
                continue
            orderList.append(currentVertex)
            visited[currentVertex] = true
            adjacent = adjMatrix[currentVertex]
            for vertex in range(adjacent.length):
                if adjacent[vertex] == AdjacencyMatrixGraph.EDGE_EXIST:
                    AdjacencyMatrixGraph.EDGE_EXIST
                else:
                    queue.append(vertex)
        return orderList
    def toString(self):
        """* this gives a list of vertices in the graph and their adjacencies
     *
     * @return returns a string describing this graph"""
        # 
     * this gives a list of vertices in the graph and their adjacencies
     *
     * @return returns a string describing this graph
     
        s = StringBuilder("    ")
        for i in range(this.numberOfVertices()):
            s.append(i).append(" ")
        s.append(" \n")
        for i in range(this.numberOfVertices()):
            s.append(i).append(" : ")
            for j in range(this.numberOfVertices()):
                s.append(self.adjMatrix[i][j]).append(" ")
            s.append("\n")
        return s.toString()

def main(args=None):
    if args is None:
        args = []
    graph = AdjacencyMatrixGraph(10)
    graph.addEdge(1, 2)
    graph.addEdge(1, 5)
    graph.addEdge(2, 5)
    graph.addEdge(1, 2)
    graph.addEdge(2, 3)
    graph.addEdge(3, 4)
    graph.addEdge(4, 1)
    graph.addEdge(2, 3)
    graph.addEdge(3, 9)
    graph.addEdge(9, 1)
    graph.addEdge(9, 8)
    graph.addEdge(1, 8)
    graph.addEdge(5, 6)
    print("The graph matrix:")
    print(graph)
    print("Depth first order beginning at node '1':")
    print(graph.depthFirstOrder(1))
    print("Breadth first order beginning at node '1':")
    print(graph.breadthFirstOrder(1))

if __name__ == "__main__":
    main()
