# --- File: IndexOfRightMostSetBit.java ---

# package: com.thealgorithms.bitmanipulation

class IndexOfRightMostSetBit:
    """* Utility class for bit manipulation operations.
 * This class provides methods to work with bitwise operations.
 * Specifically, it includes a method to find the index of the rightmost set bit
 * in an integer.
 * This class is not meant to be instantiated.
 *
 * Author: Bama Charan Chhandogi (https://github.com/BamaCharanChhandogi)"""
    def __init__(self):
        pass
    @staticmethod
    def indexOfRightMostSetBit(n):
        """* Finds the index of the rightmost set bit in the given integer.
     * The index is zero-based, meaning the rightmost bit has an index of 0.
     *
     * @param n the integer to check for the rightmost set bit
     * @return the index of the rightmost set bit; -1 if there are no set bits
     *         (i.e., the input integer is 0)"""
        if n == 0:
            return -1
        if n < 0:
            n = -n
            n = n & (~n + 1)
        index = 0
        while (n & 1) == 0:
            n = n >> 1
            index += 1
        return index

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.875
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
