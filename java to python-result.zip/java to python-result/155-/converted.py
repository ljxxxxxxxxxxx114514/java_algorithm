# --- File: UniquePermutation.java ---

# package: com.thealgorithms.backtracking

# import: java.util.ArrayList

# import: java.util.Arrays

# import: java.util.List

class UniquePermutation:
    """* Generates all UNIQUE permutations of a string, even when duplicate characters exist.
 *
 * Example:
 *   Input: "AAB"
 *   Output: ["AAB", "ABA", "BAA"]
 *
 * Time Complexity: O(n! * n)"""
    def __init__(self):
        raise UnsupportedOperationException("Utility class")
    @staticmethod
    def generateUniquePermutations(input):
        result = list()
        if input == None:
            return result
        chars = input.toCharArray()
        sorted(chars)
        backtrack(chars, [None] * chars.length, StringBuilder(), result)
        return result
    @staticmethod
    def backtrack(chars, used, current, result):
        if current.length():
            result.append(current.toString())
            return
        for i in range(chars.length):
            if i > 0 and chars[i] == chars[i - 1] and not used[i - 1]:
                continue
            if not used[i]:
                used[i] = True
                current.append(chars[i])
                backtrack(chars, used, current, result)
                used[i] = False
                current.deleteCharAt(current.length() - 1)

if __name__ == "__main__":
    pass

# --- 转换测试报告 ---
# 转换效率: 0.893
# 可解析度: 1.000 (2/2)
# --- 报告结束 ---
